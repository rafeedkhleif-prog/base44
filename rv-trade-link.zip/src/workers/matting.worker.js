import { AutoModel, Tensor, env } from "@huggingface/transformers";
import { MODEL_ID, MODEL_REVISION, MODEL_SIZE, MODEL_OUTPUT_KIND } from "@/lib/mattingModel";
import photoError from "@/lib/photoError";
import { inferenceDiagnostics } from '@/lib/mattingDiagnostics';

// Model and upstream MIT notices are distributed in mattingModel and the pilot's license disclosure.
// Use the real fixed-512 fp32 graph, not a 1024 graph with a smaller input.
env.allowLocalModels = false;
const DEVICE = "wasm";
const MEAN = [0.485, 0.456, 0.406], STD = [0.229, 0.224, 0.225];
let modelPromise = null;

async function loadModel(report) {
  if (!modelPromise) {
    modelPromise = (async () => {
      if (env.backends?.onnx?.wasm) env.backends.onnx.wasm.numThreads = 1;
      report("loading", "Loading fixed 512 graph, WASM fp32");
      const model = await AutoModel.from_pretrained(MODEL_ID, {
        revision: MODEL_REVISION, model_file_name: "model", dtype: "fp32", device: DEVICE,
        progress_callback: progress => {
          const percent = Number.isFinite(progress.progress) ? ` ${Math.round(progress.progress)}%` : "";
          report("loading", `${progress.status || "loading"}: ${progress.file || "512 model"}${percent}`);
        },
      });
      const session = model.sessions?.model;
      const outputName = session?.outputNames?.[0];
      if (session?.inputNames?.length !== 1 || session.inputNames[0] !== "input_image" ||
          session?.outputNames?.length !== 1 || typeof outputName !== "string" || !outputName) {
        throw new Error(`Unexpected graph metadata: inputs ${JSON.stringify(session?.inputNames)}, outputs ${JSON.stringify(session?.outputNames)}`);
      }
      report("normalizing", `Graph loaded: input_image to ${outputName} (${MODEL_OUTPUT_KIND}), fixed 512 RGB`);
      return { model, outputName, outputKind: MODEL_OUTPUT_KIND };
    })();
    modelPromise.catch(() => { modelPromise = null; });
  }
  return modelPromise;
}
function buildTensor(rgba, width, height) {
  const pixels = width * height, data = new Float32Array(pixels * 3);
  for (let i = 0; i < pixels; i++) for (let c = 0; c < 3; c++) {
    data[c * pixels + i] = (rgba[i * 4 + c] / 255 - MEAN[c]) / STD[c];
  }
  return new Tensor("float32", data, [1, 3, height, width]);
}
function readMask(outputs, outputName, outputKind) {
  const tensor = outputs?.[outputName];
  if (!tensor || tensor.type !== "float32" || !(tensor.data instanceof Float32Array) || !Array.isArray(tensor.dims)) {
    throw new Error(`Missing or invalid float32 output ${outputName}; returned ${Object.keys(outputs || {}).join(", ")}`);
  }
  const dims = tensor.dims, expected = [1, 1, MODEL_SIZE, MODEL_SIZE];
  if (dims.length !== expected.length || dims.some((dim, i) => !Number.isInteger(dim) || dim !== expected[i]) ||
      tensor.data.length !== dims.reduce((size, dim) => size * dim, 1)) {
    throw new Error(`Unexpected ${outputName} shape/length: ${JSON.stringify(dims)}, ${tensor.data.length} values; expected ${JSON.stringify(expected)}`);
  }
  if (outputKind !== "logits" && outputKind !== "probabilities") throw new Error("Unknown graph output activation contract");
  const mask = new Uint8Array(MODEL_SIZE * MODEL_SIZE);
  for (let i = 0; i < mask.length; i++) {
    const value = tensor.data[i];
    if (!Number.isFinite(value)) throw new Error(`${outputName} contains non-finite values at ${i}`);
    if (outputKind === "probabilities" && (value < 0 || value > 1)) {
      throw new Error(`${outputName} probability outside [0,1] at ${i}`);
    }
    // Only the verified export contract authorizes sigmoid; [0,1] logits remain logits.
    const alpha = outputKind === "logits" ? 1 / (1 + Math.exp(-value)) : value;
    mask[i] = Math.round(255 * alpha);
  }
  return { mask, maskWidth: MODEL_SIZE, maskHeight: MODEL_SIZE };
}
self.onmessage = async event => {
  const { id, type, width, height, rgba, diagnostics, expectedLogits } = event.data || {};
  let stage = "loading", input, outputs;
  const report = (next, detail) => {
    stage = next;
    self.postMessage({ id, type: "stage", stage, detail, device: `${DEVICE} fp32 · ${MODEL_SIZE}×${MODEL_SIZE}` });
  };
  try {
    if (type !== "load" && (width !== MODEL_SIZE || height !== MODEL_SIZE || rgba?.length !== width * height * 4)) throw new Error("Expected a 512×512 RGB image");
    const { model, outputName, outputKind } = await loadModel(report);
    if (type === "load") { self.postMessage({ id, type: "ready", device: `${DEVICE} fp32 · ${MODEL_SIZE}×${MODEL_SIZE}` }); return; }
    report("normalizing", "ImageNet RGB normalization, input_image [1,3,512,512]");
    input = buildTensor(rgba, width, height);
    report("inference", "Running fixed 512 fp32 graph in browser WASM");
    outputs = await model({ input_image: input });
    report("reading", `Reading ${outputName} (${outputKind}), validating shape and values`);
    const result = readMask(outputs, outputName, outputKind);
    if (diagnostics) result.diagnostics = await inferenceDiagnostics(input, outputs[outputName], outputName, expectedLogits);
    self.postMessage({ id, type: "mask", ...result, device: `${DEVICE} fp32 · ${MODEL_SIZE}×${MODEL_SIZE}` }, [result.mask.buffer]);
  } catch (error) {
    self.postMessage({ id, type: "error", stage, message: photoError(error, `${MODEL_ID}, ${DEVICE} fp32, ${MODEL_SIZE}×${MODEL_SIZE}, stage ${stage}`) });
  } finally {
    input?.dispose?.();
    if (outputs) for (const tensor of Object.values(outputs)) tensor?.dispose?.();
  }
};