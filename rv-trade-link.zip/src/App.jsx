import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import ProtectedRoute from '@/components/ProtectedRoute';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';
import Equipment from './pages/Equipment';
import ListingDetail from './pages/ListingDetail';
import Sell from './pages/Sell';
import EditListing from './pages/EditListing';
import Service from './pages/Service';
import Recycle from './pages/Recycle';
import ThankYou from './pages/ThankYou';
import Newsletter from './pages/Newsletter';
import NewsletterAdmin from './pages/NewsletterAdmin';
import ShippingAdmin from './pages/ShippingAdmin';
import RepairAdmin from './pages/RepairAdmin';
import PickupAdmin from './pages/PickupAdmin';
import Orders from './pages/Orders';
import ShippingInvoicePay from './pages/ShippingInvoicePay';
import OfferThread from './pages/OfferThread';
import OffersAdmin from './pages/OffersAdmin';
import Cart from './pages/Cart';
import MattingPilot from './pages/MattingPilot';
import MattingBatch from './pages/MattingBatch';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/equipment" element={<Equipment />} />
      <Route path="/equipment/:id" element={<ListingDetail />} />
      <Route path="/cart" element={<Cart />} />
      <Route path="/service" element={<Service />} />
      <Route path="/recycle" element={<Recycle />} />
      <Route path="/newsletter" element={<Newsletter />} />
      <Route path="/shipping-invoice/:token" element={<ShippingInvoicePay />} />
      <Route path="/offer/:token" element={<OfferThread />} />
      <Route path="/ThankYou" element={<ThankYou />} />
      <Route
        element={
          <ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />
        }
      >
        <Route path="/sell" element={<Sell />} />
        <Route path="/sell/:id" element={<EditListing />} />
        <Route path="/newsletter-admin" element={<NewsletterAdmin />} />
        <Route path="/shipping-admin" element={<ShippingAdmin />} />
        <Route path="/repair-admin" element={<RepairAdmin />} />
        <Route path="/pickup-admin" element={<PickupAdmin />} />
        <Route path="/orders" element={<Orders />} />
        <Route path="/offers" element={<OffersAdmin />} />
        <Route path="/matting-pilot" element={<MattingPilot />} />
        <Route path="/matting-batch" element={<MattingBatch />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App