import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { CATEGORIES } from "@/data/catalog";

export default function CategoryRail() {
  return (
    <section className="mx-auto mt-24 w-full max-w-[1330px] px-5 md:px-16">
      <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between md:gap-10">
        <div>
          <div className="text-[11px] font-medium uppercase tracking-[0.16em] text-sage">
            Equipment
          </div>
          <h2 className="mt-2.5 text-[26px] font-light leading-[1.15] md:text-[38px]">
            Shop by category
          </h2>
          <p className="mt-2.5 max-w-[420px] text-[15px] text-ink-body">
            {CATEGORIES.length} categories of hospital and clinic equipment, stocked and serviced in
            Pacoima.
          </p>
        </div>
        <Link
          to="/equipment"
          className="inline-flex items-center gap-2 self-start rounded-full border border-sage-line bg-shell px-5 py-3 text-[13px] text-ink transition-colors duration-200 hover:bg-panel md:self-auto"
        >
          All inventory
          <ArrowRight className="h-3.5 w-3.5 text-sage" />
        </Link>
      </div>

      <div className="mt-10 grid gap-3.5 sm:grid-cols-2 lg:grid-cols-4">
        {CATEGORIES.map((cat) => (
          <Link
            key={cat.slug}
            to={`/equipment?category=${cat.slug}`}
            className="group flex items-center justify-between gap-3 rounded-full border border-rule bg-shell px-6 py-4 text-[15px] transition-[background,box-shadow] duration-200 hover:bg-panel hover:shadow-[0_4px_12px_rgba(43,43,43,0.05)]"
          >
            <span>{cat.label}</span>
            <ArrowRight className="h-4 w-4 shrink-0 text-sage" />
          </Link>
        ))}
      </div>
    </section>
  );
}