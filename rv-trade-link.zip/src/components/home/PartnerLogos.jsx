import { Image } from "@/components/ui/image";

const PARTNER_STRIP =
  "https://base44.app/api/apps/6aeb6aa1c91d4c8d5bcd4ce8/files/mp/public/6aeb6aa1c91d4c8d5bcd4ce8/b9feca159_hospital-partners.png";

export default function PartnerLogos() {
  return (
    <section className="mx-auto mt-24 w-full max-w-[1330px] px-5 md:px-16">
      <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="text-[11px] font-medium uppercase tracking-[0.16em] text-sage">
            Partner hospitals
          </div>
          <h2 className="mt-2.5 max-w-[640px] text-[26px] font-light leading-[1.15] md:text-[38px]">
            Trusted by hospitals and institutions we serve
          </h2>
        </div>
        <p className="max-w-[420px] text-[15px] text-ink-body">
          Equipment we refurbish and recycle is put back to work across Southern California health
          systems and training programs.
        </p>
      </div>

      <div className="mt-10 flex items-center justify-center rounded-2xl border border-rule bg-shell px-4 py-8 md:px-10 md:py-10">
        <Image
          src={PARTNER_STRIP}
          alt="El Camino College, Providence Health & Services Southern California, Simi Valley Hospital and Adventist Health"
          fittingType="fit"
          className="h-auto w-full object-contain"
        />
      </div>
    </section>
  );
}