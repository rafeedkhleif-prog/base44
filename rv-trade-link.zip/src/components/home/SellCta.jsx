import { Link } from "react-router-dom";
import { Check } from "lucide-react";
import { Image } from "@/components/ui/image";

const POINTS = [
  "Submit your equipment in a few minutes",
  "We verify condition and publish the listing",
  "Buyers pay online — you get paid when it sells",
];

const SELL_IMAGE =
  "https://media.base44.com/images/public/6aeb6aa1c91d4c8d5bcd4ce8/4b5d16575_generated_22a2d7a6.jpg";

const BTN_PRIMARY =
  "inline-flex items-center justify-center rounded-full bg-sage px-6 py-3 text-[14px] text-white transition-[background,box-shadow,transform] duration-200 hover:-translate-y-0.5 hover:bg-sage-deep hover:shadow-[0_6px_16px_rgba(63,107,90,0.2)]";
const BTN_SECONDARY =
  "inline-flex items-center justify-center rounded-full border border-sage-line bg-shell px-6 py-3 text-[14px] text-ink transition-colors duration-200 hover:bg-panel";

export default function SellCta() {
  return (
    <section className="mx-5 mt-24 overflow-hidden rounded-2xl bg-panel md:mx-8 lg:mx-auto lg:w-full lg:max-w-[1330px]">
      <div className="grid lg:grid-cols-2">
        <div className="relative min-h-[280px] lg:min-h-[520px]">
          <Image
            src={SELL_IMAGE}
            alt="Interior of a mobile medical clinic exam room"
            fittingType="fill"
            className="absolute inset-0 h-full w-full"
          />
          <span className="absolute bottom-[18px] left-5 rounded-full bg-canvas/90 px-3.5 py-1.5 text-[11px] uppercase tracking-[0.1em] text-ink">
            Mobile clinic fit-out · Unit 04
          </span>
        </div>

        <div className="p-8 md:p-16">
          <div className="text-[11px] font-medium uppercase tracking-[0.16em] text-sage">
            / 04 — Sell
          </div>
          <h2 className="mt-2.5 text-[26px] font-light leading-[1.15] md:text-[38px]">
            Have equipment sitting idle?
          </h2>
          <p className="mt-4 max-w-[460px] text-[15px] leading-relaxed text-ink-soft">
            Turn surplus beds, stretchers, monitors or whole mobile units into working capital. List
            it yourself, or send us the details and our team will handle the valuation.
          </p>

          <ul className="mt-6 flex flex-col gap-3">
            {POINTS.map((point) => (
              <li key={point} className="flex gap-3 text-[14px] text-ink-list">
                <Check className="mt-0.5 h-[18px] w-[18px] shrink-0 text-sage" />
                {point}
              </li>
            ))}
          </ul>

          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <Link to="/sell" className={BTN_PRIMARY}>
              List equipment for sale
            </Link>
            <Link to="/#contact" className={BTN_SECONDARY}>
              Request a valuation
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}