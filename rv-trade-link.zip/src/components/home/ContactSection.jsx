import { Link } from "react-router-dom";
import { Mail, MapPin, Phone } from "lucide-react";
import ContactForm from "@/components/home/ContactForm";

export default function ContactSection() {
  return (
    <section id="contact" className="mx-auto mt-24 w-full max-w-[1330px] px-5 md:px-16">
      <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between md:gap-10">
        <div>
          <div className="text-[11px] font-medium uppercase tracking-[0.16em] text-sage">
            Contact
          </div>
          <h2 className="mt-2.5 text-[26px] font-light leading-[1.15] md:text-[38px]">
            How can we help?
          </h2>
        </div>
        <p className="max-w-[420px] text-[15px] text-ink-body">
          Tell us what you're looking for — or what you're looking to move. We reply within one
          business day.
        </p>
      </div>

      <div className="mt-10 grid gap-10 rounded-2xl border border-rule bg-shell p-6 md:grid-cols-[1fr_1.2fr] md:gap-14 md:p-12">
        <div>
          <div className="flex gap-4">
            <Phone className="mt-1 h-[18px] w-[18px] shrink-0 text-sage" />
            <div>
              <small className="block text-[11px] uppercase tracking-[0.14em] text-ink-faint">
                Phone
              </small>
              <a href="tel:+18188998090" className="text-[19px] leading-snug transition-colors hover:text-sage">
                1-818-899-8090
              </a>
            </div>
          </div>

          <div className="mt-6 flex gap-4">
            <Mail className="mt-1 h-[18px] w-[18px] shrink-0 text-sage" />
            <div>
              <small className="block text-[11px] uppercase tracking-[0.14em] text-ink-faint">
                Email
              </small>
              <a
                href="mailto:info@medicalrv.com"
                className="text-[19px] leading-snug transition-colors hover:text-sage"
              >
                info@medicalrv.com
              </a>
            </div>
          </div>

          <div className="mt-6 flex gap-4">
            <MapPin className="mt-1 h-[18px] w-[18px] shrink-0 text-sage" />
            <div>
              <small className="block text-[11px] uppercase tracking-[0.14em] text-ink-faint">
                Facility
              </small>
              <b className="text-[19px] font-normal leading-snug">
                13715 Desmond St.
                <br />
                Pacoima, CA 91331
              </b>
              <em className="mt-1.5 block text-[12px] not-italic text-ink-faint">
                Mon–Fri · 8:00–17:00 PT
              </em>
            </div>
          </div>

          <div className="mt-7 rounded-2xl bg-canvas p-5">
            <small className="block text-[11px] uppercase tracking-[0.14em] text-ink-faint">
              Repairs &amp; quotes
            </small>
            <p className="mt-1.5 text-[14px] leading-relaxed text-ink-body">
              Stretchers, hospital beds and exam tables — all major brands, including Midmark and
              Stryker.
            </p>
            <Link
              to="/service"
              className="mt-3 inline-block text-[13px] text-sage transition-opacity duration-200 hover:opacity-70"
            >
              Schedule service or get a quote →
            </Link>
          </div>
        </div>

        <ContactForm />
      </div>
    </section>
  );
}