import { Link } from "react-router-dom";
import { Image } from "@/components/ui/image";

const FACTS = [
  {
    title: "One facility, every stage",
    body: "Inspection, repair, cosmetic restoration and final testing all happen under one roof in Pacoima — nothing is subcontracted.",
  },
  {
    title: "Factory-trained technicians",
    body: "Twenty years of service experience across Hill-Rom, Stryker, GE, Dräger, Midmark and Maquet platforms.",
  },
  {
    title: "Documented, warranted work",
    body: "Every unit ships with a condition report and warranty. If it fails our own bench test, it does not get listed.",
  },
];

const FACILITY_IMAGE =
  "https://media.base44.com/images/public/6aeb6aa1c91d4c8d5bcd4ce8/0be5363ad_generated_3d017681.jpg";

export default function AboutBand() {
  return (
    <section className="mx-auto mt-24 w-full max-w-[1330px] px-5 md:px-16">
      <div className="grid items-center gap-10 lg:grid-cols-[480px_1fr] lg:gap-16">
        <div className="h-[320px] overflow-hidden rounded-2xl lg:h-[480px]">
          <Image
            src={FACILITY_IMAGE}
            alt="Surgical light refurbished in the Medical ReVitalization facility"
            fittingType="fill"
            className="h-full w-full"
          />
        </div>

        <div>
          <div className="text-[11px] font-medium uppercase tracking-[0.16em] text-sage">
            / Company
          </div>
          <h2 className="mt-2.5 max-w-[520px] text-[26px] font-light leading-[1.15] md:text-[38px]">
            Twenty years keeping clinics equipped
          </h2>

          <div className="mt-7">
            {FACTS.map((fact, index) => (
              <div
                key={fact.title}
                className={`border-t border-rule-strong pt-4 ${index === 0 ? "" : "mt-5"}`}
              >
                <h3 className="text-[16px] font-medium">{fact.title}</h3>
                <p className="mt-1 max-w-[560px] text-[14px] leading-relaxed text-ink-body">
                  {fact.body}
                </p>
              </div>
            ))}
          </div>

          <Link
            to="/#contact"
            className="mt-5 inline-block text-[13px] text-sage transition-opacity duration-200 hover:opacity-70"
          >
            Visit the facility →
          </Link>
        </div>
      </div>
    </section>
  );
}