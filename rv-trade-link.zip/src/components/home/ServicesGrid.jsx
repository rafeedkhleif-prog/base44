import { Link } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

const SERVICES = [
  {
    title: "Refurbish",
    body: "Factory-trained technicians restore equipment to excellent cosmetic and working condition. Rental units available while yours is in our care.",
    to: "/equipment?condition=refurbished",
    cta: "See refurbished units",
  },
  {
    title: "Buy",
    body: "Hospital beds, gurneys, OR tables. Every refurbished item ships with a warranty and guaranteed workmanship.",
    to: "/equipment",
    cta: "Browse inventory",
  },
  {
    title: "Sell",
    body: "Have equipment you no longer use? List it here, reach our buyer network, and collect payment through secure online checkout.",
    to: "/sell",
    cta: "List your equipment",
    adminOnly: true,
  },
  {
    title: "Recycle",
    body: "We strip retired equipment to individual components, then reuse or route each part to the appropriate recycler — fully documented.",
    to: "/#contact",
    cta: "Talk to us",
  },
];

const DELAYS = ["soft-d1", "soft-d2", "soft-d3", "soft-d4"];

export default function ServicesGrid() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const services = SERVICES.filter((service) => isAdmin || !service.adminOnly);

  return (
    <section id="services" className="mt-24 bg-panel">
      <div className="mx-auto w-full max-w-[1330px] px-5 py-16 md:px-16 md:py-20">
        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between md:gap-10">
          <div>
            <div className="text-[11px] font-medium uppercase tracking-[0.16em] text-sage">
              Services
            </div>
            <h2 className="mt-2.5 max-w-[640px] text-[26px] font-light leading-[1.15] md:text-[38px]">
              One facility for the full equipment lifecycle
            </h2>
          </div>
          <p className="max-w-[420px] text-[15px] leading-relaxed text-ink-body">
            Refurbish, buy, sell or recycle — the same technicians handle every stage, so condition
            reports mean something.
          </p>
        </div>

        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((service, index) => (
            <div
              key={service.title}
              className={`flex min-h-[300px] flex-col rounded-2xl border border-rule bg-canvas p-7 transition-[transform,box-shadow] [transition-duration:250ms] hover:-translate-y-0.5 hover:shadow-[0_8px_20px_rgba(43,43,43,0.06)] soft-up ${DELAYS[index % DELAYS.length]}`}
            >
              <h3 className="text-[24px] font-normal">{service.title}</h3>
              <p className="mt-2.5 flex-1 text-[14px] leading-relaxed text-ink-body">
                {service.body}
              </p>
              <Link
                to={service.to}
                className="mt-5 text-[13px] text-sage transition-opacity duration-200 hover:opacity-70"
              >
                {service.cta} →
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}