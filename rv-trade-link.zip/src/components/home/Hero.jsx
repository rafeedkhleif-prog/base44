import { Link } from "react-router-dom";
import { Image } from "@/components/ui/image";
import { useAuth } from "@/lib/AuthContext";

const HERO_IMAGE =
  "https://base44.app/api/apps/6aeb6aa1c91d4c8d5bcd4ce8/files/mp/public/6aeb6aa1c91d4c8d5bcd4ce8/55e230f06_hero-facility.png";

const STATS = [
  { value: "20+", label: "Years of service" },
  { value: "20,000", label: "Sq ft equipment floor" },
  { value: "50", label: "States delivered" },
];

const BTN_PRIMARY =
  "inline-flex items-center justify-center rounded-full bg-sage px-6 py-3 text-[14px] text-white transition-[background,box-shadow,transform] duration-200 hover:-translate-y-0.5 hover:bg-sage-deep hover:shadow-[0_6px_16px_rgba(63,107,90,0.2)]";
const BTN_SECONDARY =
  "inline-flex items-center justify-center rounded-full border border-sage-line bg-shell px-6 py-3 text-[14px] text-ink transition-colors duration-200 hover:bg-panel";

export default function Hero() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  return (
    <section className="relative mx-auto w-full max-w-[1330px] px-5 pt-10 text-center md:px-16 md:pt-14">
      <div className="soft-up soft-d1 text-[11px] font-medium uppercase tracking-[0.16em] text-sage">
        Pacoima, California
      </div>

      <h1 className="soft-up soft-d2 mt-4 text-[42px] font-light leading-[1.05] tracking-[-0.01em] md:text-[68px] md:leading-[1.08]">
        Medical Equipment
      </h1>

      <p className="soft-up soft-d3 mx-auto mt-5 max-w-[560px] text-[16px] leading-relaxed text-ink-body md:text-[17px]">
        Your one-stop source for new, used and refurbished medical equipment and mobile medical
        units.
      </p>

      <div className="soft-up soft-d3 mt-7 flex flex-col justify-center gap-3 sm:flex-row">
        <Link to="/equipment" className={BTN_PRIMARY}>
          Browse inventory
        </Link>
        {isAdmin && (
          <Link to="/sell" className={BTN_SECONDARY}>
            List equipment for sale
          </Link>
        )}
        <Link to="/service" className={BTN_SECONDARY}>
          Schedule service
        </Link>
      </div>

      <div className="soft-up soft-d4 relative mx-auto mt-12 h-[320px] overflow-hidden rounded-2xl md:h-[560px]">
        <Image
          src={HERO_IMAGE}
          alt="Modern hospital building exterior with an ambulance entrance"
          fittingType="fill"
          className="h-full w-full"
        />
      </div>

      <div className="soft-up soft-d5 relative z-10 mx-auto -mt-12 grid max-w-[900px] grid-cols-2 rounded-2xl border border-rule bg-shell md:grid-cols-3">
        {STATS.map((stat) => (
          <div
            key={stat.label}
            className="border-b border-rule px-5 py-5 text-left md:border-b-0 md:border-r md:px-[26px] md:py-[22px] md:last:border-r-0"
          >
            <b className="block text-[26px] font-light md:text-[30px]">{stat.value}</b>
            <span className="text-[12px] text-ink-faint">{stat.label}</span>
          </div>
        ))}
      </div>
    </section>
  );
}