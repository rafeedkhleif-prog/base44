import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { ArrowRight, Loader2 } from "lucide-react";

const FIELDS = [
  { name: "name", label: "Name", type: "text", placeholder: "Your name", required: true },
  { name: "email", label: "Email", type: "email", placeholder: "you@clinic.com", required: true },
  { name: "subject", label: "Subject", type: "text", placeholder: "Equipment inquiry", required: false },
];

const FIELD_CLASS =
  "w-full rounded-xl border border-fieldline bg-canvas px-4 text-[14px] text-ink outline-none transition-colors duration-200 placeholder:text-ink-meta focus:border-sage-line";
const LABEL_CLASS = "block text-[11px] uppercase tracking-[0.14em] text-ink-faint";

export default function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");

  const update = (field) => (event) => setForm((prev) => ({ ...prev, [field]: event.target.value }));

  const handleSubmit = async (event) => {
    event.preventDefault();
    setStatus("sending");
    setError("");
    try {
      await base44.entities.Inquiry.create(form);
      setStatus("sent");
      setForm({ name: "", email: "", subject: "", message: "" });
    } catch (err) {
      setStatus("idle");
      setError("We couldn't send that. Please call 1-818-899-8090 instead.");
    }
  };

  if (status === "sent") {
    return (
      <div className="flex flex-col justify-center rounded-2xl bg-panel p-8 md:p-10">
        <h3 className="text-[20px] font-normal text-sage">Message received</h3>
        <p className="mt-2.5 text-[14px] leading-relaxed text-ink-body">
          Thanks — our team will reply within one business day. For anything urgent, call
          1-818-899-8090.
        </p>
        <button
          type="button"
          onClick={() => setStatus("idle")}
          className="mt-6 self-start rounded-full border border-sage-line bg-shell px-5 py-2.5 text-[13px] text-ink transition-colors duration-200 hover:bg-canvas"
        >
          Send another
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3.5 rounded-2xl bg-panel p-6 md:p-8">
      <div className="grid gap-3.5 sm:grid-cols-2">
        {FIELDS.map((field) => (
          <div key={field.name} className="flex flex-col gap-1.5">
            <label htmlFor={field.name} className={LABEL_CLASS}>
              {field.label}
            </label>
            <input
              id={field.name}
              type={field.type}
              required={field.required}
              value={form[field.name]}
              onChange={update(field.name)}
              placeholder={field.placeholder}
              className={`h-[46px] ${FIELD_CLASS}`}
            />
          </div>
        ))}
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor="message" className={LABEL_CLASS}>
          Message
        </label>
        <textarea
          id="message"
          required
          rows={4}
          value={form.message}
          onChange={update("message")}
          placeholder="Tell us what you need — model, quantity, timeline."
          className={`min-h-[130px] resize-none py-3 ${FIELD_CLASS}`}
        />
      </div>

      {error && <p className="text-[12px] text-destructive">{error}</p>}

      <button
        type="submit"
        disabled={status === "sending"}
        className="mt-1 inline-flex w-full items-center justify-center gap-2 rounded-full bg-sage px-6 py-3 text-[14px] text-white transition-[background,box-shadow,transform] duration-200 hover:-translate-y-0.5 hover:bg-sage-deep hover:shadow-[0_6px_16px_rgba(63,107,90,0.2)] disabled:opacity-60 sm:w-[160px]"
      >
        {status === "sending" ? (
          <>
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            Sending
          </>
        ) : (
          <>
            Send message
            <ArrowRight className="h-3.5 w-3.5" />
          </>
        )}
      </button>
    </form>
  );
}