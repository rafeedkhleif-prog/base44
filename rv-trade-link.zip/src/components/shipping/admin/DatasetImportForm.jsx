import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2 } from "lucide-react";
import { parseRateTable, parseSurchargeRules, parseZoneChart } from "@/lib/rateCsv";
import { activateDataset } from "@/lib/rateDataset";

const FIELD =
  "w-full border border-border bg-card px-3 py-2.5 font-mono text-[12px] outline-none transition-colors focus:border-primary";
const LABEL = "font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground";
const todayIso = () => new Date().toISOString().slice(0, 10);
const UPS_SOURCE =
  "https://www.ups.com/us/en/support/shipping-support/shipping-costs-rates/retail-rates";

const EMPTY_META = {
  version: "",
  source_name: "UPS Rate and Service Guide · Retail Rates",
  source_url: UPS_SOURCE,
  effective_from: todayIso(),
  effective_to: "",
  dim_divisor: "139",
  max_weight_lb: "150",
  max_length_in: "108",
  max_length_plus_girth_in: "165",
  notes: "",
};

export default function DatasetImportForm({ originZip, onImported }) {
  const [meta, setMeta] = useState(EMPTY_META);
  const [files, setFiles] = useState({ zoneChart: null, rateTable: null, rules: null });
  const [errors, setErrors] = useState([]);
  const [result, setResult] = useState(null);
  const [saving, setSaving] = useState(false);

  const setField = (key, value) => setMeta((previous) => ({ ...previous, [key]: value }));

  const handleImport = async () => {
    setErrors([]);
    setResult(null);
    if (!meta.version.trim()) {
      setErrors(["Add a version label for this dataset."]);
      return;
    }
    if (!files.zoneChart || !files.rateTable) {
      setErrors(["Upload the zone chart CSV and the rate table CSV."]);
      return;
    }
    setSaving(true);
    let dataset = null;
    try {
      const [zoneText, rateText, ruleText] = await Promise.all([
        files.zoneChart.text(),
        files.rateTable.text(),
        files.rules ? files.rules.text() : Promise.resolve(""),
      ]);
      const zone = parseZoneChart(zoneText);
      const rate = parseRateTable(rateText);
      const rules = ruleText.trim()
        ? parseSurchargeRules(ruleText)
        : { rules: [], errors: [] };

      const problems = [...zone.errors, ...rate.errors, ...rules.errors].slice(0, 8);
      if (problems.length > 0) {
        setErrors(problems);
        setSaving(false);
        return;
      }
      if (zone.rows.length === 0) {
        setErrors(["The zone chart file has no valid rows."]);
        setSaving(false);
        return;
      }
      if (rate.tables.length === 0) {
        setErrors(["The rate table file has no valid rows."]);
        setSaving(false);
        return;
      }
      if (!rules.rules.some((rule) => rule.is_fuel)) {
        setErrors([
          "The surcharge file must include the current UPS fuel rule (is_fuel = true); otherwise the estimate would omit fuel.",
        ]);
        setSaving(false);
        return;
      }

      dataset = await base44.entities.RateDataset.create({
        version: meta.version.trim(),
        source_name: meta.source_name.trim() || "UPS published rate data",
        source_url: meta.source_url.trim() || UPS_SOURCE,
        service: "UPS Ground",
        rate_basis: "retail",
        origin_zip: originZip,
        effective_from: meta.effective_from,
        effective_to: meta.effective_to || "",
        status: "retired",
        imported_at: new Date().toISOString(),
        dim_divisor: Number(meta.dim_divisor) || 139,
        min_billable_lb: 1,
        max_weight_lb: Number(meta.max_weight_lb) || rate.maxWeight || 150,
        max_length_in: Number(meta.max_length_in) || 108,
        max_length_plus_girth_in: Number(meta.max_length_plus_girth_in) || 165,
        requires_fuel_rule: true,
        zone_rows: zone.rows.length,
        rate_rows: rate.tables.length,
        rule_rows: rules.rules.length,
        notes: meta.notes.trim(),
      });

      await base44.entities.RateZone.bulkCreate(
        zone.rows.map((row) => ({
          dataset_id: dataset.id,
          zone: row.zone,
          zip3_list: row.zip3_list,
        }))
      );
      await base44.entities.RateTable.bulkCreate(
        rate.tables.map((table) => ({
          dataset_id: dataset.id,
          zone: table.zone,
          rates_cents: table.rates_cents,
        }))
      );
      if (rules.rules.length > 0) {
        await base44.entities.SurchargeRule.bulkCreate(
          rules.rules.map((rule) => ({ ...rule, dataset_id: dataset.id }))
        );
      }
      await activateDataset(dataset.id);

      setResult({
        zones: zone.rows.length,
        prefixes: zone.prefixCount,
        zonesPriced: rate.tables.length,
        rules: rules.rules.length,
        maxWeight: rate.maxWeight,
      });
      setFiles({ zoneChart: null, rateTable: null, rules: null });
      onImported();
    } catch (error) {
      if (dataset?.id) {
        await base44.entities.RateZone.deleteMany({ dataset_id: dataset.id }).catch(() => {});
        await base44.entities.RateTable.deleteMany({ dataset_id: dataset.id }).catch(() => {});
        await base44.entities.SurchargeRule.deleteMany({ dataset_id: dataset.id }).catch(() => {});
        await base44.entities.RateDataset.delete(dataset.id).catch(() => {});
      }
      setErrors([`The import could not be completed. ${error?.message || ""}`.trim()]);
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="border border-border bg-card p-6">
      <h2 className="font-heading text-lg font-semibold uppercase tracking-[0.04em]">
        Import a UPS rate dataset
      </h2>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
        Download the retail rate guide and the zone chart for origin{" "}
        <span className="font-mono text-foreground">{originZip || "—"}</span> from the official UPS
        page, convert them to the CSV layouts below, and import. The dataset is stored with its
        source, service, rate basis, effective dates, version and import date.
      </p>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <label className="block">
          <span className={LABEL}>Version label</span>
          <input
            value={meta.version}
            onChange={(event) => setField("version", event.target.value)}
            placeholder="2026-retail-sep"
            className={`mt-1.5 ${FIELD}`}
          />
        </label>
        <label className="block">
          <span className={LABEL}>Source name</span>
          <input
            value={meta.source_name}
            onChange={(event) => setField("source_name", event.target.value)}
            className={`mt-1.5 ${FIELD}`}
          />
        </label>
        <label className="block sm:col-span-2">
          <span className={LABEL}>Source URL</span>
          <input
            value={meta.source_url}
            onChange={(event) => setField("source_url", event.target.value)}
            className={`mt-1.5 ${FIELD}`}
          />
        </label>
        <label className="block">
          <span className={LABEL}>Effective from</span>
          <input
            type="date"
            value={meta.effective_from}
            onChange={(event) => setField("effective_from", event.target.value)}
            className={`mt-1.5 ${FIELD}`}
          />
        </label>
        <label className="block">
          <span className={LABEL}>Effective to (optional)</span>
          <input
            type="date"
            value={meta.effective_to}
            onChange={(event) => setField("effective_to", event.target.value)}
            className={`mt-1.5 ${FIELD}`}
          />
        </label>
        <label className="block">
          <span className={LABEL}>Dim divisor</span>
          <input
            value={meta.dim_divisor}
            onChange={(event) => setField("dim_divisor", event.target.value.replace(/[^0-9.]/g, ""))}
            className={`mt-1.5 ${FIELD}`}
          />
        </label>
        <label className="block">
          <span className={LABEL}>Max billable weight (lb)</span>
          <input
            value={meta.max_weight_lb}
            onChange={(event) => setField("max_weight_lb", event.target.value.replace(/[^0-9.]/g, ""))}
            className={`mt-1.5 ${FIELD}`}
          />
        </label>
        <label className="block">
          <span className={LABEL}>Max length (in)</span>
          <input
            value={meta.max_length_in}
            onChange={(event) => setField("max_length_in", event.target.value.replace(/[^0-9.]/g, ""))}
            className={`mt-1.5 ${FIELD}`}
          />
        </label>
        <label className="block">
          <span className={LABEL}>Max length + girth (in)</span>
          <input
            value={meta.max_length_plus_girth_in}
            onChange={(event) =>
              setField("max_length_plus_girth_in", event.target.value.replace(/[^0-9.]/g, ""))
            }
            className={`mt-1.5 ${FIELD}`}
          />
        </label>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        <label className="block">
          <span className={LABEL}>Zone chart CSV</span>
          <input
            type="file"
            accept=".csv,text/csv"
            onChange={(event) => setFiles((p) => ({ ...p, zoneChart: event.target.files?.[0] ?? null }))}
            className="mt-1.5 w-full font-mono text-[10px] text-muted-foreground"
          />
          <span className="mt-1 block font-mono text-[9px] uppercase tracking-[0.12em] text-muted-foreground">
            zip3_start, zip3_end, zone
          </span>
        </label>
        <label className="block">
          <span className={LABEL}>Rate table CSV</span>
          <input
            type="file"
            accept=".csv,text/csv"
            onChange={(event) => setFiles((p) => ({ ...p, rateTable: event.target.files?.[0] ?? null }))}
            className="mt-1.5 w-full font-mono text-[10px] text-muted-foreground"
          />
          <span className="mt-1 block font-mono text-[9px] uppercase tracking-[0.12em] text-muted-foreground">
            zone, weight_lb, rate_usd
          </span>
        </label>
        <label className="block">
          <span className={LABEL}>Surcharge rules CSV</span>
          <input
            type="file"
            accept=".csv,text/csv"
            onChange={(event) => setFiles((p) => ({ ...p, rules: event.target.files?.[0] ?? null }))}
            className="mt-1.5 w-full font-mono text-[10px] text-muted-foreground"
          />
          <span className="mt-1 block font-mono text-[9px] uppercase tracking-[0.12em] text-muted-foreground">
            code, label, kind, value, is_fuel…
          </span>
        </label>
      </div>

      {errors.length > 0 && (
        <ul className="mt-5 space-y-1 border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs leading-relaxed text-destructive">
          {errors.map((message) => (
            <li key={message}>{message}</li>
          ))}
        </ul>
      )}

      {result && (
        <p className="mt-5 border border-primary/40 bg-primary/5 px-3 py-2 text-xs leading-relaxed text-foreground">
          Imported {result.prefixes} ZIP prefixes in {result.zones} zones, {result.zonesPriced} rate
          columns up to {result.maxWeight} lb, and {result.rules} surcharge rules. This dataset is now
          used for estimates.
        </p>
      )}

      <button
        type="button"
        onClick={handleImport}
        disabled={saving}
        className="mt-5 inline-flex items-center gap-2 bg-accent px-5 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-accent-foreground disabled:opacity-60"
      >
        {saving && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
        Import dataset
      </button>
    </section>
  );
}