import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2 } from "lucide-react";

const FIELD =
  "w-full border border-border bg-card px-3 py-2.5 font-mono text-[12px] outline-none transition-colors focus:border-primary";
const LABEL = "font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground";

export default function SettingsCard({ settings, onSaved }) {
  const [originZip, setOriginZip] = useState(settings?.origin_zip || "91340");
  const [handling, setHandling] = useState((((settings?.handling_cents ?? 300) || 0) / 100).toFixed(2));
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");

  useEffect(() => {
    setOriginZip(settings?.origin_zip || "91340");
    setHandling((((settings?.handling_cents ?? 300) || 0) / 100).toFixed(2));
  }, [settings?.id, settings?.origin_zip, settings?.handling_cents]);

  const save = async () => {
    setError("");
    const zip = originZip.replace(/\D/g, "");
    if (zip.length !== 5) {
      setError("Enter a 5-digit ship-from ZIP.");
      return;
    }
    const cents = Math.round(Number(handling) * 100);
    if (!Number.isFinite(cents) || cents < 0) {
      setError("Enter a valid handling fee.");
      return;
    }
    setStatus("saving");
    try {
      const payload = {
        origin_zip: zip,
        origin_country: "US",
        currency: "USD",
        service: "UPS Ground",
        rate_basis: "retail",
        handling_cents: cents,
      };
      if (settings?.id) {
        await base44.entities.ShippingSettings.update(settings.id, payload);
      } else {
        await base44.entities.ShippingSettings.create(payload);
      }
      setStatus("idle");
      onSaved();
    } catch (err) {
      setStatus("idle");
      setError("Settings could not be saved.");
    }
  };

  return (
    <section className="border border-border bg-card p-6">
      <h2 className="font-heading text-lg font-semibold uppercase tracking-[0.04em]">
        Business shipping settings
      </h2>
      <p className="mt-2 text-sm text-muted-foreground">
        Only an administrator can change the ship-from ZIP. The handling fee is added once per
        shipment, on top of the UPS estimate.
      </p>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <label className="block">
          <span className={LABEL}>Ship-from ZIP</span>
          <input
            value={originZip}
            onChange={(event) => setOriginZip(event.target.value.replace(/[^0-9]/g, "").slice(0, 5))}
            inputMode="numeric"
            className={`mt-1.5 ${FIELD}`}
          />
        </label>
        <label className="block">
          <span className={LABEL}>Handling fee (USD)</span>
          <input
            value={handling}
            onChange={(event) => setHandling(event.target.value.replace(/[^0-9.]/g, ""))}
            inputMode="decimal"
            className={`mt-1.5 ${FIELD}`}
          />
        </label>
        <div className="sm:col-span-2 grid gap-1 font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
          <span>Currency · USD</span>
          <span>Service · UPS Ground retail</span>
          <span>Coverage · contiguous United States</span>
        </div>
      </div>

      {error && (
        <p className="mt-4 border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive">
          {error}
        </p>
      )}

      <button
        type="button"
        onClick={save}
        disabled={status === "saving"}
        className="mt-5 inline-flex items-center gap-2 bg-accent px-5 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-accent-foreground disabled:opacity-60"
      >
        {status === "saving" && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
        Save settings
      </button>
    </section>
  );
}