import { useState } from "react";
import { Loader2 } from "lucide-react";
import { activateDataset, deleteDataset } from "@/lib/rateDataset";

export default function DatasetList({ datasets, onChanged }) {
  const [busyId, setBusyId] = useState("");
  const [error, setError] = useState("");

  const run = async (datasetId, action) => {
    setBusyId(datasetId);
    setError("");
    try {
      if (action === "activate") await activateDataset(datasetId);
      else await deleteDataset(datasetId);
      onChanged();
    } catch (err) {
      setError("That change could not be saved.");
    } finally {
      setBusyId("");
    }
  };

  return (
    <section className="border border-border bg-card p-6">
      <h2 className="font-heading text-lg font-semibold uppercase tracking-[0.04em]">
        Imported rate datasets
      </h2>
      <p className="mt-2 text-sm text-muted-foreground">
        One dataset is active at a time. Estimates use the active dataset whose effective dates cover
        the shipping date.
      </p>

      {datasets.length === 0 ? (
        <p className="mt-5 border border-border bg-secondary px-3 py-3 text-sm text-muted-foreground">
          No rate data imported yet. Until a dataset is loaded, estimates show the missing setup.
        </p>
      ) : (
        <div className="mt-5 divide-y divide-border border-y border-border">
          {datasets.map((dataset) => (
            <div key={dataset.id} className="flex flex-wrap items-center justify-between gap-4 py-4">
              <div className="min-w-[220px]">
                <div className="flex items-center gap-2">
                  <span className="font-heading text-sm font-semibold uppercase tracking-[0.04em]">
                    {dataset.version}
                  </span>
                  <span
                    className={`border px-2 py-0.5 font-mono text-[9px] uppercase tracking-[0.16em] ${
                      dataset.status === "active"
                        ? "border-primary/50 text-primary"
                        : "border-border text-muted-foreground"
                    }`}
                  >
                    {dataset.status}
                  </span>
                </div>
                <div className="mt-1 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                  {dataset.source_name} · origin {dataset.origin_zip} · {dataset.rate_basis}
                </div>
                <div className="mt-1 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                  Effective {dataset.effective_from || "—"}
                  {dataset.effective_to ? ` to ${dataset.effective_to}` : ""} · {dataset.zone_rows} zones ·{" "}
                  {dataset.rate_rows} rate columns · {dataset.rule_rows} rules
                </div>
              </div>

              <div className="flex items-center gap-3">
                {dataset.status !== "active" && (
                  <button
                    type="button"
                    onClick={() => run(dataset.id, "activate")}
                    disabled={busyId === dataset.id}
                    className="inline-flex items-center gap-2 border border-border px-4 py-2 font-mono text-[9px] uppercase tracking-[0.16em] transition-colors hover:border-primary/60 hover:text-primary disabled:opacity-50"
                  >
                    {busyId === dataset.id && <Loader2 className="h-3 w-3 animate-spin" />}
                    Use for estimates
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => run(dataset.id, "delete")}
                  disabled={busyId === dataset.id}
                  className="font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground transition-colors hover:text-destructive disabled:opacity-50"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {error && (
        <p className="mt-4 border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive">
          {error}
        </p>
      )}
    </section>
  );
}