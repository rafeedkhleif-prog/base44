import { Loader2 } from "lucide-react";
import { formatCents } from "@/lib/formatCents";

const FIELD =
  "w-full border border-border bg-card px-3 py-2.5 font-mono text-[12px] text-foreground outline-none transition-colors focus:border-primary";
const LABEL =
  "font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground";

const FIELDS = [
  { key: "weightLbs", label: "Packed weight (lb)", step: "0.1" },
  { key: "lengthIn", label: "Length (in)", step: "0.1" },
  { key: "widthIn", label: "Width (in)", step: "0.1" },
  { key: "heightIn", label: "Height (in)", step: "0.1" },
];

export default function ShippingEstimator({
  inputs,
  onChange,
  fromZip,
  status,
  estimate,
  message,
  onCalculate,
  complete,
}) {
  const calculating = status === "calculating";

  return (
    <div className="border-b border-border px-6 py-6">
      <div className="flex items-baseline justify-between gap-4">
        <div className="font-mono text-[9px] uppercase tracking-[0.24em] text-muted-foreground">
          Shipping estimate
        </div>
        <div className="font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
          From {fromZip || "—"}
        </div>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <label className="block">
          <span className={LABEL}>Destination ZIP</span>
          <input
            value={inputs.toZip}
            onChange={(event) => onChange("toZip", event.target.value.replace(/[^0-9]/g, "").slice(0, 5))}
            inputMode="numeric"
            placeholder="90001"
            className={`mt-1.5 ${FIELD}`}
          />
        </label>
        <label className="block">
          <span className={LABEL}>Destination type</span>
          <select
            value={inputs.destinationType}
            onChange={(event) => onChange("destinationType", event.target.value)}
            className={`mt-1.5 ${FIELD}`}
          >
            <option value="residential">Residential</option>
            <option value="commercial">Commercial</option>
          </select>
        </label>
        {FIELDS.map((field) => (
          <label key={field.key} className="block">
            <span className={LABEL}>{field.label}</span>
            <input
              value={inputs[field.key]}
              onChange={(event) =>
                onChange(field.key, event.target.value.replace(/[^0-9.]/g, ""))
              }
              inputMode="decimal"
              step={field.step}
              className={`mt-1.5 ${FIELD}`}
            />
          </label>
        ))}
      </div>

      <button
        type="button"
        onClick={() => onCalculate(inputs)}
        disabled={calculating || !complete}
        className="mt-4 flex w-full items-center justify-center gap-2 border border-border px-4 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-foreground transition-colors hover:border-primary/60 hover:text-primary disabled:cursor-not-allowed disabled:opacity-50"
      >
        {calculating ? (
          <>
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            Calculating
          </>
        ) : (
          "Calculate shipping"
        )}
      </button>

      {status === "ready" && estimate && (
        <dl className="mt-5 space-y-2 border-t border-border pt-4">
          <div className="flex items-center justify-between gap-4">
            <dt className="text-xs text-muted-foreground">Estimated UPS shipping</dt>
            <dd className="font-mono text-xs">{formatCents(estimate.upsCents)}</dd>
          </div>
          <div className="flex items-center justify-between gap-4">
            <dt className="text-xs text-muted-foreground">Handling fee</dt>
            <dd className="font-mono text-xs">{formatCents(estimate.handlingCents)}</dd>
          </div>
          <div className="flex items-center justify-between gap-4 border-t border-border pt-2">
            <dt className="font-mono text-[9px] uppercase tracking-[0.18em] text-foreground">
              Total shipping charge
            </dt>
            <dd className="font-mono text-sm text-primary">{formatCents(estimate.totalCents)}</dd>
          </div>
          <p className="pt-1 text-[11px] leading-relaxed text-muted-foreground">
            Estimated shipping. Based on published UPS rates. Final carrier charges may vary.
          </p>
        </dl>
      )}

      {status === "unavailable" && message && (
        <p className="mt-4 border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs leading-relaxed text-destructive">
          {message}
        </p>
      )}
    </div>
  );
}