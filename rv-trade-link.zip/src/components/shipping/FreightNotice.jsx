import { Truck } from "lucide-react";

export default function FreightNotice() {
  return (
    <div className="border-b border-border px-6 py-6">
      <div className="flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.24em] text-muted-foreground">
        <Truck className="h-3.5 w-3.5" />
        Freight shipping
      </div>
      <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
        Packed weight and dimensions are not on file for this unit, so it ships as freight. Freight
        is quoted after your order and charged separately — it is not included in the price shown.
      </p>
      <p className="mt-3 font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
        We will contact you to arrange the freight quote
      </p>
    </div>
  );
}