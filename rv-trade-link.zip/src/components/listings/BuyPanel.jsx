import { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ArrowRight, Loader2, Lock, Phone, ShoppingCart } from "lucide-react";
import useCart from "@/hooks/useCart";
import { addToCart } from "@/lib/cart";
import { formatPriceExact } from "@/lib/format";
import { formatCents } from "@/lib/formatCents";
import useShippingEstimate from "@/hooks/useShippingEstimate";
import ShippingEstimator from "@/components/shipping/ShippingEstimator";
import FreightNotice from "@/components/shipping/FreightNotice";
import ItemOnlyPaymentNotice from "@/components/listings/ItemOnlyPaymentNotice";
import MakeOfferDialog from "@/components/listings/MakeOfferDialog";
import { needsFreight } from "@/lib/freight";

export default function BuyPanel({ listing }) {
  const inStock = listing.quantity ?? 1;
  const sold = listing.status === "sold" || inStock < 1;
  // Priced over the phone: no amount, no shipping estimate, no online checkout.
  const callForPrice = Boolean(listing.price_on_request);
  const freight = needsFreight(listing);
  const shipping = useShippingEstimate(listing);
  const inCart = useCart().includes(listing.id);
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");

  const rated = shipping.status === "ready" && Boolean(shipping.estimate);
  // No shipping charge can be produced for this unit: freight units, or a shipment the published
  // tariff cannot price. The buyer can still take the unit; shipping is invoiced separately, so a
  // missing estimate never blocks the purchase.
  const invoiceLater = freight || shipping.status === "unavailable";
  const orderTotalCents = rated
    ? Math.round(Number(listing.price || 0) * 100) + shipping.estimate.totalCents
    : null;

  const handleBuy = async () => {
    setStatus("loading");
    setError("");
    try {
      const response = await base44.functions.invoke("create-checkout", {
        productId: listing.id,
        ...shipping.inputs,
        ...(rated ? {} : { shippingLater: true }),
      });
      const redirectUrl = response?.data?.redirectUrl;
      if (!redirectUrl) throw new Error("No checkout URL returned");
      window.location.href = redirectUrl;
    } catch (err) {
      setStatus("idle");
      setError(
        err?.response?.data?.error ||
          "Checkout could not start. Please call 1-818-899-8090 and we will complete your order."
      );
    }
  };

  return (
    <div className="border border-border bg-card">
      <div className="border-b border-border px-6 py-6">
        <div className="font-mono text-[9px] uppercase tracking-[0.24em] text-muted-foreground">
          Asking price
        </div>
        <div
          className={`mt-2 font-heading font-semibold tracking-tight ${
            callForPrice ? "text-2xl uppercase" : "text-4xl"
          }`}
        >
          {callForPrice ? "Call for price" : formatPriceExact(listing.price)}
        </div>
        <div className="mt-2 font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
          {sold
            ? "Sold"
            : callForPrice
              ? "Pricing and availability confirmed by phone"
              : freight
                ? "Price excludes freight · quoted and charged separately"
                : "Price excludes shipping · estimated by delivery ZIP"}
        </div>
        <div className="mt-3 inline-flex items-center gap-2 border border-border px-2 py-1 font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
          <span className={`h-1.5 w-1.5 ${inStock > 0 ? "bg-primary" : "bg-muted-foreground"}`} />
          {inStock > 0 ? `${inStock} in stock` : "Out of stock"}
        </div>
      </div>

      {!callForPrice &&
        (freight ? (
          <FreightNotice />
        ) : (
          <ShippingEstimator
            inputs={shipping.inputs}
            onChange={shipping.updateInput}
            fromZip={shipping.fromZip || "91340"}
            status={shipping.status}
            estimate={shipping.estimate}
            message={shipping.message}
            onCalculate={shipping.calculate}
            complete={shipping.complete}
          />
        ))}

      <div className="px-6 py-6">
        {invoiceLater && !sold && !callForPrice && <ItemOnlyPaymentNotice />}

        {orderTotalCents !== null && !sold && !callForPrice && (
          <div className="mb-4 flex items-baseline justify-between gap-4 border-b border-border pb-4">
            <span className="font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">
              Unit plus shipping
            </span>
            <span className="font-mono text-sm">{formatCents(orderTotalCents)}</span>
          </div>
        )}

        {callForPrice && !sold && (
          <a
            href="tel:+18188998090"
            className="flex w-full items-center justify-center gap-2 bg-accent px-6 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-accent-foreground transition-opacity hover:opacity-90"
          >
            <Phone className="h-3.5 w-3.5" />
            Call 1-818-899-8090
          </a>
        )}

        <button
          type="button"
          onClick={handleBuy}
          hidden={callForPrice}
          disabled={sold || status === "loading"}
          className="flex w-full items-center justify-center gap-2 bg-accent px-6 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-accent-foreground transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {status === "loading" ? (
            <>
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
              Starting checkout
            </>
          ) : sold ? (
            "No longer available"
          ) : (
            <>
              {invoiceLater ? "Buy now · shipping invoiced later" : "Buy now"}
              <ArrowRight className="h-3.5 w-3.5" />
            </>
          )}
        </button>

        {!sold && !callForPrice && (inCart ? (
          <Link
            to="/cart"
            className="mt-3 flex w-full items-center justify-center gap-2 border border-primary/50 px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-primary transition-colors hover:border-primary"
          >
            <ShoppingCart className="h-3.5 w-3.5" />
            In cart — view cart
          </Link>
        ) : (
          <button
            type="button"
            onClick={() => addToCart(listing.id)}
            className="mt-3 flex w-full items-center justify-center gap-2 border border-border px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-foreground transition-colors hover:border-primary hover:text-primary"
          >
            <ShoppingCart className="h-3.5 w-3.5" />
            Add to cart
          </button>
        ))}

        {error && (
          <p className="mt-4 border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs leading-relaxed text-destructive">
            {error}
          </p>
        )}

        {!callForPrice && (
          <p className="mt-4 flex items-center justify-center gap-2 font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">
            <Lock className="h-3 w-3" />
            Secure checkout · card payment
          </p>
        )}

        {!sold && !callForPrice && (
          <div className="mt-4">
            <MakeOfferDialog listing={listing} />
          </div>
        )}

        <div className="mt-6 border-t border-border pt-5">
          <div className="font-mono text-[9px] uppercase tracking-[0.24em] text-muted-foreground">
            Questions on this unit
          </div>
          <a href="tel:+18188998090" className="mt-2 block font-heading text-base hover:text-primary">
            1-818-899-8090
          </a>
          <a
            href="mailto:info@medicalrv.com"
            className="mt-1 block text-sm text-muted-foreground hover:text-primary"
          >
            info@medicalrv.com
          </a>
        </div>
      </div>
    </div>
  );
}