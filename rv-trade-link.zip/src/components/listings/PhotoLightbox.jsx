import { ChevronLeft, ChevronRight } from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import MagnifyingImage from "@/components/listings/MagnifyingImage";

export default function PhotoLightbox({ open, onOpenChange, photos, index, onIndexChange, title }) {
  const total = photos?.length ?? 0;
  if (!total) return null;

  const current = photos[index] ?? photos[0];
  const step = (delta) => onIndexChange((index + delta + total) % total);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[95vw] max-w-5xl gap-0 overflow-hidden border-border bg-background p-0" aria-describedby={undefined}>
        <DialogTitle className="sr-only">{title}</DialogTitle>
        <div className="relative h-[70vh] w-full bg-card">
          <MagnifyingImage
            key={current}
            src={current}
            alt={`${title} photo ${index + 1}`}
          />
          {total > 1 && (
            <>
              <button
                type="button"
                onClick={() => step(-1)}
                aria-label="Previous photo"
                className="absolute left-3 top-1/2 grid h-10 w-10 -translate-y-1/2 place-items-center border border-border bg-background/90 text-foreground transition-colors hover:border-primary hover:text-primary"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => step(1)}
                aria-label="Next photo"
                className="absolute right-3 top-1/2 grid h-10 w-10 -translate-y-1/2 place-items-center border border-border bg-background/90 text-foreground transition-colors hover:border-primary hover:text-primary"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </>
          )}
        </div>
        <div className="flex items-center justify-between gap-4 border-t border-border px-4 py-3">
          <span className="truncate font-heading text-sm font-semibold uppercase tracking-[0.02em]">
            {title}
          </span>
          <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            {index + 1} / {total}
          </span>
        </div>
      </DialogContent>
    </Dialog>
  );
}