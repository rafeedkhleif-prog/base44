import { useState } from "react";
import { Maximize2, Play } from "lucide-react";
import { Image } from "@/components/ui/image";
import { publicMediaUrls } from "@/lib/media";
import PhotoLightbox from "@/components/listings/PhotoLightbox";
import MagnifyingImage from "@/components/listings/MagnifyingImage";

export default function ListingGallery({ images = [], videoUrl, title, fallbackImage }) {
  const [active, setActive] = useState(0);
  const [zoomOpen, setZoomOpen] = useState(false);
  // Refurbished units without their own photos show the catalogue photo.
  const photos = publicMediaUrls(images);
  if (!photos.length && fallbackImage) photos.push(fallbackImage);
  const items = [
    ...photos.map((src) => ({ type: "photo", src })),
    ...(videoUrl ? [{ type: "video", src: videoUrl }] : []),
  ];

  if (!items.length) {
    return (
      <div className="grid aspect-[4/3] place-items-center border border-border bg-card font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
        No photos provided
      </div>
    );
  }

  const current = items[active] || items[0];

  return (
    <div>
      <div className="relative aspect-[4/3] overflow-hidden border border-border bg-card">
        {current.type === "video" ? (
          <video
            key={current.src}
            src={current.src}
            controls
            playsInline
            className="h-full w-full bg-accent object-contain"
          />
        ) : (
          <>
            <MagnifyingImage
              key={current.src}
              src={current.src}
              alt={`${title} photo ${active + 1}`}
            />
            <button
              type="button"
              onClick={() => setZoomOpen(true)}
              aria-label={`Open full-screen photos of ${title}`}
              className="absolute bottom-3 right-3 z-10 inline-flex items-center gap-1.5 border border-border bg-background/90 px-2 py-1 font-mono text-[9px] uppercase tracking-[0.18em] text-foreground backdrop-blur transition-colors hover:border-primary hover:text-primary"
            >
              <Maximize2 className="h-3 w-3" />
              Full screen
            </button>
          </>
        )}
      </div>
      {items.length > 1 && (
        <div className="mt-3 grid grid-cols-5 gap-2 sm:gap-3">
          {items.map((item, index) => (
            <button
              key={item.src}
              type="button"
              onClick={() => setActive(index)}
              aria-label={item.type === "video" ? "Play video" : `Show photo ${index + 1}`}
              className={`aspect-square overflow-hidden border transition-colors ${
                index === active ? "border-primary" : "border-border opacity-70 hover:opacity-100"
              }`}
            >
              {item.type === "video" ? (
                <span className="grid h-full w-full place-items-center bg-accent text-accent-foreground">
                  <Play className="h-4 w-4" />
                </span>
              ) : (
                <Image src={item.src} alt="" fittingType="fit" className="h-full w-full bg-card object-contain" />
              )}
            </button>
          ))}
        </div>
      )}

      {photos.length > 0 && (
        <PhotoLightbox
          open={zoomOpen}
          onOpenChange={setZoomOpen}
          photos={photos}
          index={Math.min(active, photos.length - 1)}
          onIndexChange={setActive}
          title={title}
        />
      )}
    </div>
  );
}