import { ChevronLeft, ChevronRight } from "lucide-react";

function pageItems(page, totalPages) {
  const numbers = new Set([1, totalPages, page, page - 1, page + 1]);
  if (page <= 3) [2, 3, 4].forEach((n) => numbers.add(n));
  if (page >= totalPages - 2) [totalPages - 1, totalPages - 2, totalPages - 3].forEach((n) => numbers.add(n));
  const sorted = [...numbers].filter((n) => n >= 1 && n <= totalPages).sort((a, b) => a - b);

  return sorted.reduce((acc, n, i) => {
    if (i > 0 && n - sorted[i - 1] > 1) acc.push(`gap-${n}`);
    acc.push(n);
    return acc;
  }, []);
}

export default function ListingPagination({ page, totalPages, onChange }) {
  if (totalPages <= 1) return null;

  const buttonBase =
    "grid h-10 min-w-10 place-items-center border border-border px-3 font-mono text-[11px] uppercase tracking-[0.16em] transition-colors";

  return (
    <nav className="mt-12 flex flex-wrap items-center justify-center gap-2">
      <button
        type="button"
        onClick={() => onChange(page - 1)}
        disabled={page <= 1}
        aria-label="Previous page"
        className={`${buttonBase} text-muted-foreground hover:border-primary/60 hover:text-primary disabled:pointer-events-none disabled:opacity-40`}
      >
        <ChevronLeft className="h-4 w-4" />
      </button>

      {pageItems(page, totalPages).map((item) =>
        typeof item === "number" ? (
          <button
            key={item}
            type="button"
            onClick={() => onChange(item)}
            aria-current={item === page ? "page" : undefined}
            className={
              item === page
                ? `${buttonBase} border-primary bg-primary text-primary-foreground`
                : `${buttonBase} text-muted-foreground hover:border-primary/60 hover:text-primary`
            }
          >
            {item}
          </button>
        ) : (
          <span key={item} className="px-2 font-mono text-[11px] text-muted-foreground">
            …
          </span>
        )
      )}

      <button
        type="button"
        onClick={() => onChange(page + 1)}
        disabled={page >= totalPages}
        aria-label="Next page"
        className={`${buttonBase} text-muted-foreground hover:border-primary/60 hover:text-primary disabled:pointer-events-none disabled:opacity-40`}
      >
        <ChevronRight className="h-4 w-4" />
      </button>

      <span className="ml-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
        Page {page} of {totalPages}
      </span>
    </nav>
  );
}