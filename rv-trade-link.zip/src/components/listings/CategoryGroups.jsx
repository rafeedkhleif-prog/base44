import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import ListingCard from "@/components/listings/ListingCard";
import { CATEGORIES } from "@/data/catalog";
import { isNewArrivalActive } from "@/lib/newArrival";

// Units shown per category before linking to that category's own page.
const PREVIEW = 6;

export default function CategoryGroups({ listings }) {
  const newArrivals = (listings ?? []).filter(isNewArrivalActive);
  const featured = new Set(newArrivals.map((listing) => listing.id));

  const buckets = new Map(CATEGORIES.map((cat) => [cat.slug, []]));
  const other = buckets.get("other-equipment");

  (listings ?? []).forEach((listing) => {
    if (featured.has(listing.id)) return;
    const bucket = buckets.get(listing.category);
    if (bucket) bucket.push(listing);
    else if (other) other.push(listing);
  });

  const groups = CATEGORIES.map((cat) => ({ ...cat, items: buckets.get(cat.slug) })).filter(
    (group) => group.items.length
  );

  return (
    <div className="space-y-16">
      {newArrivals.length > 0 && (
        <section>
          <div className="flex flex-wrap items-end justify-between gap-3 border-b border-border pb-3">
            <h2 className="font-heading text-xl font-semibold uppercase tracking-[0.02em] md:text-2xl">
              New arrivals
            </h2>
            <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-primary">
              {newArrivals.length} {newArrivals.length === 1 ? "unit" : "units"} just in
            </span>
          </div>
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {newArrivals.map((listing) => (
              <ListingCard key={listing.id} listing={listing} />
            ))}
          </div>
        </section>
      )}

      {groups.map((group) => (
        <section key={group.slug} id={`category-${group.slug}`}>
          <div className="flex flex-wrap items-end justify-between gap-3 border-b border-border pb-3">
            <h2 className="font-heading text-xl font-semibold uppercase tracking-[0.02em] md:text-2xl">
              {group.label}
            </h2>
            <div className="flex items-center gap-5">
              <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                {group.items.length} {group.items.length === 1 ? "unit" : "units"}
              </span>
              {group.items.length > PREVIEW && (
                <Link
                  to={`/equipment?category=${group.slug}`}
                  className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-primary transition-opacity hover:opacity-80"
                >
                  View all
                  <ArrowRight className="h-3 w-3" />
                </Link>
              )}
            </div>
          </div>
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {group.items.slice(0, PREVIEW).map((listing) => (
              <ListingCard key={listing.id} listing={listing} />
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}