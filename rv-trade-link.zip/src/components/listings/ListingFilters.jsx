import { Search } from "lucide-react";
import { CATEGORIES, CONDITIONS } from "@/data/catalog";

const SELECT_CLASS =
  "max-w-[230px] border border-input bg-background px-3 py-2.5 font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground outline-none focus:border-primary";

export default function ListingFilters({
  category,
  onCategoryChange,
  condition,
  onConditionChange,
  brand,
  brands,
  onBrandChange,
  search,
  onSearchChange,
  sort,
  onSortChange,
  resultCount,
}) {
  return (
    <div className="border-y border-border bg-card">
      <div className="mx-auto w-full max-w-7xl px-5 py-5 md:px-8">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative w-full lg:w-56">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input
              type="search"
              value={search}
              onChange={(event) => onSearchChange(event.target.value)}
              placeholder="Search equipment"
              aria-label="Search equipment"
              className="w-full border border-input bg-background py-2.5 pl-9 pr-3 font-mono text-[11px] uppercase tracking-[0.12em] outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary"
            />
          </div>

          <select
            value={category}
            onChange={(event) => onCategoryChange(event.target.value)}
            aria-label="Filter by category"
            className={SELECT_CLASS}
          >
            <option value="all">All categories</option>
            {CATEGORIES.map((cat) => (
              <option key={cat.slug} value={cat.slug}>
                {cat.label}
              </option>
            ))}
          </select>

          <select
            value={brand}
            onChange={(event) => onBrandChange(event.target.value)}
            aria-label="Filter by brand"
            className={SELECT_CLASS}
          >
            <option value="all">Any brand</option>
            {brands.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>

          <select
            value={condition}
            onChange={(event) => onConditionChange(event.target.value)}
            aria-label="Filter by condition"
            className={SELECT_CLASS}
          >
            <option value="all">Any condition</option>
            {CONDITIONS.map((item) => (
              <option key={item.value} value={item.value}>
                {item.label}
              </option>
            ))}
          </select>

          <label className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
            Arrange
            <select
              value={sort}
              onChange={(event) => onSortChange(event.target.value)}
              aria-label="Arrange inventory"
              className={SELECT_CLASS}
            >
              <option value="newest">Date posted · newest</option>
              <option value="oldest">Date posted · oldest</option>
              <option value="price-asc">Price · low to high</option>
              <option value="price-desc">Price · high to low</option>
            </select>
          </label>
        </div>

        <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
          {resultCount} {resultCount === 1 ? "unit" : "units"} available
        </p>
      </div>
    </div>
  );
}