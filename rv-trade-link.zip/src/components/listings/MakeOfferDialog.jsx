import { useState } from "react";
import { Link } from "react-router-dom";
import { Loader2, Tag } from "lucide-react";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { formatPriceExact } from "@/lib/format";

const FIELD =
  "w-full border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary";
const LABEL = "font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground";

export default function MakeOfferDialog({ listing }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    amount: "",
    buyer_name: "",
    buyer_email: "",
    buyer_phone: "",
    message: "",
    binding: false,
  });
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");
  const [token, setToken] = useState("");

  const setField = (field) => (event) =>
    setForm((current) => ({ ...current, [field]: event.target.value }));

  const submit = async (event) => {
    event.preventDefault();
    const amount = Number(form.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      setError("Enter the amount you would like to offer.");
      return;
    }
    if (!form.buyer_email.trim()) {
      setError("Enter an email so we can send our answer.");
      return;
    }
    if (!form.binding) {
      setError("Please confirm the offer is binding before sending it.");
      return;
    }
    setStatus("saving");
    setError("");
    try {
      const record = await base44.entities.Offer.create({
        listing_id: listing.id,
        listing_title: listing.title,
        asking_price: listing.price,
        buyer_name: form.buyer_name.trim(),
        buyer_email: form.buyer_email.trim().toLowerCase(),
        buyer_phone: form.buyer_phone.trim(),
        amount,
        message: form.message.trim(),
        binding_accepted: true,
        status: "pending",
        token: crypto.randomUUID(),
      });
      setToken(record.token);
      setStatus("sent");
    } catch (err) {
      setStatus("idle");
      setError(err?.message || "Your offer could not be sent. Please call 1-818-899-8090.");
    }
  };

  const reset = () => {
    setForm({
      amount: "",
      buyer_name: "",
      buyer_email: "",
      buyer_phone: "",
      message: "",
      binding: false,
    });
    setToken("");
    setStatus("idle");
    setError("");
    setOpen(false);
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (!next) reset();
        else setOpen(true);
      }}
    >
      <DialogTrigger asChild>
        <button
          type="button"
          className="flex w-full items-center justify-center gap-2 border border-border px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-foreground transition-colors hover:border-primary hover:text-primary"
        >
          <Tag className="h-3.5 w-3.5" />
          Make a best offer
        </button>
      </DialogTrigger>

      <DialogContent className="max-h-[90vh] overflow-y-auto border-border bg-card sm:max-w-lg">
        {status === "sent" ? (
          <>
            <DialogHeader>
              <DialogTitle className="font-heading text-xl uppercase">Offer sent</DialogTitle>
              <DialogDescription className="text-sm text-muted-foreground">
                We review every offer and reply by email. You can also follow the answer on your
                private offer page.
              </DialogDescription>
            </DialogHeader>
            <Link
              to={`/offer/${token}`}
              className="mt-5 inline-flex items-center justify-center bg-primary px-5 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-primary-foreground"
            >
              Track this offer
            </Link>
            <button
              type="button"
              onClick={reset}
              className="mt-3 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground hover:text-foreground"
            >
              Close
            </button>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="font-heading text-xl uppercase">Make a best offer</DialogTitle>
              <DialogDescription className="text-sm text-muted-foreground">
                {listing.title} · asking {formatPriceExact(listing.price)}
              </DialogDescription>
            </DialogHeader>

            <form onSubmit={submit} className="mt-5 space-y-4">
              <div>
                <label className={LABEL} htmlFor="offer-amount">
                  Your offer (USD)
                </label>
                <Input
                  id="offer-amount"
                  type="number"
                  min="1"
                  step="1"
                  value={form.amount}
                  onChange={setField("amount")}
                  className={`mt-1.5 ${FIELD}`}
                  placeholder="0"
                />
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className={LABEL} htmlFor="offer-name">
                    Name
                  </label>
                  <Input
                    id="offer-name"
                    value={form.buyer_name}
                    onChange={setField("buyer_name")}
                    className={`mt-1.5 ${FIELD}`}
                  />
                </div>
                <div>
                  <label className={LABEL} htmlFor="offer-email">
                    Email
                  </label>
                  <Input
                    id="offer-email"
                    type="email"
                    required
                    value={form.buyer_email}
                    onChange={setField("buyer_email")}
                    className={`mt-1.5 ${FIELD}`}
                  />
                </div>
              </div>
              <div>
                <label className={LABEL} htmlFor="offer-phone">
                  Phone (optional)
                </label>
                <Input
                  id="offer-phone"
                  value={form.buyer_phone}
                  onChange={setField("buyer_phone")}
                  className={`mt-1.5 ${FIELD}`}
                />
              </div>
              <div>
                <label className={LABEL} htmlFor="offer-message">
                  Message (optional)
                </label>
                <Textarea
                  id="offer-message"
                  rows={3}
                  value={form.message}
                  onChange={setField("message")}
                  className={`mt-1.5 ${FIELD}`}
                />
              </div>

              <label className="flex cursor-pointer items-start gap-3 border border-border bg-background px-3 py-3">
                <input
                  type="checkbox"
                  checked={form.binding}
                  onChange={(event) =>
                    setForm((current) => ({ ...current, binding: event.target.checked }))
                  }
                  className="mt-0.5 h-4 w-4 accent-[hsl(var(--primary))]"
                />
                <span className="text-[12px] leading-relaxed text-ink-body">
                  <b className="font-semibold">This offer is binding.</b> If we accept it, you agree
                  to pay the offered amount, and we email you a secure payment link to complete the
                  purchase. Shipping is quoted and invoiced separately.
                </span>
              </label>

              {error && (
                <p className="border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs leading-relaxed text-destructive">
                  {error}
                </p>
              )}

              <button
                type="submit"
                disabled={status === "saving"}
                className="flex w-full items-center justify-center gap-2 bg-accent px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-accent-foreground transition-opacity hover:opacity-90 disabled:opacity-50"
              >
                {status === "saving" ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    Sending
                  </>
                ) : (
                  "Send offer"
                )}
              </button>
              <p className="text-center font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
                Offers do not reserve the unit
              </p>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}