import { Link } from "react-router-dom";
import { Image } from "@/components/ui/image";
import { formatPrice } from "@/lib/format";
import { conditionLabel } from "@/data/catalog";
import { publicMediaUrl } from "@/lib/media";
import { listingPhoto } from "@/data/categoryPhotos";
import { isNewArrivalActive } from "@/lib/newArrival";
import ListingImageZoom from "@/components/listings/ListingImageZoom";

const badgeTone = {
  refurbished: "border-primary/50 text-primary",
  new: "border-foreground/40 text-foreground",
  used: "border-border text-muted-foreground",
  "for-parts": "border-destructive/50 text-destructive",
};

export default function ListingCard({ listing }) {
  // A listing shows its own photo when it has one, else its category photo.
  const image = publicMediaUrl(listingPhoto(listing));

  return (
    <div className="group relative flex flex-col border border-border bg-card transition-colors hover:border-primary/50">
      <div className="relative aspect-[4/3] overflow-hidden bg-card">
        {image ? (
          <Image
            src={image}
            alt={listing.title}
            fittingType="fit"
            className="h-full w-full object-contain"
          />
        ) : (
          <div className="grid h-full w-full place-items-center font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
            No image
          </div>
        )}
        <span
          className={`absolute left-1.5 top-1.5 border bg-background/80 px-1.5 py-0.5 font-mono text-[8px] uppercase tracking-[0.12em] backdrop-blur ${
            badgeTone[listing.condition] ?? badgeTone.refurbished
          }`}
        >
          {conditionLabel(listing.condition)}
        </span>

        {isNewArrivalActive(listing) && (
          <div className="pointer-events-none absolute inset-0 overflow-hidden">
            <span className="absolute right-[-40px] top-[12px] rotate-45 bg-primary px-10 py-0.5 text-center font-mono text-[8px] uppercase tracking-[0.16em] text-primary-foreground">
              New arrival
            </span>
          </div>
        )}

        {listing.images?.length > 0 && (
          <div className="absolute bottom-1.5 right-1.5 z-20">
            <ListingImageZoom images={listing.images} title={listing.title} />
          </div>
        )}
      </div>

      <div className="flex flex-1 flex-col p-3">
        <span className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.14em] text-muted-foreground">
          {listing.seller_photo_url && (
            <span className="h-4 w-4 shrink-0 overflow-hidden rounded-full border border-border bg-background">
              <Image
                src={listing.seller_photo_url}
                alt=""
                fittingType="fill"
                className="h-full w-full"
              />
            </span>
          )}
          {listing.brand}
        </span>
        <h3 className="mt-1.5 font-heading text-[13px] font-semibold uppercase leading-snug tracking-[0.01em]">
          {listing.title}
        </h3>
        <div className="mt-3 border-t border-border pt-2.5">
          <div className="flex items-end justify-between gap-2">
            <span className="font-mono text-[13px] text-primary">
              {listing.price_on_request ? "Call for price" : formatPrice(listing.price)}
            </span>
            <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-muted-foreground transition-colors group-hover:text-foreground">
              View
            </span>
          </div>
          <span className="mt-1.5 block font-mono text-[8px] uppercase leading-relaxed tracking-[0.1em] text-muted-foreground">
            Shipping estimated in app by delivery ZIP
          </span>
        </div>
      </div>

      <Link
        to={`/equipment/${listing.id}`}
        aria-label={`View ${listing.title}`}
        className="absolute inset-0 z-10"
      />
    </div>
  );
}