import { Search } from "lucide-react";
import { Image } from "@/components/ui/image";
import MagnifierLens from "@/components/listings/MagnifierLens";
import useMagnifier from "@/components/listings/useMagnifier";

export default function MagnifyingImage({ src, alt }) {
  const { host, image, lens, handlers } = useMagnifier();
  return (
    <div
      ref={host}
      role="button"
      tabIndex={0}
      aria-label={`Magnify ${alt}. Hover or hold and drag. For keyboard, press Enter and use arrow keys; Escape closes the lens.`}
      className="absolute inset-0 touch-none cursor-crosshair select-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-primary"
      {...handlers}
    >
      <Image ref={image} src={src} alt={alt} fittingType="fit" loading="eager" draggable={false} className="block h-full w-full bg-card object-contain" />
      {lens && <MagnifierLens src={src} lens={lens} />}
      <span aria-hidden="true" className="pointer-events-none absolute bottom-3 left-3 flex items-center gap-1.5 border border-border bg-background/90 px-2 py-1 font-mono text-[9px] uppercase tracking-[0.12em] text-foreground">
        <Search className="h-3 w-3" />
        <span className="hidden sm:inline">Hover for 3× lens</span>
        <span className="sm:hidden">Hold to magnify</span>
      </span>
    </div>
  );
}