import { Image } from "@/components/ui/image";

export default function MagnifierLens({ src, lens }) {
  const zoom = 3;
  const size = Math.min(220, lens.width * 0.65, lens.height * 0.65);
  const radius = size / 2;
  const left = Math.max(radius, Math.min(lens.width - radius, lens.x));
  const top = Math.max(radius, Math.min(lens.height - radius, lens.y));
  return (
    <div aria-hidden="true" className="pointer-events-none absolute z-20 overflow-hidden rounded-full border-2 border-primary bg-card shadow-2xl" style={{ width: size, height: size, left: left - radius, top: top - radius }}>
      <div className="absolute" style={{ width: lens.width * zoom, height: lens.height * zoom, left: radius - lens.x * zoom, top: radius - lens.y * zoom }}>
        <Image src={src} alt="" fittingType="fit" loading="eager" draggable={false} className="block h-full w-full bg-card object-contain" />
      </div>
      <span className="absolute bottom-2 left-1/2 -translate-x-1/2 bg-background/90 px-2 py-0.5 font-mono text-[10px] text-foreground">3×</span>
    </div>
  );
}