// Shown before a buyer pays for a unit that has no shipping charge at checkout: freight units and
// units the published tariff cannot price. The item is charged now, shipping is invoiced later.
export default function ItemOnlyPaymentNotice() {
  return (
    <div className="mb-4 border border-primary/40 bg-primary/5 px-4 py-3">
      <div className="font-mono text-[9px] uppercase tracking-[0.22em] text-primary">
        Payment scope
      </div>
      <p className="mt-2 text-[13px] leading-relaxed text-foreground">
        Your payment covers the item only. Freight or shipping charges will be calculated and
        invoiced separately.
      </p>
    </div>
  );
}