import { useRef, useState } from "react";

export default function useMagnifier() {
  const host = useRef(null);
  const image = useRef(null);
  const [lens, setLens] = useState(null);
  const inspect = (clientX, clientY) => {
    const rect = host.current?.getBoundingClientRect();
    const photo = image.current;
    if (!rect?.width || !photo?.naturalWidth) return;
    const x = clientX - rect.left, y = clientY - rect.top;
    const ratio = photo.naturalWidth / photo.naturalHeight;
    const width = Math.min(rect.width, rect.height * ratio);
    const height = Math.min(rect.height, rect.width / ratio);
    const left = (rect.width - width) / 2, top = (rect.height - height) / 2;
    if (x < left || x > left + width || y < top || y > top + height) {
      setLens(null);
      return;
    }
    setLens({ x, y, width: rect.width, height: rect.height });
  };
  const move = (event) => inspect(event.clientX, event.clientY);
  const onKeyDown = (event) => {
    if (event.key === "Escape") return setLens(null);
    const directions = { ArrowLeft: [-20, 0], ArrowRight: [20, 0], ArrowUp: [0, -20], ArrowDown: [0, 20] };
    const delta = directions[event.key];
    if (!delta && event.key !== "Enter" && event.key !== " ") return;
    event.preventDefault();
    const rect = host.current.getBoundingClientRect();
    inspect(rect.left + (lens?.x ?? rect.width / 2) + (delta?.[0] ?? 0), rect.top + (lens?.y ?? rect.height / 2) + (delta?.[1] ?? 0));
  };
  const handlers = {
    onPointerEnter: (event) => { if (event.pointerType === "mouse") move(event); },
    onPointerMove: move,
    onPointerDown: (event) => { event.currentTarget.setPointerCapture(event.pointerId); move(event); },
    onPointerUp: (event) => { if (event.pointerType !== "mouse") setLens(null); },
    onPointerCancel: () => setLens(null),
    onPointerLeave: () => setLens(null),
    onBlur: () => setLens(null),
    onKeyDown,
  };
  return { host, image, lens, handlers };
}