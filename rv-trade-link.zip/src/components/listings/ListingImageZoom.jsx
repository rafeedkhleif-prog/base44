import { useState } from "react";
import { Maximize2 } from "lucide-react";
import PhotoLightbox from "@/components/listings/PhotoLightbox";
import { publicMediaUrls } from "@/lib/media";

export default function ListingImageZoom({ images, title }) {
  const photos = publicMediaUrls(images);
  const [open, setOpen] = useState(false);
  const [index, setIndex] = useState(0);

  if (!photos.length) return null;

  return (
    <>
      <button
        type="button"
        onClick={() => {
          setIndex(0);
          setOpen(true);
        }}
        className="inline-flex items-center gap-1.5 border border-border bg-background/90 px-2 py-1 font-mono text-[9px] uppercase tracking-[0.18em] text-foreground backdrop-blur transition-colors hover:border-primary hover:text-primary"
        aria-label={`Zoom in on ${title}`}
      >
        <Maximize2 className="h-3 w-3" />
        Zoom
      </button>

      <PhotoLightbox
        open={open}
        onOpenChange={setOpen}
        photos={photos}
        index={index}
        onIndexChange={setIndex}
        title={title}
      />
    </>
  );
}