import { useEffect, useState } from "react";
import { Loader2, Upload, User, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Image } from "@/components/ui/image";

const labelClass = "font-mono text-[9px] uppercase tracking-[0.22em] text-muted-foreground";

/**
 * Chooses the profile photo shown beside the seller on this one listing.
 * The value lives in the listing form, so it is saved with the rest of the listing.
 */
export default function ListingProfilePhoto({ value, onChange, user }) {
  const [options, setOptions] = useState(() =>
    user?.profile_photo_url ? [user.profile_photo_url] : []
  );
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  // Photos already used on the seller's other listings, so they can be reused.
  useEffect(() => {
    if (!user?.id) return;
    let active = true;
    base44.entities.Listing.filter({ created_by_id: user.id }, { limit: 100 })
      .then(({ items }) => {
        if (!active) return;
        const used = items.map((item) => item.seller_photo_url).filter(Boolean);
        setOptions((prev) => Array.from(new Set([...prev, ...used])));
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [user?.id]);

  const handleUpload = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    setBusy(true);
    setError("");
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      setOptions((prev) => [file_url, ...prev.filter((option) => option !== file_url)]);
      onChange(file_url);
    } catch {
      setError("That photo could not be uploaded. Try a smaller image.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <p className={labelClass}>Profile photo on this listing</p>
      <div className="mt-3 flex flex-wrap items-center gap-4">
        <span className="grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-full border border-border bg-background text-muted-foreground">
          {value ? (
            <Image src={value} alt="Listing profile photo" fittingType="fill" className="h-full w-full" />
          ) : (
            <User className="h-5 w-5" />
          )}
        </span>

        {options.length > 0 && (
          <div className="flex flex-wrap items-center gap-2">
            {options.map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => onChange(option)}
                aria-label="Use this profile photo"
                className={`h-9 w-9 overflow-hidden rounded-full border transition-colors ${
                  option === value
                    ? "border-primary ring-2 ring-primary/30"
                    : "border-border hover:border-primary/60"
                }`}
              >
                <Image src={option} alt="" fittingType="fill" className="h-full w-full" />
              </button>
            ))}
          </div>
        )}

        <div className="flex items-center gap-3">
          <label className="inline-flex cursor-pointer items-center gap-2 border border-border px-4 py-2.5 font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground transition-colors hover:border-primary/60 hover:text-primary">
            {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Upload className="h-3 w-3" />}
            {value ? "Change" : "Upload"}
            <input
              type="file"
              accept="image/*"
              onChange={handleUpload}
              disabled={busy}
              className="hidden"
            />
          </label>
          {value && (
            <button
              type="button"
              onClick={() => onChange("")}
              aria-label="Remove profile photo"
              className="grid h-9 w-9 place-items-center border border-border text-muted-foreground transition-colors hover:border-destructive hover:text-destructive"
            >
              <X className="h-3 w-3" />
            </button>
          )}
        </div>
      </div>
      <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
        Shown as a small avatar beside the brand on this listing. Stored publicly — anyone with the
        link can open them.
      </p>
      {error && <p className="mt-2 text-xs text-destructive">{error}</p>}
    </div>
  );
}