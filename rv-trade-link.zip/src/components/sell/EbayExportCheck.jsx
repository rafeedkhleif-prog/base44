export default function EbayExportCheck({ prepared }) {
  if (!prepared) return null;
  return (
    <div className="mt-4 border border-border p-3 text-sm" role="status">
      <p>{prepared.items.length} listings · {prepared.matchedPhotos} of {prepared.totalPhotos} photos found</p>
      <p className="mt-1 text-xs text-muted-foreground">
        {prepared.exportPaths.length > 1 ? `${prepared.exportPaths.length} export files read:` : "Export read:"}
      </p>
      <ul className="mt-1 space-y-0.5 break-all text-xs text-muted-foreground">
        {prepared.exportPaths.map((path) => <li key={path}>{path}</li>)}
      </ul>
      {prepared.missingPaths.length > 0 && (
        <div className="mt-3 text-xs text-muted-foreground">
          <p>{prepared.missingPaths.length} photo file(s) are not in the selection. Every other photo still imports; these can be added to the listing by hand afterwards.</p>
          <ul className="mt-2 space-y-1 break-all text-xs">
            {prepared.missingPaths.slice(0, 5).map((path) => <li key={path}>{path}</li>)}
          </ul>
          {prepared.missingPaths.length > 5 && <p className="mt-1 text-xs">And {prepared.missingPaths.length - 5} more missing files.</p>}
        </div>
      )}
      {prepared.withoutGallery.length > 0 && <p className="mt-3 text-xs text-muted-foreground">No photos were found for: {prepared.withoutGallery.join(", ")}. These listings import without photos.</p>}
      {prepared.canImport && <p className="mt-2 text-xs text-muted-foreground">Ready to import.</p>}
    </div>
  );
}