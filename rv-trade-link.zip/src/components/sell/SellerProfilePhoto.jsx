import { useState } from "react";
import { Loader2, Upload, User } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Image } from "@/components/ui/image";
import { useAuth } from "@/lib/AuthContext";

export default function SellerProfilePhoto({ user }) {
  const { checkUserAuth } = useAuth();
  const [photo, setPhoto] = useState(user?.profile_photo_url || "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const save = async (url) => {
    if (!user?.id) return;
    await base44.auth.updateMe({ profile_photo_url: url });
    // Every listing the seller owns shows the same photo on the cards.
    await base44.entities.Listing.updateMany(
      { created_by_id: user.id },
      { $set: { seller_photo_url: url } }
    );
    setPhoto(url);
    await checkUserAuth();
  };

  const handleUpload = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    setBusy(true);
    setError("");
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      await save(file_url);
    } catch {
      setError("That photo could not be saved. Try a smaller image.");
    } finally {
      setBusy(false);
    }
  };

  const handleRemove = async () => {
    setBusy(true);
    setError("");
    try {
      await save("");
    } catch {
      setError("That photo could not be removed. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mb-10 flex flex-wrap items-center gap-5 border border-border bg-card px-6 py-5">
      <span className="grid h-16 w-16 shrink-0 place-items-center overflow-hidden rounded-full border border-border bg-background text-muted-foreground">
        {photo ? (
          <Image src={photo} alt="Seller profile photo" fittingType="fill" className="h-full w-full" />
        ) : (
          <User className="h-6 w-6" />
        )}
      </span>
      <div className="min-w-0 flex-1">
        <h2 className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
          Seller profile photo
        </h2>
        <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
          Shown on every listing you publish in Inventory and Refurbished. Stored publicly — anyone
          with the link can open them.
        </p>
        {error && <p className="mt-2 text-xs text-destructive">{error}</p>}
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <label
          className={`inline-flex cursor-pointer items-center gap-2 border border-border px-4 py-2.5 font-mono text-[9px] uppercase tracking-[0.18em] transition-colors ${
            busy ? "opacity-60" : "text-muted-foreground hover:border-primary/60 hover:text-primary"
          }`}
        >
          {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Upload className="h-3 w-3" />}
          {photo ? "Replace photo" : "Upload photo"}
          <input
            type="file"
            accept="image/*"
            onChange={handleUpload}
            disabled={busy}
            className="hidden"
          />
        </label>
        {photo && (
          <button
            type="button"
            onClick={handleRemove}
            disabled={busy}
            className="font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground transition-colors hover:text-destructive disabled:opacity-60"
          >
            Remove
          </button>
        )}
      </div>
    </div>
  );
}