import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { formatPrice } from "@/lib/format";
import { conditionLabel } from "@/data/catalog";

const PAGE_SIZE = 100;

const statusTone = {
  active: "text-primary",
  sold: "text-muted-foreground",
  archived: "text-muted-foreground",
};

export default function MyListings({ userId, refreshKey = 0 }) {
  const [listings, setListings] = useState([]);
  const [cursor, setCursor] = useState(null);
  const [hasMore, setHasMore] = useState(false);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);

  useEffect(() => {
    let active = true;
    if (!userId) return;
    setLoading(true);
    Promise.all([
      base44.entities.Listing.filter(
        { created_by_id: userId },
        { sort: "-created_date", limit: PAGE_SIZE }
      ),
      base44.entities.Listing.count({ created_by_id: userId }),
    ])
      .then(([page, count]) => {
        if (!active) return;
        setListings(page.items ?? []);
        setCursor(page.next_cursor ?? null);
        setHasMore(Boolean(page.has_more));
        setTotal(count ?? 0);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [userId, refreshKey]);

  const loadMore = async () => {
    setLoadingMore(true);
    try {
      const page = await base44.entities.Listing.filter(
        { created_by_id: userId },
        { sort: "-created_date", limit: PAGE_SIZE, ...(cursor ? { cursor } : {}) }
      );
      setListings((prev) => [...prev, ...(page.items ?? [])]);
      setCursor(page.next_cursor ?? null);
      setHasMore(Boolean(page.has_more));
    } finally {
      setLoadingMore(false);
    }
  };

  const handleDelete = async (id) => {
    await base44.entities.Listing.delete(id);
    setListings((prev) => prev.filter((item) => item.id !== id));
    setTotal((prev) => Math.max(0, prev - 1));
  };

  if (loading) return null;
  if (!listings.length) return null;

  return (
    <section className="mt-16 border-t border-border pt-10">
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <h2 className="font-mono text-[10px] uppercase tracking-[0.26em] text-muted-foreground">
          Your listings
        </h2>
        <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
          Showing {listings.length} of {total || listings.length}
        </span>
      </div>
      <div className="mt-4">
        {listings.map((item) => (
          <div
            key={item.id}
            className="flex flex-wrap items-center justify-between gap-3 border-b border-border py-4"
          >
            <div className="min-w-0">
              <Link
                to={`/equipment/${item.id}`}
                className="block truncate font-heading text-sm uppercase tracking-[0.03em] hover:text-primary"
              >
                {item.title}
              </Link>
              <div className="mt-1 font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">
                {conditionLabel(item.condition)} · {item.price_on_request ? "Call for price" : formatPrice(item.price)}
              </div>
            </div>
            <div className="flex items-center gap-5">
              <span
                className={`font-mono text-[9px] uppercase tracking-[0.2em] ${
                  statusTone[item.status] ?? "text-muted-foreground"
                }`}
              >
                {item.status}
              </span>
              <Link
                to={`/sell/${item.id}`}
                className="font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground transition-colors hover:text-primary"
              >
                Edit
              </Link>
              {item.status !== "sold" && (
                <button
                  type="button"
                  onClick={() => handleDelete(item.id)}
                  className="font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground transition-colors hover:text-destructive"
                >
                  Remove
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
      {hasMore && (
        <button
          type="button"
          onClick={loadMore}
          disabled={loadingMore}
          className="mt-6 inline-flex items-center justify-center gap-2 border border-border px-4 py-3 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground transition-colors hover:border-primary/60 hover:text-primary disabled:opacity-60"
        >
          {loadingMore ? (
            <>
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
              Loading
            </>
          ) : (
            `Load next ${PAGE_SIZE}`
          )}
        </button>
      )}
    </section>
  );
}