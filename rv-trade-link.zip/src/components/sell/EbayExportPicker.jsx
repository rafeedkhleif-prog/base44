import { useRef } from "react";
import { FileArchive, FolderUp } from "lucide-react";

const buttonClass = "inline-flex items-center justify-center gap-2 border border-border px-4 py-3 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground hover:border-primary/60 hover:text-primary disabled:opacity-60";

export default function EbayExportPicker({ disabled, onPick, onReset, hasFiles }) {
  const zipRef = useRef(null);
  const folderRef = useRef(null);
  const filesRef = useRef(null);
  return (
    <div className="mt-4 flex flex-wrap gap-3">
      <button type="button" disabled={disabled} className={buttonClass} onClick={() => zipRef.current?.click()}>
        <FileArchive className="h-3.5 w-3.5" /> Choose export ZIP
      </button>
      <button type="button" disabled={disabled} className={buttonClass} onClick={() => folderRef.current?.click()}>
        <FolderUp className="h-3.5 w-3.5" /> Choose export folder
      </button>
      <button type="button" disabled={disabled} className={buttonClass} onClick={() => filesRef.current?.click()}>Add files</button>
      {hasFiles && <button type="button" disabled={disabled} className={buttonClass} onClick={onReset}>Clear selection</button>}
      <input ref={zipRef} type="file" accept=".zip,application/zip,application/x-zip-compressed" disabled={disabled} onChange={(event) => onPick(event, true)} className="hidden" />
      <input ref={folderRef} type="file" multiple webkitdirectory="" disabled={disabled} onChange={(event) => onPick(event, false)} className="hidden" />
      <input ref={filesRef} type="file" multiple accept=".html,.htm,.json,.csv,image/*" disabled={disabled} onChange={(event) => onPick(event, false)} className="hidden" />
    </div>
  );
}