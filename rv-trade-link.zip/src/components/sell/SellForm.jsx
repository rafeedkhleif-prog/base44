import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Image as ImageIcon,
  Loader2,
  Plus,
  RotateCw,
  Save,
  Video as VideoIcon,
  X,
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { CATEGORIES, CONDITIONS } from "@/data/catalog";
import { Image } from "@/components/ui/image";
import { publicMediaUrl, publicMediaUrls } from "@/lib/media";
import { rotatedImageFile } from "@/lib/rotateImage";
import EbayListingImporter from "@/components/sell/EbayListingImporter";
import QuantityStepper from "@/components/sell/QuantityStepper";
import ListingProfilePhoto from "@/components/sell/ListingProfilePhoto";

const emptyForm = {
  title: "",
  brand: "",
  category: "",
  condition: "refurbished",
  price: "",
  weight_lbs: "",
  length_in: "",
  width_in: "",
  height_in: "",
  location: "",
  quantity: "1",
  description: "",
  new_arrival: false,
  new_arrival_since: "",
  seller_name: "MRI",
  seller_email: "",
  seller_phone: "8188998090",
  seller_photo_url: "",
};

const inputClass =
  "mt-2 w-full border border-input bg-background px-3 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-primary";
const labelClass = "font-mono text-[9px] uppercase tracking-[0.22em] text-muted-foreground";

const normalizeChoice = (value) =>
  String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();

function catalogChoice(raw, options, key) {
  const wanted = normalizeChoice(raw);
  if (!wanted) return "";
  return (
    options.find((item) =>
      [item.label, item[key]].some((value) => normalizeChoice(value) === wanted)
    )?.[key] || ""
  );
}

export default function SellForm({ user, listing = null, onPublished }) {
  const isEdit = Boolean(listing);
  const [form, setForm] = useState(
    listing
      ? {
          title: listing.title || "",
          brand: listing.brand || "",
          category: listing.category || "",
          condition: listing.condition || "refurbished",
          price: listing.price_on_request ? "" : listing.price ?? "",
          weight_lbs: listing.weight_lbs ?? "",
          length_in: listing.length_in ?? "",
          width_in: listing.width_in ?? "",
          height_in: listing.height_in ?? "",
          location: listing.location || "",
          quantity: String(listing.quantity ?? 1),
          description: listing.description || "",
          new_arrival: Boolean(listing.new_arrival),
          new_arrival_since:
            listing.new_arrival_since || (listing.new_arrival ? listing.created_date : ""),
          seller_name: listing.seller_name || "",
          seller_email: listing.seller_email || "",
          seller_phone: listing.seller_phone || "",
          seller_photo_url: listing.seller_photo_url || "",
        }
      : {
          ...emptyForm,
          seller_email: user?.email || "",
          location: "Pacoima, CA",
        }
  );
  const [images, setImages] = useState(publicMediaUrls(listing?.images));
  const [video, setVideo] = useState(listing?.video_url || "");
  const [uploading, setUploading] = useState(false);
  const [rotatingUrl, setRotatingUrl] = useState("");
  const [videoUploading, setVideoUploading] = useState(false);
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");
  const [created, setCreated] = useState(null);

  const [importFiles, setImportFiles] = useState([]);
  const [appliedImport, setAppliedImport] = useState(false);

  const update = (field) => (event) => {
    const { value } = event.target;
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  function applyImport(data) {
    if (isEdit || user?.role !== "admin" || appliedImport) return;
    const values = data.values;
    const category = catalogChoice(values.category, CATEGORIES, "slug");
    const condition = catalogChoice(values.condition, CONDITIONS, "value");
    const price = String(values.price || "").replace(/[^0-9.]/g, "");
    const size = (value) => (value && Number(value) > 0 ? String(value) : "");
    setForm((prev) => ({
      ...prev,
      title: values.name || prev.title,
      brand: values.brand || prev.brand,
      description: values.description || prev.description,
      price,
      category: category || prev.category,
      condition: condition || prev.condition,
      weight_lbs: size(values.weight_lbs) || prev.weight_lbs,
      length_in: size(values.length_in) || prev.length_in,
      width_in: size(values.width_in) || prev.width_in,
      height_in: size(values.height_in) || prev.height_in,
    }));
    setImages((prev) => [...new Set([...prev, ...data.images])].slice(0, 14));
    setAppliedImport(true);
    setError("");
  }

  const handleFiles = async (event) => {
    const selected = Array.from(event.target.files || []).slice(0, Math.max(14 - images.length, 0));
    event.target.value = "";
    if (!selected.length) return;
    setUploading(true);
    setError("");
    let failed = 0;
    for (const file of selected) {
      try {
        const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
        const url = publicMediaUrl(file_url);
        setImages((prev) => (prev.includes(url) ? prev : [...prev, url]));
      } catch {
        failed += 1;
      }
    }
    setUploading(false);
    if (failed) {
      setError(
        `${failed} of ${selected.length} photos could not be uploaded. Try adding them a few at a time.`
      );
    }
  };

  const handleRotate = async (url) => {
    setRotatingUrl(url);
    setError("");
    try {
      const file = await rotatedImageFile(url, 90);
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      const rotated = publicMediaUrl(file_url);
      setImages((prev) => prev.map((item) => (item === url ? rotated : item)));
    } catch {
      setError("That photo could not be rotated. Please try another one.");
    } finally {
      setRotatingUrl("");
    }
  };

  // The cover is simply the first photo in the gallery, so every card and the
  // listing page pick it up without any extra field.
  const setCover = (url) =>
    setImages((prev) => [url, ...prev.filter((item) => item !== url)]);

  const handleVideo = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setVideoUploading(true);
    setError("");
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      setVideo(file_url);
    } catch {
      setError("That video could not be uploaded. Try a smaller file.");
    } finally {
      setVideoUploading(false);
      event.target.value = "";
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const priceText = String(form.price ?? "").trim();
    const hasPrice = priceText !== "";
    const price = hasPrice ? Number(priceText) : 0;
    const needsCategory = !appliedImport;
    if (!form.title.trim() || !form.description.trim() || (needsCategory && !form.category)) {
      setError(
        needsCategory
          ? "Add a title, category and description so buyers know what they are looking at."
          : "Add a title and description so buyers know what they are looking at."
      );
      return;
    }
    if (appliedImport && !form.condition) {
      setError("Choose the equipment condition before publishing.");
      return;
    }
    if (hasPrice && (!Number.isFinite(price) || price < 1)) {
      setError("Enter a valid asking price, or leave the price blank to show Call for price.");
      return;
    }
    setStatus("saving");
    setError("");
    try {
      const dimension = (value) => {
        const number = Number(value);
        return Number.isFinite(number) && number > 0 ? number : null;
      };
      const weight = Number(form.weight_lbs);
      const payload = {
        ...form,
        price,
        price_on_request: !hasPrice,
        quantity: Math.max(0, Math.floor(Number(form.quantity) || 0)),
        weight_lbs: Number.isFinite(weight) && weight > 0 ? weight : null,
        length_in: dimension(form.length_in),
        width_in: dimension(form.width_in),
        height_in: dimension(form.height_in),
        images,
        video_url: video,
      };
      const record = isEdit
        ? await base44.entities.Listing.update(listing.id, payload)
        : await base44.entities.Listing.create({
            ...payload,
            seller_photo_url: form.seller_photo_url || user?.profile_photo_url || "",
            status: payload.quantity > 0 ? "active" : "archived",
          });
      setCreated(record);
      setStatus("done");
      if (!isEdit) onPublished?.(record);
    } catch (err) {
      setStatus("idle");
      setError(
        err?.message ||
          (isEdit
            ? "We could not save those changes. Please try again."
            : "We could not publish that listing. Please try again.")
      );
    }
  };

  if (status === "done" && created) {
    return (
      <div className="border border-primary/40 bg-card p-8 md:p-10">
        <div className="font-mono text-[10px] uppercase tracking-[0.24em] text-primary">
          {isEdit ? "Listing updated" : "Listing live"}
        </div>
        <h2 className="mt-3 font-heading text-2xl font-semibold uppercase tracking-[0.02em]">
          {isEdit
            ? `${created.title} has been updated`
            : `${created.title} is on the marketplace`}
        </h2>
        <p className="mt-3 max-w-lg text-sm leading-relaxed text-muted-foreground">
          {isEdit
            ? "Your changes are live. Buyers see the updated photos, details and price right away."
            : "Buyers can now find this unit and pay online. When it sells, the listing is marked sold automatically and we'll be in touch to arrange the handover."}
        </p>
        <div className="mt-7 flex flex-col gap-3 sm:flex-row">
          <Link
            to={`/equipment/${created.id}`}
            className="bg-primary px-5 py-3 text-center font-mono text-[10px] uppercase tracking-[0.2em] text-primary-foreground"
          >
            View listing
          </Link>
          {!isEdit && (
            <button
              type="button"
              onClick={() => {
                setCreated(null);
                setStatus("idle");
                if (appliedImport) setImportFiles((prev) => prev.slice(1));
                setAppliedImport(false);
                setImages([]);
                setVideo("");
                setForm({
                  ...emptyForm,
                  location: "Pacoima, CA",
                  seller_email: user?.email || "",
                });
              }}
              className="border border-border px-5 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-foreground"
            >
              List another unit
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <>
      {!isEdit && user?.role === "admin" && (
        <EbayListingImporter
          files={importFiles}
          setFiles={setImportFiles}
          applied={appliedImport}
          onApply={applyImport}
        />
      )}

      <form onSubmit={handleSubmit} className="border border-border bg-card">
        <div className="border-b border-border px-6 py-5">
          <h2 className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
            01 — Unit details
          </h2>
        </div>
        <div className="grid gap-5 px-6 py-6 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label htmlFor="title" className={labelClass}>
              Listing title *
            </label>
            <input
              id="title"
              required
              value={form.title}
              onChange={update("title")}
              placeholder="Stryker M-Series Gurney"
              className={inputClass}
            />
          </div>
          <div>
            <label htmlFor="brand" className={labelClass}>
              Brand
            </label>
            <input
              id="brand"
              value={form.brand}
              onChange={update("brand")}
              placeholder="Stryker"
              className={inputClass}
            />
          </div>
          <div>
            <label htmlFor="category" className={labelClass}>
              Category *
            </label>
            <select
              id="category"
              required={!appliedImport}
              value={form.category}
              onChange={update("category")}
              className={inputClass}
            >
              <option value="">{appliedImport ? "Category (optional)" : "Select a category"}</option>
              {CATEGORIES.map((cat) => (
                <option key={cat.slug} value={cat.slug}>
                  {cat.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="condition" className={labelClass}>
              Condition
            </label>
            <select
              id="condition"
              required={appliedImport}
              value={form.condition}
              onChange={update("condition")}
              className={inputClass}
            >
              {appliedImport && !form.condition && <option value="">Select the condition</option>}
              {CONDITIONS.map((item) => (
                <option key={item.value} value={item.value}>
                  {item.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="price" className={labelClass}>
              Asking price (USD) — optional
            </label>
            <input
              id="price"
              type="number"
              min="1"
              step="0.01"
              value={form.price}
              onChange={update("price")}
              placeholder="1850"
              className={inputClass}
            />
            <p className="mt-2 font-mono text-[9px] uppercase leading-relaxed tracking-[0.12em] text-muted-foreground">
              Leave blank to show “Call for price” with your phone number
            </p>
          </div>
          <div>
            <label htmlFor="weight_lbs" className={labelClass}>
              Shipping weight (lb)
            </label>
            <input
              id="weight_lbs"
              type="number"
              min="1"
              step="1"
              value={form.weight_lbs}
              onChange={update("weight_lbs")}
              placeholder="250"
              className={inputClass}
            />
          </div>
          <div className="grid grid-cols-3 gap-3 sm:col-span-2">
            {[
              ["length_in", "Length (in)", "48"],
              ["width_in", "Width (in)", "40"],
              ["height_in", "Height (in)", "30"],
            ].map(([field, label, placeholder]) => (
              <div key={field}>
                <label htmlFor={field} className={labelClass}>
                  {label}
                </label>
                <input
                  id={field}
                  type="number"
                  min="1"
                  step="1"
                  value={form[field]}
                  onChange={update(field)}
                  placeholder={placeholder}
                  className={inputClass}
                />
              </div>
            ))}
          </div>
          <QuantityStepper
            value={form.quantity}
            onChange={(next) => setForm((prev) => ({ ...prev, quantity: next }))}
            sold={listing?.sold_units ?? 0}
          />
          <div>
            <label htmlFor="location" className={labelClass}>
              Location
            </label>
            <input
              id="location"
              value={form.location}
              onChange={update("location")}
              placeholder="Pacoima, CA"
              className={inputClass}
            />
          </div>
          <div>
            <label htmlFor="seller_phone" className={labelClass}>
              Phone
            </label>
            <input
              id="seller_phone"
              value={form.seller_phone}
              onChange={update("seller_phone")}
              placeholder="(818) 000-0000"
              className={inputClass}
            />
          </div>
          <div className="sm:col-span-2">
            <label htmlFor="description" className={labelClass}>
              Description *
            </label>
            <textarea
              id="description"
              required
              rows={4}
              value={form.description}
              onChange={update("description")}
              placeholder="Model, year, service history, included accessories, known faults."
              className={`${inputClass} resize-none`}
            />
          </div>
        </div>

        <div className="border-y border-border px-6 py-5">
          <h2 className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
            02 — Photos
          </h2>
        </div>
        <div className="px-6 py-6">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {images.map((url, index) => (
              <div
                key={url}
                className={`relative aspect-square overflow-hidden border ${
                  index === 0 ? "border-primary ring-1 ring-primary" : "border-border"
                }`}
              >
                <Image src={url} alt="" fittingType="fill" className="h-full w-full" />
                {index === 0 ? (
                  <span className="absolute inset-x-1 bottom-1 bg-primary py-1 text-center font-mono text-[8px] uppercase tracking-[0.12em] text-primary-foreground">
                    Cover photo
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={() => setCover(url)}
                    className="absolute inset-x-1 bottom-1 bg-background/90 py-1 text-center font-mono text-[8px] uppercase tracking-[0.12em] text-muted-foreground transition-colors hover:text-primary"
                  >
                    Set as cover
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => handleRotate(url)}
                  disabled={rotatingUrl === url}
                  aria-label="Rotate photo"
                  title="Rotate photo"
                  className="absolute left-1 top-1 grid h-6 w-6 place-items-center bg-background/90 text-muted-foreground transition-colors hover:text-primary disabled:opacity-60"
                >
                  {rotatingUrl === url ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <RotateCw className="h-3 w-3" />
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setImages((prev) => prev.filter((item) => item !== url))}
                  aria-label="Remove photo"
                  className="absolute right-1 top-1 grid h-6 w-6 place-items-center bg-background/90 text-muted-foreground hover:text-destructive"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
            {images.length < 14 && (
              <label className="flex aspect-square cursor-pointer flex-col items-center justify-center gap-2 border border-dashed border-border text-muted-foreground transition-colors hover:border-primary/60 hover:text-primary">
                {uploading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <>
                    <ImageIcon className="h-4 w-4" />
                    <span className="font-mono text-[9px] uppercase tracking-[0.16em]">Add photo</span>
                  </>
                )}
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleFiles}
                  disabled={uploading}
                  className="hidden"
                />
              </label>
            )}
          </div>
          <p className="mt-3 font-mono text-[9px] uppercase tracking-[0.14em] text-muted-foreground">
            {images.length}/14 photos · “Set as cover” changes the main photo · tap ↻ to rotate · stored publicly — anyone with the link can open them
          </p>

          <div className="mt-7 border-t border-border pt-6">
            <p className={labelClass}>Video (1 max)</p>
            {video ? (
              <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:items-start">
                <video
                  src={video}
                  controls
                  playsInline
                  className="aspect-video w-full max-w-sm border border-border bg-accent object-contain"
                />
                <button
                  type="button"
                  onClick={() => setVideo("")}
                  className="border border-border px-4 py-2.5 font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground transition-colors hover:text-destructive"
                >
                  Remove video
                </button>
              </div>
            ) : (
              <label className="mt-3 flex cursor-pointer items-center justify-center gap-2 border border-dashed border-border px-4 py-6 font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground transition-colors hover:border-primary/60 hover:text-primary">
                {videoUploading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <VideoIcon className="h-4 w-4" />
                )}
                {videoUploading ? "Uploading" : "Add a video"}
                <input
                  type="file"
                  accept="video/*"
                  onChange={handleVideo}
                  disabled={videoUploading}
                  className="hidden"
                />
              </label>
            )}
          </div>

          <div className="mt-7 border-t border-border pt-6">
            <label className="flex cursor-pointer items-start gap-3">
              <input
                type="checkbox"
                checked={Boolean(form.new_arrival)}
                onChange={(event) =>
                  setForm((prev) =>
                    event.target.checked
                      ? {
                          ...prev,
                          new_arrival: true,
                          new_arrival_since: prev.new_arrival_since || new Date().toISOString(),
                        }
                      : { ...prev, new_arrival: false, new_arrival_since: "" }
                  )
                }
                className="mt-0.5 h-4 w-4 accent-primary"
              />
              <span>
                <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-foreground">
                  New arrival watermark
                </span>
                <span className="mt-1 block text-xs leading-relaxed text-muted-foreground">
                  Puts a red “New arrival” ribbon across the photo on inventory cards. It drops off
                  automatically one week after you switch it on — untick to remove it sooner.
                </span>
              </span>
            </label>
          </div>
        </div>

        <div className="border-y border-border px-6 py-5">
          <h2 className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
            03 — Seller contact
          </h2>
        </div>
        <div className="grid gap-5 px-6 py-6 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <ListingProfilePhoto
              user={user}
              value={form.seller_photo_url}
              onChange={(url) => setForm((prev) => ({ ...prev, seller_photo_url: url }))}
            />
          </div>
          <div>
            <label htmlFor="seller_name" className={labelClass}>
              Name
            </label>
            <input
              id="seller_name"
              value={form.seller_name}
              onChange={update("seller_name")}
              className={inputClass}
            />
          </div>
          <div>
            <label htmlFor="seller_email" className={labelClass}>
              Email
            </label>
            <input
              id="seller_email"
              type="email"
              value={form.seller_email}
              onChange={update("seller_email")}
              className={inputClass}
            />
          </div>
        </div>

        <div className="border-t border-border px-6 py-6">
          {error && (
            <p className="mb-4 border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs leading-relaxed text-destructive">
              {error}
            </p>
          )}
          <button
            type="submit"
            disabled={status === "saving" || uploading || videoUploading}
            className="flex w-full items-center justify-center gap-2 bg-accent px-6 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-accent-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
          >
            {status === "saving" ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                {isEdit ? "Saving" : "Publishing"}
              </>
            ) : (
              <>
                {isEdit ? <Save className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
                {isEdit ? "Save changes" : "Publish listing"}
              </>
            )}
          </button>
          <p className="mt-3 text-center font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
            No listing fee · commission agreed on sale
          </p>
        </div>
      </form>
    </>
  );
}