import { Link } from "react-router-dom";

export default function EbayExportResults({ summary }) {
  if (!summary) return null;
  const attention = summary.results.filter((item) => item.problems.length || item.error);
  return (
    <div className="mt-5 border-t border-border pt-4" role="status">
      <p className="text-sm">{summary.created} created · {summary.updated} updated · {summary.failed} need attention · {summary.photos} photos saved</p>
      {summary.failures.length > 0 && (
        <div className="mt-3 text-xs text-muted-foreground">
          <p className="font-semibold">Inputs that could not be read</p>
          <ul className="mt-1 space-y-1">{summary.failures.map((failure, index) => <li key={index}>{failure}</li>)}</ul>
        </div>
      )}
      {attention.length > 0 && (
        <div className="mt-3 text-xs text-muted-foreground">
          <p className="font-semibold">Needs attention</p>
          <ul className="mt-1 space-y-2">
            {attention.map((item, index) => <li key={index}>{item.label}: {[...item.problems, item.error].filter(Boolean).join(" · ")}</li>)}
          </ul>
        </div>
      )}
      <ul className="mt-3 space-y-2 text-xs">
        {summary.results.filter((item) => item.listingId).map((item) => (
          <li key={item.listingId}><Link to={`/equipment/${item.listingId}`} className="text-primary underline underline-offset-2">{item.label}</Link></li>
        ))}
      </ul>
    </div>
  );
}