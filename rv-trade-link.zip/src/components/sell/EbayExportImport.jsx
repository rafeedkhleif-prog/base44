import { Loader2 } from "lucide-react";
import useEbayExportImport from "@/hooks/useEbayExportImport";
import EbayExportPicker from "@/components/sell/EbayExportPicker";
import EbayExportCheck from "@/components/sell/EbayExportCheck";
import EbayExportResults from "@/components/sell/EbayExportResults";

export default function EbayExportImport({ user, onComplete }) {
  const state = useEbayExportImport({ user, onComplete });
  return (
    <section className="mb-6 border border-border bg-card p-6" aria-label="Import an eBay export">
      <h2 className="font-heading text-lg font-semibold">Import an eBay export</h2>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
        Choose the complete export ZIP, containing index.html and the items photo folder. No need to select individual photos.
        Every gallery and description photo in the export is uploaded and attached to its listing, including photos kept in a
        folder named after the product. You can also select an extracted folder. Re-importing the same eBay draft updates its existing listing.
      </p>
      <p className="mt-2 text-xs text-muted-foreground">Photos (stored publicly — anyone with the link can open them)</p>
      <EbayExportPicker disabled={state.busy} onPick={state.pick} onReset={state.reset} hasFiles={state.files.length > 0} />
      {state.phase === "checking" && <p role="status" className="mt-3 flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Reading export and checking photos…</p>}
      <EbayExportCheck prepared={state.prepared} />
      <button type="button" onClick={state.run} disabled={state.busy || !state.prepared?.canImport}
        className="mt-4 flex w-full items-center justify-center gap-2 bg-accent px-6 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-accent-foreground hover:opacity-90 disabled:opacity-60">
        {state.busy && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
        {state.phase === "checking" ? "Checking photos" : state.phase === "importing" ? "Importing" : "Start import"}
      </button>
      {state.progress && <p role="status" className="mt-3 text-sm text-muted-foreground">{state.progress.position + 1} of {state.progress.total} — {state.progress.label}</p>}
      {state.error && <p role="alert" className="mt-3 border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive">{state.error}</p>}
      <EbayExportResults summary={state.summary} />
    </section>
  );
}