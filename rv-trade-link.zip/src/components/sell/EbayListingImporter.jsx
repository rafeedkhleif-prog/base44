import { useEffect, useState } from "react";
import readSavedEbayPage from "@/lib/ebayImport";

export default function EbayListingImporter({ files, setFiles, applied, onApply }) {
  const file = files[0];
  const [preview, setPreview] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let current = true;
    setPreview(null);
    setError("");
    if (file) {
      readSavedEbayPage(file)
        .then((data) => {
          if (current) setPreview({ file, data });
        })
        .catch((err) => {
          if (current) setError(err.message);
        });
    }
    return () => {
      current = false;
    };
  }, [file]);

  const data = preview && preview.file === file ? preview.data : null;
  const values = data?.values;
  const size = [
    values?.weight_lbs && `${values.weight_lbs} lb`,
    values?.length_in && `${values.length_in} × ${values.width_in || "?"} × ${values.height_in || "?"} in`,
  ]
    .filter(Boolean)
    .join(" · ");

  return (
    <section className="mb-6 border border-border bg-card p-6" aria-label="Import eBay listing">
      <h2 className="font-heading text-lg font-semibold">Import a saved eBay listing</h2>
      <p className="mt-2 text-sm text-muted-foreground">
        Open the listing (or your eBay draft) in a browser and save the page, then upload that file
        here. Title, price, condition, description, photos, brand, weight and dimensions are read
        from the saved page.
      </p>

      {!applied && (
        <label className="mt-3 block text-sm">
          Choose saved eBay listings or drafts (.html or .mhtml)
          <input
            className="mt-2 block w-full"
            type="file"
            multiple
            accept=".html,.htm,.mhtml,.mht"
            onChange={(event) => {
              if (event.target.files.length) setFiles(Array.from(event.target.files));
              event.target.value = "";
            }}
          />
        </label>
      )}

      {file && (
        <p className="mt-3 text-sm">
          {file.name}
          {files.length > 1 ? ` · ${files.length - 1} more in queue` : ""}
        </p>
      )}

      {error && (
        <p role="alert" className="mt-2 text-sm text-destructive">
          {error}
        </p>
      )}

      {file && !error && !data && <p role="status">Reading file…</p>}

      {data && !applied && (
        <>
          <p className="mt-2 font-semibold">{values.name || "Title missing from saved page"}</p>
          <p className="text-sm">
            {[
              values.brand,
              values.price && `USD ${values.price}`,
              values.condition,
              values.category,
            ]
              .filter(Boolean)
              .join(" · ")}
          </p>
          {(size || data.images.length > 0) && (
            <p className="text-sm text-muted-foreground">
              {[size, data.images.length > 0 && `${data.images.length} eBay photos`]
                .filter(Boolean)
                .join(" · ")}
            </p>
          )}
          {data.notes.map((note) => (
            <p key={note} className="text-sm">
              {note}
            </p>
          ))}
          {(values.sku || values.quantity) && (
            <p className="text-sm">
              eBay reference only:{" "}
              {[values.sku && `SKU ${values.sku}`, values.quantity && `quantity ${values.quantity}`]
                .filter(Boolean)
                .join(" · ")}
            </p>
          )}
          <button
            type="button"
            className="mt-3 bg-primary px-4 py-2 text-primary-foreground"
            onClick={() => onApply(data)}
          >
            Use in listing form
          </button>
        </>
      )}

      {file && !applied && (
        <button
          type="button"
          className="ml-3 mt-3 text-sm underline"
          onClick={() => setFiles((current) => current.slice(1))}
        >
          Skip this file
        </button>
      )}

      {applied && (
        <p role="status" className="mt-2 text-sm">
          Review the details, category, condition, price, photos and shipping size below. Publish
          when ready.
        </p>
      )}
    </section>
  );
}