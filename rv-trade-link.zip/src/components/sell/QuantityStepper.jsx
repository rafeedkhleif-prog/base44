import { Minus, Plus } from "lucide-react";

const buttonClass =
  "grid h-11 w-11 place-items-center border border-border text-muted-foreground transition-colors hover:border-primary/60 hover:text-primary disabled:opacity-40";

export default function QuantityStepper({ value, onChange, sold = 0, label = "Units in stock" }) {
  const quantity = Number(value) || 0;
  const set = (next) => onChange(String(Math.min(999, Math.max(0, next))));
  return (
    <div>
      <label className="font-mono text-[9px] uppercase tracking-[0.22em] text-muted-foreground">{label}</label>
      <div className="mt-2 flex items-stretch">
        <button type="button" onClick={() => set(quantity - 1)} disabled={quantity <= 0} aria-label="Remove one unit" className={buttonClass}>
          <Minus className="h-3.5 w-3.5" />
        </button>
        <input
          type="number"
          min="0"
          max="999"
          step="1"
          value={value}
          onChange={(event) => set(Number(event.target.value))}
          className="w-full border-y border-border bg-background text-center font-mono text-sm outline-none focus:border-primary"
        />
        <button type="button" onClick={() => set(quantity + 1)} disabled={quantity >= 999} aria-label="Add one unit" className={buttonClass}>
          <Plus className="h-3.5 w-3.5" />
        </button>
      </div>
      <p className="mt-2 font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
        {quantity > 0 ? `${quantity} available` : "Out of stock"}
        {sold > 0 ? ` · ${sold} sold` : ""}
      </p>
    </div>
  );
}