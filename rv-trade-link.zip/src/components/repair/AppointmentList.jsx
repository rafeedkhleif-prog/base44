import { format } from "date-fns";
import { Trash2 } from "lucide-react";

const SOURCE_LABEL = {
  phone: "Phone",
  email: "Email",
  web: "Web form",
  "in-person": "In person",
  other: "Other",
};

const WINDOW_LABEL = {
  morning: "Morning · 8:00–12:00",
  afternoon: "Afternoon · 12:00–17:00",
  flexible: "Flexible",
};

export default function AppointmentList({ items, onDelete }) {
  if (items.length === 0) {
    return (
      <p className="border border-border bg-card px-4 py-8 text-center text-sm text-muted-foreground">
        Nothing on the calendar yet. Book an appointment or mark a day unavailable to start.
      </p>
    );
  }

  return (
    <ul className="divide-y divide-border border border-border bg-card">
      {items.map((item) => {
        const blocked = item.kind === "blocked";
        return (
          <li key={item.id} className="flex flex-wrap items-start gap-4 px-4 py-4 md:px-5">
            <div className="w-24 shrink-0">
              <div className="font-mono text-sm">{format(new Date(`${item.date}T12:00:00`), "MMM d")}</div>
              <div className="font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
                {format(new Date(`${item.date}T12:00:00`), "yyyy")}
              </div>
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span
                  className={`border px-2 py-0.5 font-mono text-[9px] uppercase tracking-[0.16em] ${
                    blocked ? "border-border text-muted-foreground" : "border-primary/50 text-primary"
                  }`}
                >
                  {blocked ? "Unavailable" : "Appointment"}
                </span>
                {!blocked && item.source && (
                  <span className="font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
                    via {SOURCE_LABEL[item.source] ?? item.source}
                  </span>
                )}
                {!blocked && item.time_window && (
                  <span className="font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
                    {WINDOW_LABEL[item.time_window] ?? item.time_window}
                  </span>
                )}
              </div>

              <div className="mt-1.5 font-heading text-sm font-semibold uppercase tracking-[0.01em]">
                {blocked ? item.notes || "Day closed" : item.customer_name || "Unnamed appointment"}
              </div>

              {!blocked && (
                <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                  {item.organization && <span>{item.organization}</span>}
                  {item.customer_phone && <span>{item.customer_phone}</span>}
                  {item.customer_email && <span>{item.customer_email}</span>}
                  {item.equipment && <span>{item.equipment}</span>}
                </div>
              )}

              {!blocked && item.notes && (
                <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">{item.notes}</p>
              )}
            </div>

            <button
              type="button"
              onClick={() => onDelete(item)}
              aria-label={`Remove ${item.date}`}
              className="grid h-8 w-8 shrink-0 place-items-center border border-border text-muted-foreground transition-colors hover:border-destructive hover:text-destructive"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </li>
        );
      })}
    </ul>
  );
}