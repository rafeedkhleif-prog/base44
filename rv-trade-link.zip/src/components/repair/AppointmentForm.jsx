import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

const inputClass =
  "mt-1.5 w-full border border-input bg-background px-3 py-2 text-sm outline-none transition-colors focus:border-primary";
const labelClass = "font-mono text-[9px] uppercase tracking-[0.2em] text-muted-foreground";

const EMPTY = {
  kind: "appointment",
  source: "phone",
  time_window: "flexible",
  customer_name: "",
  customer_phone: "",
  customer_email: "",
  organization: "",
  equipment: "",
  notes: "",
};

export default function AppointmentForm({
  date,
  onSaved,
  entity = base44.entities.RepairAppointment,
  noun = "repair appointment",
}) {
  const [form, setForm] = useState({ ...EMPTY, date });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const isBlocked = form.kind === "blocked";

  useEffect(() => {
    setForm((prev) => ({ ...prev, date }));
  }, [date]);

  const update = (field) => (event) =>
    setForm((prev) => ({ ...prev, [field]: event.target.value }));

  const submit = async (event) => {
    event.preventDefault();
    if (!form.date) {
      setError("Pick the day you want to book or close.");
      return;
    }
    if (!isBlocked && !form.customer_name.trim()) {
      setError("Add the customer name so the calendar record is useful.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      const payload = { date: form.date, kind: form.kind, notes: form.notes.trim() };
      if (!isBlocked) {
        Object.assign(payload, {
          source: form.source,
          time_window: form.time_window,
          customer_name: form.customer_name.trim(),
          customer_phone: form.customer_phone.trim(),
          customer_email: form.customer_email.trim(),
          organization: form.organization.trim(),
          equipment: form.equipment.trim(),
        });
      }
      await entity.create(payload);
      setForm({ ...EMPTY, date: form.date });
      onSaved();
    } catch (err) {
      setError("That could not be saved. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="border border-border bg-card p-6">
      <h2 className="font-heading text-lg font-semibold uppercase tracking-[0.02em]">
        {isBlocked ? "Mark a day unavailable" : `Book a ${noun}`}
      </h2>
      <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
        Booked days and closed days both disappear from the public calendar.
      </p>

      <div className="mt-5 grid grid-cols-2 gap-2">
        {[
          { value: "appointment", label: "Appointment" },
          { value: "blocked", label: "Unavailable" },
        ].map((option) => (
          <button
            key={option.value}
            type="button"
            onClick={() => setForm((prev) => ({ ...prev, kind: option.value }))}
            className={`border px-3 py-2.5 font-mono text-[10px] uppercase tracking-[0.16em] transition-colors ${
              form.kind === option.value
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border text-muted-foreground hover:text-foreground"
            }`}
          >
            {option.label}
          </button>
        ))}
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label htmlFor="appt-date" className={labelClass}>
            Date *
          </label>
          <input
            id="appt-date"
            type="date"
            required
            value={form.date}
            onChange={update("date")}
            className={inputClass}
          />
        </div>

        {!isBlocked && (
          <>
            <div>
              <label htmlFor="appt-name" className={labelClass}>
                Customer / facility contact *
              </label>
              <input
                id="appt-name"
                value={form.customer_name}
                onChange={update("customer_name")}
                className={inputClass}
              />
            </div>
            <div>
              <label htmlFor="appt-org" className={labelClass}>
                Facility
              </label>
              <input
                id="appt-org"
                value={form.organization}
                onChange={update("organization")}
                className={inputClass}
              />
            </div>
            <div>
              <label htmlFor="appt-phone" className={labelClass}>
                Phone
              </label>
              <input
                id="appt-phone"
                type="tel"
                value={form.customer_phone}
                onChange={update("customer_phone")}
                className={inputClass}
              />
            </div>
            <div>
              <label htmlFor="appt-email" className={labelClass}>
                Email
              </label>
              <input
                id="appt-email"
                type="email"
                value={form.customer_email}
                onChange={update("customer_email")}
                className={inputClass}
              />
            </div>
            <div>
              <label htmlFor="appt-equipment" className={labelClass}>
                Equipment
              </label>
              <input
                id="appt-equipment"
                value={form.equipment}
                onChange={update("equipment")}
                placeholder="Stryker stretcher"
                className={inputClass}
              />
            </div>
            <div>
              <label htmlFor="appt-window" className={labelClass}>
                Time window
              </label>
              <select
                id="appt-window"
                value={form.time_window}
                onChange={update("time_window")}
                className={inputClass}
              >
                <option value="morning">Morning · 8:00–12:00</option>
                <option value="afternoon">Afternoon · 12:00–17:00</option>
                <option value="flexible">Flexible</option>
              </select>
            </div>
            <div>
              <label htmlFor="appt-source" className={labelClass}>
                Received by
              </label>
              <select
                id="appt-source"
                value={form.source}
                onChange={update("source")}
                className={inputClass}
              >
                <option value="phone">Phone</option>
                <option value="email">Email</option>
                <option value="web">Web form</option>
                <option value="in-person">In person</option>
                <option value="other">Other</option>
              </select>
            </div>
          </>
        )}

        <div className="sm:col-span-2">
          <label htmlFor="appt-notes" className={labelClass}>
            {isBlocked ? "Reason (internal)" : "Notes (internal)"}
          </label>
          <textarea
            id="appt-notes"
            rows={3}
            value={form.notes}
            onChange={update("notes")}
            placeholder={isBlocked ? "Holiday, crew out, parts delivery…" : "Parts ordered, gate code, contact…"}
            className={`${inputClass} resize-none`}
          />
        </div>
      </div>

      {error && (
        <p className="mt-4 border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs leading-relaxed text-destructive">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={saving}
        className="mt-5 flex w-full items-center justify-center gap-2 bg-primary px-5 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
      >
        {saving ? (
          <>
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            Saving
          </>
        ) : isBlocked ? (
          "Mark day unavailable"
        ) : (
          "Save appointment"
        )}
      </button>
    </form>
  );
}