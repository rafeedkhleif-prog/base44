import {
  addMonths,
  eachDayOfInterval,
  endOfMonth,
  endOfWeek,
  format,
  startOfMonth,
  startOfWeek,
} from "date-fns";
import { ChevronLeft, ChevronRight } from "lucide-react";

const WEEKDAYS = ["S", "M", "T", "W", "T", "F", "S"];

export default function AvailabilityCalendar({
  month,
  onMonthChange,
  unavailableDates,
  selected,
  onSelect,
  allowTaken = false,
}) {
  const todayKey = format(new Date(), "yyyy-MM-dd");
  const taken = unavailableDates instanceof Set ? unavailableDates : new Set(unavailableDates ?? []);
  const days = eachDayOfInterval({
    start: startOfWeek(startOfMonth(month)),
    end: endOfWeek(endOfMonth(month)),
  });

  return (
    <div className="border border-border bg-card">
      <div className="flex items-center justify-between border-b border-border px-3 py-2.5">
        <button
          type="button"
          onClick={() => onMonthChange(addMonths(month, -1))}
          aria-label="Previous month"
          className="grid h-8 w-8 place-items-center border border-border text-muted-foreground transition-colors hover:border-primary hover:text-primary"
        >
          <ChevronLeft className="h-4 w-4" />
        </button>
        <span className="font-mono text-[10px] uppercase tracking-[0.24em]">
          {format(month, "MMMM yyyy")}
        </span>
        <button
          type="button"
          onClick={() => onMonthChange(addMonths(month, 1))}
          aria-label="Next month"
          className="grid h-8 w-8 place-items-center border border-border text-muted-foreground transition-colors hover:border-primary hover:text-primary"
        >
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>

      <div className="grid grid-cols-7 border-b border-border">
        {WEEKDAYS.map((label, index) => (
          <div
            key={`${label}-${index}`}
            className="py-2 text-center font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground"
          >
            {label}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-px bg-border p-px">
        {days.map((day) => {
          const key = format(day, "yyyy-MM-dd");
          const inMonth = day.getMonth() === month.getMonth();
          const isPast = key < todayKey;
          const isTaken = taken.has(key);
          const isSelected = key === selected;
          const locked = isPast || (isTaken && !allowTaken);

          return (
            <button
              key={key}
              type="button"
              disabled={locked}
              onClick={() => onSelect?.(key)}
              aria-label={`${format(day, "MMMM d, yyyy")}${isTaken ? " — unavailable" : ""}`}
              className={[
                "h-11 font-mono text-xs transition-colors",
                !inMonth && "opacity-30",
                isSelected
                  ? "bg-primary text-primary-foreground"
                  : isTaken
                    ? "bg-muted text-muted-foreground line-through"
                    : isPast
                      ? "bg-card text-muted-foreground/40"
                      : "bg-card text-foreground",
                locked ? "cursor-not-allowed" : "hover:bg-secondary",
              ]
                .filter(Boolean)
                .join(" ")}
            >
              {day.getDate()}
            </button>
          );
        })}
      </div>

      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-border px-3 py-2.5 font-mono text-[9px] uppercase tracking-[0.14em] text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 border border-border bg-card" />
          Available
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 bg-muted-foreground/40" />
          Unavailable
        </span>
        {selected && (
          <span className="ml-auto text-foreground">
            {format(new Date(`${selected}T12:00:00`), "MMM d, yyyy")}
          </span>
        )}
      </div>
    </div>
  );
}