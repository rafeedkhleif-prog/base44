import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, ArrowUpRight, ChevronDown, ShoppingCart } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/lib/AuthContext";
import useCart from "@/hooks/useCart";
import { Image } from "@/components/ui/image";

const LOGO_URL =
  "https://base44.app/api/apps/6aeb6aa1c91d4c8d5bcd4ce8/files/mp/public/6aeb6aa1c91d4c8d5bcd4ce8/7bc983a03_mri-logo.png";

const NAV = [
  { label: "Inventory", to: "/equipment" },
  { label: "Refurbished", to: "/equipment?condition=refurbished" },
  { label: "Services", to: "/#services" },
  { label: "Repair", to: "/service" },
  { label: "Recycle", to: "/recycle" },
  { label: "Contact", to: "/#contact" },
  { label: "Newsletter", to: "/newsletter" },
];

const ADMIN_NAV = [
  { label: "Sell", to: "/sell" },
  { label: "Orders", to: "/orders" },
  { label: "Offers", to: "/offers" },
  { label: "Newsletter admin", to: "/newsletter-admin" },
  { label: "Shipping rates", to: "/shipping-admin" },
  { label: "Repair calendar", to: "/repair-admin" },
  { label: "Pickup calendar", to: "/pickup-admin" },
  { label: "Photo batch", to: "/matting-batch" },
];

const PILL = "rounded-full px-5 py-2.5 text-[14px] transition-colors";

export default function SiteHeader() {
  const [open, setOpen] = useState(false);
  const { isAuthenticated, user } = useAuth();
  const isAdmin = user?.role === "admin";
  const allLinks = [...NAV, ...(isAdmin ? ADMIN_NAV : [])];
  const cartCount = useCart().length;
  const { pathname, search } = useLocation();
  const onRefurbished =
    pathname === "/equipment" && new URLSearchParams(search).get("condition") === "refurbished";

  // Inventory and Refurbished share a path, so the active tab is decided by the
  // condition in the URL: the refurbished tab is the one the CTA links to.
  const isActive = (item) => {
    const [path, query] = item.to.split("?");
    if (query) return pathname === path && search.includes(query);
    if (pathname !== path) return false;
    return !(path === "/equipment" && onRefurbished);
  };

  return (
    <header className="sticky top-0 z-50 border-b border-rule bg-canvas/90 backdrop-blur-md">
      <div className="mx-auto flex w-full max-w-[1330px] items-center justify-between gap-6 px-5 py-[22px] md:px-10">
        <Link to="/" className="flex items-center gap-3">
          <Image
            src={LOGO_URL}
            alt="Medical ReVitalization, Inc."
            fittingType="fit"
            className="h-[40px] w-auto rounded-lg"
          />
          <span className="hidden sm:flex">
            <a
              href="tel:8188998090"
              className="text-[13px] text-ink-faint transition-colors hover:text-sage"
            >
              818-899-8090
            </a>
          </span>
        </Link>

        <nav className="hidden items-center gap-[30px] text-[14px] text-ink-body lg:flex">
          {NAV.map((item) => (
            <Link
              key={item.label}
              to={item.to}
              className={`transition-colors hover:text-sage ${
                isActive(item) ? "text-sage" : ""
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          {isAdmin ? (
            <>
              <DropdownMenu>
                <DropdownMenuTrigger
                  className={`hidden items-center gap-1.5 border border-sage-line text-sage hover:bg-panel lg:inline-flex ${PILL}`}
                >
                  Admin
                  <ChevronDown className="h-3.5 w-3.5" />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="rounded-xl border-rule bg-shell text-[13px]">
                  {ADMIN_NAV.map((item) => (
                    <DropdownMenuItem key={item.label} asChild>
                      <Link to={item.to}>{item.label}</Link>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
              <Link
                to="/sell"
                className={`hidden items-center gap-2 bg-sage text-white hover:bg-sage-deep sm:inline-flex ${PILL}`}
              >
                List equipment
                <ArrowUpRight className="h-3.5 w-3.5" />
              </Link>
            </>
          ) : isAuthenticated ? (
            <span className="hidden text-[13px] text-ink-faint lg:block">
              {user?.full_name || user?.email}
            </span>
          ) : (
            <Link
              to="/login"
              className={`hidden border border-sage-line text-sage hover:bg-panel lg:inline-flex ${PILL}`}
            >
              Sign in
            </Link>
          )}

          <Link
            to="/cart"
            aria-label={cartCount ? `Cart, ${cartCount} items` : "Cart"}
            className="relative grid h-10 w-10 place-items-center rounded-xl border border-sage-line text-sage transition-colors hover:bg-panel"
          >
            <ShoppingCart className="h-4 w-4" />
            {cartCount > 0 && (
              <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-sage px-1 font-mono text-[9px] leading-none text-white">
                {cartCount}
              </span>
            )}
          </Link>

          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <button
                type="button"
                aria-label="Open menu"
                className="grid h-10 w-10 place-items-center rounded-xl border border-sage-line text-sage lg:hidden"
              >
                <Menu className="h-4 w-4" />
              </button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] border-rule bg-canvas p-6">
              <SheetTitle className="text-[11px] uppercase tracking-[0.16em] text-ink-faint">
                Menu
              </SheetTitle>
              <div className="mt-6 flex flex-col">
                {allLinks.map((item) => (
                  <Link
                    key={item.label}
                    to={item.to}
                    onClick={() => setOpen(false)}
                    className={`border-b border-rule py-3.5 text-[15px] ${
                      isActive(item) ? "text-sage" : ""
                    }`}
                  >
                    {item.label}
                  </Link>
                ))}
                {(isAdmin || !isAuthenticated) && (
                  <Link
                    to={isAdmin ? "/sell" : "/login"}
                    onClick={() => setOpen(false)}
                    className="mt-6 rounded-full bg-sage px-5 py-3 text-center text-[14px] text-white transition-colors hover:bg-sage-deep"
                  >
                    {isAdmin ? "List equipment" : "Sign in"}
                  </Link>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}