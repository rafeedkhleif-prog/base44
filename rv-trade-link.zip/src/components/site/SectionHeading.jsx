export default function SectionHeading({ index, eyebrow, title, description, action }) {
  return (
    <div className="flex flex-col gap-6 border-b border-border pb-8 md:flex-row md:items-end md:justify-between">
      <div>
        <div className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-[0.26em] text-muted-foreground">
          {index && <span className="text-primary">{index}</span>}
          <span>{eyebrow}</span>
        </div>
        <h2 className="mt-4 max-w-2xl font-heading text-2xl font-semibold uppercase leading-[1.05] tracking-[0.01em] md:text-4xl">
          {title}
        </h2>
        {description && (
          <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground">{description}</p>
        )}
      </div>
      {action}
    </div>
  );
}