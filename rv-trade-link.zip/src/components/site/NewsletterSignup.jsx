import { useState } from "react";
import { Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function NewsletterSignup({ source = "site footer" }) {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("idle");
  const [note, setNote] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!email.trim()) return;
    setStatus("saving");
    setNote("");
    try {
      await base44.entities.Subscriber.create({
        email: email.trim().toLowerCase(),
        status: "active",
        source
      });
      setEmail("");
      setStatus("done");
      setNote("You're on the list — inventory updates will land in your inbox.");
    } catch (err) {
      setStatus("idle");
      setNote("That signup didn't go through. Please try again.");
    }
  };

  return (
    <div>
      <h4 className="text-[11px] font-medium uppercase tracking-[0.16em] text-ink-faint">
        Newsletter
      </h4>
      <p className="mt-4 max-w-[320px] text-[14px] leading-relaxed text-ink-body">New arrivals and price drops!

      </p>
      <form onSubmit={handleSubmit} className="mt-4 flex max-w-[340px] gap-2">
        <input
          type="email"
          required
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          placeholder="you@facility.com"
          aria-label="Email address"
          className="h-[42px] w-full rounded-full border border-rule bg-canvas px-4 text-[14px] outline-none transition-colors placeholder:text-ink-meta focus:border-sage-line" />
        
        <button
          type="submit"
          disabled={status === "saving"}
          className="flex shrink-0 items-center gap-2 rounded-full bg-sage px-5 text-[13px] text-white transition-colors hover:bg-sage-deep disabled:opacity-60">
          
          {status === "saving" && <Loader2 className="h-3 w-3 animate-spin" />}
          Subscribe
        </button>
      </form>
      {note && <p className="mt-3 max-w-[340px] text-[12px] leading-relaxed text-ink-faint">{note}</p>}
    </div>);

}