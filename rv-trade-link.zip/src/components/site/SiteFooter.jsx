import { Link } from "react-router-dom";
import { CATEGORIES } from "@/data/catalog";
import { useAuth } from "@/lib/AuthContext";
import NewsletterSignup from "@/components/site/NewsletterSignup";
import { Image } from "@/components/ui/image";

const LOGO_URL =
  "https://base44.app/api/apps/6aeb6aa1c91d4c8d5bcd4ce8/files/mp/public/6aeb6aa1c91d4c8d5bcd4ce8/45b693f53_mri-logo.png";

export default function SiteFooter() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const company = [
    { label: "Inventory", to: "/equipment" },
    ...(isAdmin ? [{ label: "Sell your equipment", to: "/sell" }] : []),
    { label: "Repair & service", to: "/service" },
    { label: "Services", to: "/#services" },
    { label: "Contact", to: "/#contact" },
  ];

  return (
    <footer className="mt-24 border-t border-rule bg-shell">
      <div className="mx-auto w-full max-w-[1330px] px-5 py-16 md:px-16">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-[2fr_1fr_1fr_1.4fr] lg:gap-12">
          <div>
            <div className="flex items-center gap-3">
              <Image
                src={LOGO_URL}
                alt="Medical ReVitalization, Inc."
                fittingType="fit"
                className="h-[44px] w-auto rounded-lg"
              />
            </div>
            <p className="mt-5 max-w-[340px] text-[14px] leading-relaxed text-ink-body">
              Refurbishing, selling and recycling medical equipment from a 20,000 sq ft facility in
              Pacoima, California. Factory-trained technicians, warranted work, nationwide delivery.
            </p>
            <div className="mt-4 flex flex-col gap-1 text-[14px] text-ink-body">
              <a href="tel:+18188998090" className="transition-colors hover:text-sage">
                1-818-899-8090
              </a>
              <a href="mailto:info@medicalrv.com" className="transition-colors hover:text-sage">
                info@medicalrv.com
              </a>
              <span>13715 Desmond St., Pacoima, CA 91331</span>
            </div>
          </div>

          <div>
            <h4 className="text-[11px] font-medium uppercase tracking-[0.16em] text-ink-faint">
              Company
            </h4>
            <ul className="mt-4 flex flex-col gap-2.5 text-[14px] text-ink-body">
              {company.map((item) => (
                <li key={item.label}>
                  <Link to={item.to} className="transition-colors hover:text-sage">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-[11px] font-medium uppercase tracking-[0.16em] text-ink-faint">
              Equipment
            </h4>
            <ul className="mt-4 flex flex-col gap-2.5 text-[14px] text-ink-body">
              {CATEGORIES.slice(0, 5).map((cat) => (
                <li key={cat.slug}>
                  <Link
                    to={`/equipment?category=${cat.slug}`}
                    className="transition-colors hover:text-sage"
                  >
                    {cat.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <NewsletterSignup />
        </div>

        <div className="mt-14 flex flex-col gap-2 border-t border-rule pt-6 text-[11px] uppercase tracking-[0.12em] text-ink-faint md:flex-row md:items-center md:justify-between">
          <span>© {new Date().getFullYear()} Medical ReVitalization, Inc.</span>
          <span>13715 Desmond St. Pacoima, CA 91331</span>
        </div>
      </div>
    </footer>
  );
}