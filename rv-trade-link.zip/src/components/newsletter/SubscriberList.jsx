import { Loader2, MailOpen, Trash2 } from "lucide-react";

export default function SubscriberList({ subscribers = [], loading = false, onRemove }) {
  const active = subscribers.filter((item) => item.status === "active");

  return (
    <div className="border border-border bg-card">
      <div className="flex items-center justify-between border-b border-border px-6 py-5">
        <h2 className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
          Subscribers
        </h2>
        <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-primary">
          {active.length} active
        </span>
      </div>
      {loading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        </div>
      ) : subscribers.length === 0 ? (
        <div className="px-6 py-14 text-center">
          <MailOpen className="mx-auto h-4 w-4 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">
            No subscribers yet. The signup form in the site footer feeds this list.
          </p>
        </div>
      ) : (
        <ul className="max-h-[520px] divide-y divide-border overflow-y-auto">
          {subscribers.map((subscriber) => (
            <li key={subscriber.id} className="flex items-center justify-between gap-3 px-6 py-4">
              <div className="min-w-0">
                <p className="truncate text-sm">{subscriber.email}</p>
                <p className="mt-1 font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
                  {subscriber.status}
                  {subscriber.source ? ` · ${subscriber.source}` : ""}
                </p>
              </div>
              <button
                type="button"
                onClick={() => onRemove(subscriber)}
                aria-label={`Remove ${subscriber.email}`}
                className="text-muted-foreground transition-colors hover:text-destructive"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}