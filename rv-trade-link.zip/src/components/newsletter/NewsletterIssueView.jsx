import { Link } from "react-router-dom";
import LetterPreview from "@/components/newsletter/LetterPreview";

function issueDate(issue) {
  const value = issue.issue_date || issue.created_date;
  if (!value) return "";
  return new Date(value).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });
}

export default function NewsletterIssueView({ issue }) {
  const paragraphs = (issue.message || "")
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);
  const cta = issue.cta_url || "";
  const ctaClass =
    "mt-9 inline-flex bg-primary px-6 py-3.5 font-mono text-[10px] uppercase tracking-[0.2em] text-primary-foreground transition-opacity hover:opacity-90";

  return (
    <article className="border border-border bg-card p-7 md:p-12">
      <div className="flex flex-col gap-2 border-b border-border pb-5 font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
        <span>Medical ReVitalization · Newsletter</span>
        <span>{issueDate(issue)}</span>
      </div>

      <h2 className="mt-7 font-heading text-3xl font-semibold uppercase leading-[1.05] tracking-[0.01em] md:text-[40px]">
        {issue.headline}
      </h2>

      <div className="mt-6 space-y-4 text-[15px] leading-relaxed text-muted-foreground">
        {paragraphs.map((paragraph, index) => (
          <p key={index}>{paragraph}</p>
        ))}
      </div>

      {issue.letter_url && <LetterPreview url={issue.letter_url} name={issue.letter_name} />}

      {issue.cta_label &&
        (cta.startsWith("/") ? (
          <Link to={cta} className={ctaClass}>
            {issue.cta_label}
          </Link>
        ) : cta ? (
          <a href={cta} className={ctaClass}>
            {issue.cta_label}
          </a>
        ) : null)}
    </article>
  );
}