import { useState } from "react";
import { Loader2, Upload } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { publicMediaUrl } from "@/lib/media";

const MAX_LETTER_BYTES = 5 * 1024 * 1024;

export default function LetterUpload({ onUploaded }) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (file.size > MAX_LETTER_BYTES) {
      setError("Letters must be 5 MB or smaller.");
      return;
    }
    setUploading(true);
    setError("");
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      await onUploaded({ url: publicMediaUrl(file_url), name: file.name });
    } catch (err) {
      setError("That letter could not be published. Try a PDF under 5 MB.");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div>
      <label className="mt-3 flex w-fit cursor-pointer items-center justify-center gap-2 border border-border px-4 py-3 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground transition-colors hover:border-primary/60 hover:text-primary">
        {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />}
        {uploading ? "Publishing" : "Upload letter"}
        <input
          type="file"
          accept=".pdf,.doc,.docx,image/*"
          onChange={handleChange}
          disabled={uploading}
          className="hidden"
        />
      </label>
      <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">
        PDF, Word or image up to 5 MB. It publishes here as the latest issue.
      </p>
      {error && <p className="mt-2 text-xs leading-relaxed text-destructive">{error}</p>}
    </div>
  );
}