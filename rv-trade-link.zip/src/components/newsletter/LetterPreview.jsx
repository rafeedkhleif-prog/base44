import { useEffect, useState } from "react";
import { Image } from "@/components/ui/image";

const isHeicFile = (url, name) => /\.(heic|heif)(\?|#|$)/i.test(name || "") || /\.(heic|heif)(\?|#|$)/i.test(url || "");
const isImageFile = (url, name) => /\.(png|jpe?g|gif|webp|avif|bmp)(\?|#|$)/i.test(name || "") || /\.(png|jpe?g|gif|webp|avif|bmp)(\?|#|$)/i.test(url || "");

export default function LetterPreview({ url, name }) {
  const heic = isHeicFile(url, name);
  const [converted, setConverted] = useState(null);
  const [failed, setFailed] = useState(false);
  const [size, setSize] = useState(null);
  const source = heic ? converted : url;

  // The image is laid out by its own aspect ratio, so the page shows the whole letter
  // instead of collapsing it.
  useEffect(() => {
    if (!source) return;
    setSize(null);
    const probe = new window.Image();
    probe.onload = () => setSize({ width: probe.naturalWidth, height: probe.naturalHeight });
    probe.src = source;
  }, [source]);

  useEffect(() => {
    if (!url || !heic) return;
    let objectUrl = "";
    let cancelled = false;
    (async () => {
      try {
        const response = await fetch(url);
        const blob = await response.blob();
        const { default: heic2any } = await import("heic2any");
        const jpeg = await heic2any({ blob, toType: "image/jpeg", quality: 0.9 });
        objectUrl = URL.createObjectURL(jpeg);
        if (!cancelled) setConverted(objectUrl);
      } catch {
        if (!cancelled) setFailed(true);
      }
    })();
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [url, heic]);

  if (!url) return null;
  const showImage = (heic || isImageFile(url, name)) && !failed;

  return (
    <figure className="mt-8 border border-border">
      {!showImage ? (
        <iframe src={url} title={name || "Newsletter letter"} className="h-[80vh] w-full bg-secondary" />
      ) : source && size ? (
        <Image
          src={source}
          alt={name || "Newsletter letter"}
          originWidth={size.width}
          originHeight={size.height}
          fittingType="fit"
          className="block w-full"
        />
      ) : (
        <div className="flex h-64 items-center justify-center bg-secondary font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
          {failed ? "This photo could not be displayed" : "Loading photo"}
        </div>
      )}
      <figcaption className="flex items-center justify-between gap-3 border-t border-border px-4 py-3 font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">
        <span className="truncate">{name || "Letter"}</span>
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="shrink-0 text-primary transition-opacity hover:opacity-80"
        >
          Open full size
        </a>
      </figcaption>
    </figure>
  );
}