import { useState } from "react";
import { Loader2, Trash2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function IssueDeleteButton({ issue, onDeleted }) {
  const [deleting, setDeleting] = useState(false);

  const handleDelete = async () => {
    if (!window.confirm("Delete this issue? The newsletter page goes back to the empty state so you can publish a new one.")) {
      return;
    }
    setDeleting(true);
    try {
      await base44.entities.NewsletterIssue.delete(issue.id);
      onDeleted();
    } finally {
      setDeleting(false);
    }
  };

  return (
    <button
      type="button"
      onClick={handleDelete}
      disabled={deleting}
      className="flex items-center gap-2 border border-border px-4 py-2.5 font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground transition-colors hover:border-destructive/60 hover:text-destructive disabled:opacity-60"
    >
      {deleting ? <Loader2 className="h-3 w-3 animate-spin" /> : <Trash2 className="h-3 w-3" />}
      {deleting ? "Deleting" : "Delete issue"}
    </button>
  );
}