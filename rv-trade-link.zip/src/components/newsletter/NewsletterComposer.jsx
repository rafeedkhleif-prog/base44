import { useState } from "react";
import { Loader2, Paperclip, Send, Upload, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { publicMediaUrl } from "@/lib/media";

const MAX_LETTER_BYTES = 5 * 1024 * 1024;

const inputClass =
  "mt-2 w-full border border-input bg-background px-3 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-primary";
const labelClass = "font-mono text-[9px] uppercase tracking-[0.22em] text-muted-foreground";

const emptyDraft = { headline: "", message: "", ctaLabel: "Browse inventory", ctaUrl: "/equipment" };

export default function NewsletterComposer({ subscriberCount = 0, disabled = false }) {
  const [draft, setDraft] = useState(emptyDraft);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);
  const [publishedHeadline, setPublishedHeadline] = useState("");
  const [letter, setLetter] = useState(null);
  const [letterUploading, setLetterUploading] = useState(false);
  const [letterError, setLetterError] = useState("");

  const update = (field) => (event) => setDraft((prev) => ({ ...prev, [field]: event.target.value }));

  const handleLetter = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (file.size > MAX_LETTER_BYTES) {
      setLetterError("Letters must be 5 MB or smaller.");
      return;
    }
    setLetterUploading(true);
    setLetterError("");
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      setLetter({ url: publicMediaUrl(file_url), name: file.name });
    } catch (err) {
      setLetterError("That letter could not be uploaded. Try a PDF under 5 MB.");
    } finally {
      setLetterUploading(false);
    }
  };

  const handleSend = async (event) => {
    event.preventDefault();
    if (!draft.headline.trim() || !draft.message.trim()) {
      setError("Add a headline and a message before sending.");
      return;
    }
    setSending(true);
    setError("");
    setResult(null);
    setPublishedHeadline("");
    let publishedHeadline = "";
    try {
      // Publish the issue on the newsletter tab first, so it goes live even if the email step fails.
      const issue = await base44.entities.NewsletterIssue.create({
        headline: draft.headline.trim(),
        message: draft.message.trim(),
        cta_label: draft.ctaLabel,
        cta_url: draft.ctaUrl,
        issue_date: new Date().toISOString().slice(0, 10),
        ...(letter ? { letter_url: letter.url, letter_name: letter.name } : {}),
      });
      publishedHeadline = issue.headline;
      setPublishedHeadline(issue.headline);

      const response = await base44.functions.invoke("send-newsletter", {
        ...draft,
        issueId: issue.id,
        letterUrl: letter?.url || "",
        letterName: letter?.name || "",
      });
      setResult(response.data);
      setLetter(null);
    } catch (err) {
      const reason = err?.response?.data?.error || "the emails could not be sent.";
      setError(
        publishedHeadline
          ? `Published to the newsletter tab. ${reason}`
          : err?.response?.data?.error || "The newsletter could not be published. Please try again."
      );
    } finally {
      setSending(false);
    }
  };

  return (
    <form onSubmit={handleSend} className="border border-border bg-card">
      <div className="border-b border-border px-6 py-5">
        <h2 className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
          Compose email
        </h2>
      </div>
      <div className="grid gap-5 px-6 py-6">
        <div>
          <label htmlFor="headline" className={labelClass}>
            Headline *
          </label>
          <input
            id="headline"
            required
            value={draft.headline}
            onChange={update("headline")}
            placeholder="November inventory just landed"
            className={inputClass}
          />
        </div>
        <div>
          <label htmlFor="message" className={labelClass}>
            Message *
          </label>
          <textarea
            id="message"
            required
            rows={9}
            value={draft.message}
            onChange={update("message")}
            placeholder="What's new, what sold, what's arriving."
            className={`${inputClass} resize-none`}
          />
        </div>
        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label htmlFor="ctaLabel" className={labelClass}>
              Button label
            </label>
            <input
              id="ctaLabel"
              value={draft.ctaLabel}
              onChange={update("ctaLabel")}
              className={inputClass}
            />
          </div>
          <div>
            <label htmlFor="ctaUrl" className={labelClass}>
              Button link
            </label>
            <input
              id="ctaUrl"
              value={draft.ctaUrl}
              onChange={update("ctaUrl")}
              className={inputClass}
            />
          </div>
        </div>

        <div className="border-t border-border pt-5">
          <p className={labelClass}>Letter attachment (optional)</p>
          {letter ? (
            <div className="mt-2 flex items-center justify-between gap-3 border border-border bg-secondary px-3 py-3">
              <span className="flex min-w-0 items-center gap-2 text-sm">
                <Paperclip className="h-3.5 w-3.5 shrink-0 text-primary" />
                <span className="truncate">{letter.name}</span>
              </span>
              <button
                type="button"
                onClick={() => setLetter(null)}
                aria-label="Remove letter"
                className="grid h-7 w-7 shrink-0 place-items-center text-muted-foreground transition-colors hover:text-destructive"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          ) : (
            <label className="mt-2 flex cursor-pointer items-center justify-center gap-2 border border-dashed border-border px-4 py-4 font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground transition-colors hover:border-primary/60 hover:text-primary">
              {letterUploading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Upload className="h-4 w-4" />
              )}
              {letterUploading ? "Uploading" : "Upload letter"}
              <input
                type="file"
                accept=".pdf,.doc,.docx,image/*"
                onChange={handleLetter}
                disabled={letterUploading}
                className="hidden"
              />
            </label>
          )}
          <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">
            PDF, Word or image up to 5 MB. It is emailed with the issue and linked on the public
            newsletter page.
          </p>
          {letterError && (
            <p className="mt-2 text-xs leading-relaxed text-destructive">{letterError}</p>
          )}
        </div>
      </div>
      <div className="border-t border-border px-6 py-6">
        {error && (
          <p className="mb-4 border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs leading-relaxed text-destructive">
            {error}
          </p>
        )}
        {publishedHeadline && (
          <p className="mb-4 border border-primary/40 bg-primary/5 px-3 py-2 text-xs leading-relaxed">
            Published to the newsletter tab: {publishedHeadline}
          </p>
        )}
        {result && (
          <p className="mb-4 border border-primary/40 bg-primary/5 px-3 py-2 text-xs leading-relaxed">
            Sent to {result.sent} of {result.total} subscribers
            {result.failed ? ` · ${result.failed} failed` : ""}.
          </p>
        )}
        <button
          type="submit"
          disabled={sending || disabled}
          className="flex w-full items-center justify-center gap-2 bg-accent px-6 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-accent-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
        >
          {sending ? (
            <>
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
              Sending
            </>
          ) : (
            <>
              <Send className="h-3.5 w-3.5" />
              Send to {subscriberCount} subscribers
            </>
          )}
        </button>
      </div>
    </form>
  );
}