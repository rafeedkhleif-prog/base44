import { Check, Recycle } from "lucide-react";

const ACCEPTED = [
  "Broken stretchers, gurneys and hospital beds",
  "Exam and procedure tables that no longer adjust",
  "Non-working monitors, pumps and defibrillators",
  "Wheelchairs with bent frames or dead motors",
  "Obsolete units and leftover parts inventory",
];

const STEPS = [
  { index: "01", title: "Send the details", body: "Tell us what you have and where it sits." },
  { index: "02", title: "We confirm", body: "A coordinator calls to lock a pickup window." },
  { index: "03", title: "We haul it out", body: "Our crew loads it and recycles what can be recovered." },
];

export default function RecycleScope() {
  return (
    <div>
      <div className="border border-border bg-card p-6 md:p-8">
        <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.22em] text-primary">
          <Recycle className="h-3.5 w-3.5" />
          What we take
        </div>
        <ul className="mt-5 space-y-3">
          {ACCEPTED.map((item) => (
            <li key={item} className="flex gap-3 text-sm leading-relaxed text-muted-foreground">
              <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
        <p className="mt-5 border-t border-border pt-4 text-xs leading-relaxed text-muted-foreground">
          Anything too far gone to repair is stripped down — metal, electronics and usable components
          are recovered instead of going to a landfill.
        </p>
      </div>

      <div className="mt-6 grid gap-6 border-t border-border pt-6 sm:grid-cols-3">
        {STEPS.map((step) => (
          <div key={step.index}>
            <span className="font-mono text-[10px] tracking-[0.24em] text-primary">{step.index}</span>
            <h3 className="mt-2 font-heading text-sm font-semibold uppercase tracking-[0.03em]">
              {step.title}
            </h3>
            <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">{step.body}</p>
          </div>
        ))}
      </div>
    </div>
  );
}