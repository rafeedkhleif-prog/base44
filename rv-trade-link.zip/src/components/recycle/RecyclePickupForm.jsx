import { useState } from "react";
import { format, startOfMonth } from "date-fns";
import { Loader2, Truck } from "lucide-react";
import { base44 } from "@/api/base44Client";
import AvailabilityCalendar from "@/components/repair/AvailabilityCalendar";
import useCalendarAvailability from "@/hooks/useCalendarAvailability";

const EQUIPMENT = [
  "Stretchers & Gurneys",
  "Hospital Beds",
  "Exam & Procedure Tables",
  "Surgical Tables",
  "Wheelchairs",
  "Monitors & Pumps",
  "Other equipment",
];

const inputClass =
  "mt-2 w-full border border-input bg-background px-3 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-primary";
const labelClass = "font-mono text-[9px] uppercase tracking-[0.22em] text-muted-foreground";

const emptyForm = {
  name: "",
  organization: "",
  email: "",
  phone: "",
  equipment: "",
  location: "",
  details: "",
  preferred_date: "",
};

export default function RecyclePickupForm() {
  const [form, setForm] = useState(emptyForm);
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");
  const [month, setMonth] = useState(startOfMonth(new Date()));
  const availability = useCalendarAvailability("pickup-availability");

  const update = (field) => (event) =>
    setForm((prev) => ({ ...prev, [field]: event.target.value }));

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.details.trim()) {
      setError("Add your name, email and what we're picking up so we can schedule it.");
      return;
    }
    if (!form.preferred_date) {
      setError("Pick an available day for the pickup.");
      return;
    }
    if (availability.unavailableDates.has(form.preferred_date)) {
      setError("That day is unavailable. Please choose another available date.");
      return;
    }
    setStatus("saving");
    setError("");
    try {
      const live = await availability.refresh();
      if (live?.has(form.preferred_date)) {
        setStatus("idle");
        setForm((prev) => ({ ...prev, preferred_date: "" }));
        setError("That day was just taken. Please choose another available date.");
        return;
      }
      await base44.entities.ServiceRequest.create({
        ...form,
        request_type: "pickup",
        status: "new",
      });
      setStatus("sent");
    } catch (err) {
      setStatus("idle");
      setError("We couldn't send that. Please call 1-818-899-8090.");
    }
  };

  if (status === "sent") {
    return (
      <div className="border border-primary/40 bg-card p-8">
        <div className="font-mono text-[10px] uppercase tracking-[0.24em] text-primary">
          Pickup requested
        </div>
        <h2 className="mt-3 font-heading text-2xl font-semibold uppercase tracking-[0.02em]">
          We'll call to set the pickup
        </h2>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          {form.preferred_date
            ? `You asked for ${format(new Date(`${form.preferred_date}T12:00:00`), "MMMM d, yyyy")}. We'll call to confirm the equipment and the pickup window, usually within one business day.`
            : "Our team will confirm the equipment and a pickup window, usually within one business day."}
        </p>
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <a
            href="tel:+18188998090"
            className="bg-primary px-5 py-3 text-center font-mono text-[10px] uppercase tracking-[0.2em] text-primary-foreground"
          >
            Call 1-818-899-8090
          </a>
          <button
            type="button"
            onClick={() => {
              setForm(emptyForm);
              setStatus("idle");
            }}
            className="border border-border px-5 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-foreground"
          >
            Request another pickup
          </button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="border border-border bg-card p-6 md:p-8">
      <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
        <Truck className="h-3.5 w-3.5 text-primary" />
        Book an equipment pickup
      </div>

      <div className="mt-6 grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="rc-name" className={labelClass}>
            Name *
          </label>
          <input id="rc-name" required value={form.name} onChange={update("name")} className={inputClass} />
        </div>
        <div>
          <label htmlFor="rc-organization" className={labelClass}>
            Facility
          </label>
          <input
            id="rc-organization"
            value={form.organization}
            onChange={update("organization")}
            placeholder="Clinic or hospital"
            className={inputClass}
          />
        </div>
        <div>
          <label htmlFor="rc-email" className={labelClass}>
            Email *
          </label>
          <input
            id="rc-email"
            type="email"
            required
            value={form.email}
            onChange={update("email")}
            placeholder="you@clinic.com"
            className={inputClass}
          />
        </div>
        <div>
          <label htmlFor="rc-phone" className={labelClass}>
            Phone
          </label>
          <input
            id="rc-phone"
            type="tel"
            value={form.phone}
            onChange={update("phone")}
            placeholder="(818) 000-0000"
            className={inputClass}
          />
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="rc-equipment" className={labelClass}>
            Equipment type
          </label>
          <select
            id="rc-equipment"
            value={form.equipment}
            onChange={update("equipment")}
            className={inputClass}
          >
            <option value="">Select equipment</option>
            {EQUIPMENT.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="rc-location" className={labelClass}>
            Pickup address
          </label>
          <input
            id="rc-location"
            value={form.location}
            onChange={update("location")}
            placeholder="Address, city, ZIP"
            className={inputClass}
          />
        </div>
        <div className="sm:col-span-2">
          <div className="flex items-baseline justify-between gap-3">
            <span className={labelClass}>Pickup date *</span>
            {form.preferred_date && (
              <button
                type="button"
                onClick={() => setForm((prev) => ({ ...prev, preferred_date: "" }))}
                className="font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground transition-colors hover:text-foreground"
              >
                Clear date
              </button>
            )}
          </div>
          <div className="mt-2">
            {availability.loading ? (
              <div className="h-72 animate-pulse border border-border bg-secondary" />
            ) : (
              <AvailabilityCalendar
                month={month}
                onMonthChange={setMonth}
                unavailableDates={availability.unavailableDates}
                selected={form.preferred_date}
                onSelect={(key) => setForm((prev) => ({ ...prev, preferred_date: key }))}
              />
            )}
          </div>
          <p className="mt-3 font-mono text-[9px] uppercase leading-relaxed tracking-[0.14em] text-muted-foreground">
            Crossed-out days are already booked or closed. We confirm every pickup by phone.
          </p>
          {availability.error && (
            <p className="mt-2 text-xs leading-relaxed text-destructive">{availability.error}</p>
          )}
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="rc-details" className={labelClass}>
            What are we picking up? *
          </label>
          <textarea
            id="rc-details"
            required
            rows={4}
            value={form.details}
            onChange={update("details")}
            placeholder="E.g. 3 broken Stryker gurneys, non-working hydraulic pedals. Loading dock access, ground floor."
            className={`${inputClass} resize-none`}
          />
        </div>
      </div>

      {error && (
        <p className="mt-4 border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs leading-relaxed text-destructive">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={status === "saving"}
        className="mt-6 flex w-full items-center justify-center gap-2 bg-primary px-6 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
      >
        {status === "saving" ? (
          <>
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            Sending
          </>
        ) : (
          "Request pickup"
        )}
      </button>
      <p className="mt-3 text-center font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
        Broken is fine · We confirm every pickup by phone
      </p>
    </form>
  );
}