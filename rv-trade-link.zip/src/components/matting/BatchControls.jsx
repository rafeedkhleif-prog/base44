import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { Link } from "react-router-dom";

export default function BatchControls({ counts, audit, building, running, onBuild, onRun, onStop }) {
  return (
    <div className="rounded-xl border border-rule bg-shell p-5">
      {audit && <p className="mb-4 text-[13px] leading-relaxed text-ink-body">
        Audited {audit.listings.toLocaleString()} active listings: {audit.gallerySlots.toLocaleString()} slots,
        {" "}{audit.skipped} exact approved cover skipped, {audit.eligibleSlots.toLocaleString()} eligible slots,
        {" "}{audit.uniqueOriginals.toLocaleString()} unique originals. Duplicate originals share processing, not gallery slots.
      </p>}
      <div className="flex flex-wrap items-center gap-x-6 gap-y-3 font-mono text-[10px] uppercase tracking-[0.12em] text-ink-meta">
        {["queued", "processing", "done", "applied", "failed", "review", "conflicted", "remaining"].map(key => <span key={key}>{key} {counts[key] ?? 0}</span>)}
      </div>
      <p className="mt-2 text-[11px] text-ink-faint">Totals count saved gallery slots. Done includes verified applied slots; remaining includes failed, review, conflict and rollback slots.</p>
      <div className="mt-4 flex flex-wrap gap-2.5">
        <Button variant="outline" onClick={onBuild} disabled={building || running} className="rounded-full">
          {building ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : null}
          {building ? "Queueing photos…" : "Build queue"}
        </Button>
        <Link to="/matting-pilot" className="self-center px-2 text-[13px] text-sage underline">Inspect pilot</Link>
        <Button onClick={onRun} disabled={building || running || !counts.pilotApproved || !(counts.queued || counts.ready || counts.processing)} className="rounded-full">
          {running ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : null}
          {running ? "Processing and applying…" : "Run and apply verified photos"}
        </Button>
        {running && (
          <Button variant="ghost" onClick={onStop} className="rounded-full">
            Stop after this photo
          </Button>
        )}
      </div>
      {!counts.pilotApproved && <p className="mt-3 text-[12px] text-primary">Production is locked. Run and approve the actual 512 browser pilot first.</p>}
      <p className="mt-3 text-[12px] leading-relaxed text-ink-faint">
        Keep this tab open and the device awake for the entire run. Closing it stops processing.
        Progress, original galleries and mappings persist; an interrupted claim resumes after its 15-minute lease expires.
        Studio originals apply immediately. Segmented previews require approval; unsafe results never replace originals.
      </p>
    </div>
  );
}