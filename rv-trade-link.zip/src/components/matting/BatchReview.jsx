import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import BatchQueueList from "@/components/matting/BatchQueueList";
export default function BatchReview({ revision, running, onAction }) {
  const [filter, setFilter] = useState("pending"), [page, setPage] = useState(null), [rows, setRows] = useState([]), [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const load = async (cursor) => {
    setLoading(true); setError("");
    try {
      const status = filter === "pending" ? { $in: ["review", "failed", "conflicted", "rolled_back"] } : filter === "applied" ? "applied" : { $ne: "skipped" };
      const next = await base44.entities.PhotoSlot.filter({ current: true, status }, { sort: "-updated_date", limit: 20, ...(cursor ? { cursor } : {}) });
      setPage(next); setRows(old => cursor ? [...old, ...next.items] : next.items);
    } catch (e) { setError(e.message); } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [revision, filter]);
  return <section className="mt-10">
    <div className="flex flex-wrap items-center justify-between gap-3">
      <h2 className="text-[11px] uppercase tracking-[0.16em] text-ink-faint">Gallery slot mappings</h2>
      <select aria-label="Photo status" value={filter} onChange={e => setFilter(e.target.value)} className="rounded-lg border border-rule bg-shell p-2 text-[12px]">
        <option value="pending">Review, failed and conflicted</option><option value="applied">Applied and rollback</option><option value="all">All pending and completed slots</option>
      </select>
    </div>
    {error && <p className="mt-3 text-sm text-primary">{error}</p>}
    <div className="mt-3"><BatchQueueList rows={rows} disabled={running || loading} onAction={onAction} /></div>
    {loading && <p className="mt-3 text-sm text-ink-meta">Loading mappings…</p>}
    {page?.has_more && <button disabled={loading} onClick={() => load(page.next_cursor)} className="mt-3 text-sm text-sage underline">Load more</button>}
  </section>;
}