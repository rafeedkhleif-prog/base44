export default function PilotMetrics({ photo }) {
  const diagnostic = photo.diagnostics;
  if (!diagnostic) return null;
  const m = diagnostic.maskQuality;
  return <div className="mt-3 space-y-2 text-[11px] leading-relaxed text-ink-body">
    <p>Model-mask kept: {m.keptPixels}/{m.totalPixels} ({(m.coverage * 100).toFixed(4)}%). Composite ink: {(photo.inkShare * 100).toFixed(4)}%.</p>
    <p>Confident-alpha share: {(m.confidence * 100).toFixed(4)}%. Uncertain: {(m.uncertainShare * 100).toFixed(4)}%. Central detail retention: {(m.detailRetention * 100).toFixed(4)}% (required 85%).</p>
    <p>Bounds: {m.bounds ? `${m.bounds.left},${m.bounds.top} to ${m.bounds.right},${m.bounds.bottom}, inclusive at 512×512` : 'empty mask'}.</p>
    {photo.method === 'white-original' && <p>White original preserved. Model-mask checks below are diagnostic only and are not applied to this original.</p>}
    <p>The detail check counts all central horizontal contrast, including possible background edges. Confident alpha is not proof that equipment details survived.</p>
    <p className="font-medium text-ink">Exact browser values, including logits quantiles</p>
    <pre className="max-h-96 overflow-auto rounded-lg border border-rule bg-card p-2 font-mono text-[10px] whitespace-pre-wrap break-all">{JSON.stringify({ finalOutput: { coverage: photo.coverage, inkShare: photo.inkShare, detailRetention: photo.detailRetention, qualityAccepted: photo.qualityAccepted }, ...diagnostic }, null, 2)}</pre>
    {photo.nativeComparison && <>
      <p className="font-medium text-ink">Native CPU vs browser, byte-identical reference input</p>
      <pre className="max-h-96 overflow-auto rounded-lg border border-rule bg-card p-2 font-mono text-[10px] whitespace-pre-wrap break-all">{JSON.stringify(photo.nativeComparison, null, 2)}</pre>
    </>}
    {!photo.nativeComparison && <p>Native/browser comparison pending.</p>}
  </div>;
}