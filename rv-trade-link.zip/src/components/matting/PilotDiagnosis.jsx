import { MODEL_REVISION, MODEL_SHA256 } from '@/lib/mattingModel';
export default function PilotDiagnosis() {
  return <section className="mt-4 rounded-lg border border-rule bg-shell p-4 text-[12px] leading-relaxed text-ink-body">
    <p className="font-medium text-ink">Confirmed native quality limitation, not a graph execution failure</p>
    <p className="mt-1">The pinned fp32 graph produces Stryker 1005 detail retention 0.8312049992025321 and ultrasound 0.8361905793122288. Both fail the unchanged 0.85 requirement; their confident-alpha shares are 0.9742050170898438 and 0.9849395751953125. The message was hiding which guard failed.</p>
    <p className="mt-2">Input goes straight to Conv, with no embedded RGB rescaling or ImageNet normalization. The publisher requires 1/255 and ImageNet normalization once. Output is a final Conv with raw logits, so one external sigmoid is correct. Shapes are [1,3,512,512] to [1,1,512,512], row-major; square resizing maps back to the source rectangle without padding or a crop.</p>
    <p className="mt-2">The 512 model and scene-wide contrast heuristic cannot confirm preservation of every label, cable, or wheel. Background contrast can affect the retention score. No thresholds are reduced, and these candidates are not safe to approve automatically.</p>
    <p className="mt-2">Run the pilot to see rejected composites and measured browser values. A second inference uses the native CPU reference's exact RGBA bytes and compares every logit, with input and reference checksums. Canvas-vs-native resize differences are shown separately, not misreported as a runtime mismatch.</p>
    <p className="mt-2 font-medium text-primary">Diagnostic mode: pilot approval is disabled. Production remains locked, and this page makes no gallery or queue writes.</p>
    <p className="mt-2 break-all font-mono text-[10px]">Pinned revision: {MODEL_REVISION}<br />Inspected fp32 graph SHA-256: {MODEL_SHA256}</p>
  </section>;
}