import { Image } from "@/components/ui/image";
import { publicMediaUrl } from "@/lib/media";
export default function BatchQueueList({ rows, disabled, onAction }) {
  if (!rows.length) return <p className="rounded-xl border border-rule bg-shell px-5 py-8 text-center text-[13px] text-ink-meta">No slots in this view.</p>;
  return <ul className="divide-y divide-rule overflow-hidden rounded-xl border border-rule bg-shell">
    {rows.map(row => <li key={row.id} className="flex flex-wrap items-center gap-4 p-3">
      <Image src={publicMediaUrl(row.output_url || row.source_url)} alt={row.listing_title || "Equipment photo"} fittingType="fit" className="h-16 w-16 shrink-0 rounded-lg border border-rule bg-card object-contain" />
      <div className="min-w-0 flex-1">
        <p className="truncate text-[13px] text-ink">{row.listing_title}</p>
        <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.1em] text-ink-meta">Slot {row.slot_index + 1} · {row.status}</p>
        {row.error && <p className="mt-1 text-[11px] text-primary">{row.error}</p>}
        <div className="mt-1 flex gap-3 text-[11px] text-sage">
          <a href={row.source_url} target="_blank" rel="noreferrer" className="underline">Original</a>
          {row.output_url && <a href={row.output_url} target="_blank" rel="noreferrer" className="underline">Result</a>}
        </div>
      </div>
      <div className="flex flex-wrap gap-3 text-[11px] text-sage">
        {row.status === "review" && <button disabled={disabled} onClick={() => onAction("approve", row)} className="underline disabled:opacity-40">Approve and apply</button>}
        {["failed", "conflicted", "rolled_back"].includes(row.status) && <button disabled={disabled} onClick={() => onAction("retry", row)} className="underline disabled:opacity-40">Retry mapped photo</button>}
        {row.status === "applied" && <button disabled={disabled} onClick={() => onAction("rollback", row)} className="underline disabled:opacity-40">Restore original gallery</button>}
      </div>
    </li>)}
  </ul>;
}