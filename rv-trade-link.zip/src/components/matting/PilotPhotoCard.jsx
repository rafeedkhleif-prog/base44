import PilotFrame from '@/components/matting/PilotFrame';
import PilotStage from '@/components/matting/PilotStage';
import PilotMetrics from '@/components/matting/PilotMetrics';

export default function PilotPhotoCard({ photo }) {
  return (
    <div className="rounded-xl border border-rule bg-shell p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-[14px] text-ink">{photo.title}</p>
          <p className="mt-0.5 font-mono text-[10px] uppercase tracking-[0.1em] text-ink-meta">
            {photo.kind} · {photo.listingId}
          </p>
        </div>
        <PilotStage stage={photo.stage} />
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2">
        <PilotFrame url={photo.previewUrl} label="Original, decoded" empty={photo.stage === 'decoding' ? 'Decoding…' : 'Not decoded yet'} />
        <PilotFrame url={photo.resultUrl} label={photo.qualityAccepted === false ? 'Rejected candidate, not applied' : 'White + logo'} empty={photo.stage === 'error' ? 'No candidate available' : 'Pending'} />
        {photo.maskPreviewUrl && <PilotFrame url={photo.maskPreviewUrl} label="Browser model alpha" />}
        {photo.nativeResultUrl && <PilotFrame url={photo.nativeResultUrl} label="Native CPU candidate, not applied" />}
      </div>

      {photo.dims && <p className="mt-2 font-mono text-[10px] text-ink-meta">source {photo.dims.source} · mask {photo.dims.mask || 'pending'} · {photo.method === 'white-original' ? 'Original preserved' : 'Segmented candidate'}</p>}
      <PilotMetrics photo={photo} />
      {photo.error && (
        <p className="mt-2 rounded-lg bg-primary/5 px-2.5 py-2 font-mono text-[11px] leading-relaxed text-primary">
          {photo.error}
        </p>
      )}
      {['done', 'rejected'].includes(photo.stage) && (
        <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.1em] text-ink-meta">
          {(photo.ms / 1000).toFixed(1)}s · {(photo.bytes / 1024).toFixed(0)} KB
        </p>
      )}
    </div>
  );
}