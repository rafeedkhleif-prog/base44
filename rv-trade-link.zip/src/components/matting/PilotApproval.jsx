import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { photoBatch } from "@/lib/photoBatchClient";
import { MODEL_ID, PIPELINE_VERSION } from "@/lib/mattingModel";

export default function PilotApproval({ photos, onApproved }) {
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [approved, setApproved] = useState(false);
  const ready = photos.length === 3 && photos.every(p => p.engineConfirmed === true && p.resultUrl);

  const approve = async () => {
    if (!window.confirm("Approve production: the three inspected previews keep the full equipment, labels and edges intact. Every queued gallery slot will get a clean background.")) return;
    setSaving(true);
    setError("");
    try {
      await photoBatch("approvePilot", {
        model_id: MODEL_ID,
        version: PIPELINE_VERSION,
        backend: "wasm",
        dtype: "fp32",
        samples: photos.map(p => ({ source_url: p.originalUrl, engineConfirmed: true, outputReady: true })),
      });
      setApproved(true);
      onApproved?.();
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mt-4">
      <Button onClick={approve} disabled={!ready || saving || approved} variant={approved ? "outline" : "default"} className="rounded-full">
        {saving ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : null}
        {approved ? "Production approved" : saving ? "Approving…" : "Run all three, then approve production"}
      </Button>
      {!ready && !approved && (
        <p className="mt-2 font-mono text-[10px] uppercase tracking-[0.12em] text-ink-meta">
          Approval unlocks once all three previews finish in this browser
        </p>
      )}
      {approved && (
        <p className="mt-2 text-[12px] leading-relaxed text-ink-body">
          Approved. Open the batch to queue the remaining photos and run them.
        </p>
      )}
      {error && <p className="mt-2 font-mono text-[11px] leading-relaxed text-primary">{error}</p>}
    </div>
  );
}