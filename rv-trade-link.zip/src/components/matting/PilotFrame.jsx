import { Image } from '@/components/ui/image';
export default function PilotFrame({ url, label, empty = 'Pending' }) {
  return <div className="overflow-hidden rounded-lg border border-rule bg-card">
    {url ? <a href={url} target="_blank" rel="noreferrer" className="block" aria-label={`Open ${label}`}><Image src={url} alt={label} fittingType="fit" className="h-40 w-full object-contain" /></a> : <div className="grid h-40 place-items-center px-3 text-center text-[11px] text-ink-meta">{empty}</div>}
    <p className="border-t border-rule bg-panel px-2 py-1 text-[10px] uppercase tracking-[0.1em] text-ink-meta">{label}</p>
  </div>;
}