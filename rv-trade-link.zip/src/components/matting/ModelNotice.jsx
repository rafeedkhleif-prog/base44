import { MODEL_ID, MODEL_REVISION, MODEL_LICENSE } from "@/lib/mattingModel";
export default function ModelNotice() {
  return <details className="mt-6 text-[11px] text-ink-faint">
    <summary className="cursor-pointer">512 browser model metadata and MIT notices</summary>
    <p className="mt-2 break-all">{MODEL_ID} · revision {MODEL_REVISION} · onnx/model.onnx · WASM fp32 · RGB NCHW [1,3,512,512] · logits and sigmoid.</p>
    <a href={`https://huggingface.co/${MODEL_ID}`} target="_blank" rel="noreferrer" className="mt-1 inline-block text-sage underline">Publisher model card</a>
    <pre className="mt-3 whitespace-pre-wrap font-mono text-[10px] leading-relaxed">{MODEL_LICENSE}</pre>
  </details>;
}