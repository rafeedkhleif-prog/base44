import { Loader2, Check, AlertTriangle } from 'lucide-react';
const LABELS = { idle: 'Not started', decoding: 'Decoding photo', checking: 'Checking white background', loading: 'Loading 512 WASM', normalizing: 'Normalizing 512 RGB', inference: 'Running 512 WASM', reading: 'Reading logits', validating: 'Verifying mask', masking: 'Preparing 512 engine', composing: 'Compositing', comparing: 'Comparing native output', done: 'Preview ready', rejected: 'Quality rejected', error: 'Failed' };
export default function PilotStage({ stage }) {
  return <span className="flex shrink-0 items-center gap-1.5 text-[11px] uppercase tracking-[0.1em] text-ink-faint">
    {stage === 'done' ? <Check className="h-3.5 w-3.5 text-sage" /> : ['error', 'rejected'].includes(stage) ? <AlertTriangle className="h-3.5 w-3.5 text-primary" /> : stage !== 'idle' ? <Loader2 className="h-3.5 w-3.5 animate-spin text-ink-faint" /> : null}
    {LABELS[stage] || stage}
  </span>;
}