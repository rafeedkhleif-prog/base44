import { Link } from "react-router-dom";
import { Trash2 } from "lucide-react";
import { Image } from "@/components/ui/image";
import { formatPriceExact } from "@/lib/format";
import { publicMediaUrl } from "@/lib/media";
import { listingPhoto } from "@/data/categoryPhotos";

export default function CartLine({ listing, onRemove }) {
  const image = publicMediaUrl(listingPhoto(listing));
  const available =
    listing.status === "active" && (listing.quantity ?? 1) > 0 && !listing.price_on_request;

  return (
    <div className="flex gap-4 border-b border-border py-5">
      <Link
        to={`/equipment/${listing.id}`}
        className="h-24 w-28 shrink-0 overflow-hidden border border-border bg-background"
      >
        {image ? (
          <Image src={image} alt={listing.title} fittingType="fill" className="h-full w-full" />
        ) : (
          <div className="grid h-full place-items-center font-mono text-[9px] uppercase tracking-[0.14em] text-muted-foreground">
            No image
          </div>
        )}
      </Link>

      <div className="flex flex-1 flex-col">
        <span className="font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
          {listing.brand || "Medical equipment"}
        </span>
        <Link
          to={`/equipment/${listing.id}`}
          className="mt-1 font-heading text-sm font-semibold uppercase leading-snug transition-colors hover:text-primary"
        >
          {listing.title}
        </Link>
        <span className="mt-1 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
          {listing.location || "Pacoima, CA"} · 1 unit
        </span>

        {!available && (
          <span className="mt-2 font-mono text-[9px] uppercase leading-relaxed tracking-[0.14em] text-destructive">
            {listing.price_on_request
              ? "Priced by phone — call 1-818-899-8090 to buy this unit"
              : "No longer available"}
          </span>
        )}

        <div className="mt-auto flex items-end justify-between gap-3 pt-3">
          <span className="font-mono text-sm text-primary">
            {listing.price_on_request ? "Call for price" : formatPriceExact(listing.price)}
          </span>
          <button
            type="button"
            onClick={() => onRemove(listing.id)}
            className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground transition-colors hover:text-destructive"
          >
            <Trash2 className="h-3 w-3" />
            Remove
          </button>
        </div>
      </div>
    </div>
  );
}