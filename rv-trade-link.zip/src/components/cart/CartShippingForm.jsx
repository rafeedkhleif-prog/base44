const FIELD =
  "mt-1.5 w-full border border-border bg-background px-3 py-2.5 font-mono text-[12px] text-foreground outline-none transition-colors focus:border-primary";
const LABEL = "font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground";

// The delivery address the order ships to. It is what the shipping rate is priced on, and it is
// saved with the order so the shop knows where the equipment goes.
export default function CartShippingForm({ address, onChange, complete }) {
  const set = (field) => (event) => onChange(field, event.target.value);

  return (
    <div className="mt-5 border-t border-border pt-5">
      <div className="font-mono text-[9px] uppercase tracking-[0.24em] text-muted-foreground">
        Delivery address
      </div>

      <label className="mt-3 block">
        <span className={LABEL}>Street address</span>
        <input
          value={address.street}
          onChange={set("street")}
          placeholder="Street and number, suite"
          autoComplete="street-address"
          className={FIELD}
        />
      </label>

      <div className="mt-3 grid grid-cols-[1.6fr_1fr] gap-3">
        <label className="block">
          <span className={LABEL}>City</span>
          <input
            value={address.city}
            onChange={set("city")}
            autoComplete="address-level2"
            className={FIELD}
          />
        </label>
        <label className="block">
          <span className={LABEL}>State</span>
          <input
            value={address.state}
            onChange={set("state")}
            autoComplete="address-level1"
            maxLength={20}
            className={FIELD}
          />
        </label>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-3">
        <label className="block">
          <span className={LABEL}>ZIP</span>
          <input
            value={address.zip}
            onChange={(event) =>
              onChange("zip", event.target.value.replace(/[^0-9]/g, "").slice(0, 5))
            }
            inputMode="numeric"
            autoComplete="postal-code"
            placeholder="90001"
            className={FIELD}
          />
        </label>
        <label className="block">
          <span className={LABEL}>Address type</span>
          <select
            value={address.destinationType}
            onChange={set("destinationType")}
            className={FIELD}
          >
            <option value="residential">Residential</option>
            <option value="commercial">Commercial</option>
          </select>
        </label>
      </div>

      {!complete && (
        <p className="mt-2 font-mono text-[9px] uppercase leading-relaxed tracking-[0.14em] text-muted-foreground">
          Street, city, state and ZIP are needed to price shipping
        </p>
      )}
    </div>
  );
}