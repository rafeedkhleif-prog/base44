import { formatCents } from "@/lib/formatCents";
import ShippingInvoiceForm from "@/components/orders/ShippingInvoiceForm";
import { MapPin, Package, Truck } from "lucide-react";
import QuickBooksLinks from "@/components/orders/QuickBooksLinks";

const SHIPPING_LABEL = {
  included: "Shipping charged with the item",
  pending: "Item paid · shipping not charged yet",
  invoiced: "Shipping invoiced · awaiting payment",
  paid: "Shipping paid",
};

const MODE_LABEL = {
  rated: "Rated at checkout",
  freight: "Freight · invoiced separately",
  invoiced_later: "No rate available · invoiced separately",
};

const money = (value) => {
  const amount = Number(value);
  return Number.isFinite(amount) ? `$${amount.toFixed(2)}` : "—";
};

export default function OrderRow({ purchase, onInvoiced }) {
  const shippingStatus = purchase.shippingPaymentStatus || "pending";
  const needsInvoice = shippingStatus === "pending" || shippingStatus === "invoiced";
  const paidAt = purchase.paidAt || purchase.created_date;
  const dateLabel = paidAt
    ? new Date(paidAt).toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
      })
    : "—";

  const shippingFigure =
    shippingStatus === "included"
      ? money(purchase.shippingAmount)
      : shippingStatus === "paid"
        ? formatCents(purchase.shippingInvoicedCents)
        : shippingStatus === "invoiced"
          ? `${formatCents(purchase.shippingInvoicedCents)} invoiced`
          : "Pending";

  return (
    <div className="border border-border bg-card px-5 py-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="font-heading text-base font-semibold tracking-tight">
            {purchase.productName || "Equipment"}
          </div>
          <div className="mt-1 font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
            {purchase.buyerName || purchase.buyerEmail || "Buyer not on file"} · {dateLabel}
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-3 font-mono text-[9px] uppercase tracking-[0.14em] text-muted-foreground">
            <span>Order {purchase.orderId || purchase.checkoutSessionId}</span>
            <QuickBooksLinks />
          </div>
          {purchase.shipTo && (
            <div className="mt-1.5 flex items-start gap-1.5 font-mono text-[10px] uppercase tracking-[0.12em] text-muted-foreground">
              <MapPin className="mt-0.5 h-3 w-3 shrink-0" />
              <span>
                Ship to {purchase.shipTo}
                {purchase.destinationType ? ` · ${purchase.destinationType}` : ""}
              </span>
            </div>
          )}
        </div>
        <div className="flex flex-wrap gap-2">
          <span
            className={`inline-flex items-center gap-1.5 border px-2 py-1 font-mono text-[9px] uppercase tracking-[0.16em] ${
              purchase.status === "paid"
                ? "border-primary/40 bg-primary/5 text-primary"
                : "border-border bg-muted text-muted-foreground"
            }`}
          >
            <Package className="h-3 w-3" />
            {purchase.status === "paid" ? "Item paid" : `Item ${purchase.status || "pending"}`}
          </span>
          <span className="inline-flex items-center gap-1.5 border border-border px-2 py-1 font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
            <Truck className="h-3 w-3" />
            {SHIPPING_LABEL[shippingStatus] || shippingStatus}
          </span>
        </div>
      </div>

      <div className="mt-4 grid gap-3 border-t border-border pt-4 sm:grid-cols-3">
        <div>
          <div className="font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">
            Item
          </div>
          <div className="mt-1 font-mono text-[13px]">{money(purchase.itemAmount || purchase.amount)}</div>
        </div>
        <div>
          <div className="font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">
            Shipping
          </div>
          <div className="mt-1 font-mono text-[13px]">{shippingFigure}</div>
        </div>
        <div>
          <div className="font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">
            Shipping mode
          </div>
          <div className="mt-1 font-mono text-[11px] uppercase tracking-[0.08em] text-muted-foreground">
            {MODE_LABEL[purchase.shippingMode] || "—"}
          </div>
        </div>
      </div>

      {needsInvoice && (
        <ShippingInvoiceForm purchase={purchase} onInvoiced={onInvoiced} />
      )}
    </div>
  );
}