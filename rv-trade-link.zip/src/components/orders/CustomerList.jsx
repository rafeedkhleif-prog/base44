import { formatCents } from "@/lib/formatCents";
import { Mail } from "lucide-react";

export default function CustomerList({ customers }) {
  if (!customers.length) {
    return (
      <p className="border border-border bg-card px-5 py-8 text-center font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
        No customers yet
      </p>
    );
  }

  return (
    <div className="divide-y divide-border border border-border bg-card">
      {customers.map((customer) => (
        <div
          key={customer.id}
          className="flex flex-wrap items-center justify-between gap-3 px-5 py-4"
        >
          <div className="min-w-0">
            <div className="flex items-center gap-2 font-heading text-[15px] font-medium">
              {customer.name || customer.email}
            </div>
            <div className="mt-1 flex items-center gap-1.5 font-mono text-[10px] tracking-[0.06em] text-muted-foreground">
              <Mail className="h-3 w-3" />
              {customer.email}
            </div>
          </div>
          <div className="flex items-center gap-6 font-mono text-[11px]">
            <div className="text-right">
              <div className="text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
                Orders
              </div>
              <div className="mt-1">{customer.ordersCount ?? 0}</div>
            </div>
            <div className="text-right">
              <div className="text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
                Paid
              </div>
              <div className="mt-1">{formatCents(customer.totalPaidCents || 0)}</div>
            </div>
            <div className="hidden text-right sm:block">
              <div className="text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
                Last order
              </div>
              <div className="mt-1">
                {customer.lastOrderAt
                  ? new Date(customer.lastOrderAt).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })
                  : "—"}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}