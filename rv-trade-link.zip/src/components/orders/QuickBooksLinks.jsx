import { ExternalLink } from "lucide-react";

// QuickBooks Online opens straight into the matching transaction form, so the same
// order can be keyed in as a sales receipt, an invoice or a payment.
const LINKS = [
  { label: "QB order", href: "https://qbo.intuit.com/app/salesreceipt" },
  { label: "QB invoice", href: "https://qbo.intuit.com/app/invoice" },
  { label: "QB payment", href: "https://qbo.intuit.com/app/recvpayment" },
];

export default function QuickBooksLinks() {
  return (
    <span className="flex flex-wrap items-center gap-3">
      {LINKS.map((link) => (
        <a
          key={link.label}
          href={link.href}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 border-b border-muted-foreground/40 pb-0.5 transition-colors hover:border-primary hover:text-primary"
        >
          {link.label}
          <ExternalLink className="h-3 w-3" />
        </a>
      ))}
    </span>
  );
}