import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Check, Copy, Loader2, Send } from "lucide-react";

const inputClass =
  "mt-1 w-full border border-border bg-background px-3 py-2 font-mono text-[12px] tracking-[0.04em] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary";

export default function ShippingInvoiceForm({ purchase, onInvoiced }) {
  const [amount, setAmount] = useState("");
  const [service, setService] = useState(
    purchase.shippingMode === "freight" ? "LTL freight" : "UPS Ground"
  );
  const [notes, setNotes] = useState("");
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);

  const submit = async (event) => {
    event.preventDefault();
    const cents = Math.round(Number(amount) * 100);
    if (!Number.isSafeInteger(cents) || cents < 50) {
      setError("Enter the shipping amount, at least $0.50.");
      return;
    }
    setStatus("loading");
    setError("");
    try {
      const response = await base44.functions.invoke("send-shipping-invoice", {
        purchaseId: purchase.id,
        amountCents: cents,
        service,
        notes,
      });
      setResult(response?.data ?? null);
      setAmount("");
      setStatus("idle");
      onInvoiced?.();
    } catch (err) {
      setStatus("idle");
      setError(err?.response?.data?.error || "The invoice could not be created. Please try again.");
    }
  };

  return (
    <div className="mt-4 border border-border bg-background px-4 py-4">
      <div className="font-mono text-[9px] uppercase tracking-[0.22em] text-muted-foreground">
        Invoice the shipping
      </div>
      <form onSubmit={submit} className="mt-3 grid gap-3 sm:grid-cols-2">
        <label className="block">
          <span className="font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">
            Amount (USD)
          </span>
          <input
            value={amount}
            onChange={(e) => setAmount(e.target.value.replace(/[^\d.]/g, ""))}
            inputMode="decimal"
            className={inputClass}
          />
        </label>
        <label className="block">
          <span className="font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">
            Service
          </span>
          <input
            value={service}
            onChange={(e) => setService(e.target.value)}
            className={inputClass}
          />
        </label>
        <label className="block sm:col-span-2">
          <span className="font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">
            Note (optional)
          </span>
          <input
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className={inputClass}
          />
        </label>

        {error && (
          <p className="border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs leading-relaxed text-destructive sm:col-span-2">
            {error}
          </p>
        )}

        {result && (
          <div className="border border-primary/40 bg-primary/5 px-3 py-3 sm:col-span-2">
            <div className="flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.2em] text-primary">
              <Check className="h-3 w-3" />
              {result.emailed ? `Invoice emailed to ${result.buyerEmail}` : "Invoice created"}
            </div>
            {!result.emailed && (
              <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                {result.emailError || "Send this payment link to the buyer:"}
              </p>
            )}
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <a
                href={result.paymentUrl}
                target="_blank"
                rel="noreferrer"
                className="break-all font-mono text-[11px] text-primary underline"
              >
                {result.paymentUrl}
              </a>
              <button
                type="button"
                onClick={() => navigator.clipboard?.writeText(result.paymentUrl)}
                className="inline-flex items-center gap-1 border border-border px-2 py-1 font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground hover:text-foreground"
              >
                <Copy className="h-3 w-3" />
                Copy
              </button>
            </div>
          </div>
        )}

        <div className="sm:col-span-2">
          <button
            type="submit"
            disabled={status === "loading"}
            className="inline-flex items-center gap-2 bg-accent px-4 py-2.5 font-mono text-[10px] uppercase tracking-[0.2em] text-accent-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
          >
            {status === "loading" ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                Sending
              </>
            ) : (
              <>
                <Send className="h-3.5 w-3.5" />
                Send shipping invoice
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}