import { Check, Phone } from "lucide-react";

const SCOPE = [
  "Stretchers & gurneys",
  "Hospital & long-term care beds",
  "Exam and procedure tables",
  "Surgical tables",
  "Wheelchairs & transport chairs",
];

const BRANDS = [
  "Stryker",
  "Midmark",
  "Hill-Rom",
  "Invacare",
  "Hamilton",
  "Ferno",
  "Ritter",
  "Brewer",
];

const STEPS = [
  { index: "01", title: "Tell us the unit", body: "Brand, model and the fault. A photo helps." },
  { index: "02", title: "We confirm a window", body: "A coordinator calls to lock in the visit." },
  { index: "03", title: "Repair and report", body: "Work is documented, parts and labor itemized." },
];

export default function ServiceScope() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
          What we service
        </h2>
        <ul className="mt-4 space-y-2.5">
          {SCOPE.map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm">
              <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="border-t border-border pt-8">
        <h2 className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
          Brands we support
        </h2>
        <div className="mt-4 flex flex-wrap gap-2">
          {BRANDS.map((brand) => (
            <span
              key={brand}
              className="border border-border px-2.5 py-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground"
            >
              {brand}
            </span>
          ))}
        </div>
      </div>

      <div className="border-t border-border pt-8">
        <h2 className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
          How it works
        </h2>
        <ol className="mt-4 space-y-4">
          {STEPS.map((step) => (
            <li key={step.index} className="flex gap-4">
              <span className="font-mono text-[10px] tracking-[0.24em] text-primary">
                {step.index}
              </span>
              <div>
                <div className="font-heading text-sm uppercase tracking-[0.04em]">{step.title}</div>
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{step.body}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>

      <div className="border border-border bg-card p-6">
        <p className="text-sm leading-relaxed text-muted-foreground">
          Unit down and need it working today? Call the shop directly — we keep parts on the shelf
          for Stryker and Midmark stretchers and beds.
        </p>
        <a
          href="tel:+18188998090"
          className="mt-4 inline-flex items-center gap-2 font-heading text-lg hover:text-primary"
        >
          <Phone className="h-4 w-4 text-primary" />
          1-818-899-8090
        </a>
      </div>
    </div>
  );
}