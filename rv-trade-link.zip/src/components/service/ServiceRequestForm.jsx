import { useState } from "react";
import { startOfMonth } from "date-fns";
import { CalendarCheck, FileText, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import AvailabilityCalendar from "@/components/repair/AvailabilityCalendar";
import useCalendarAvailability from "@/hooks/useCalendarAvailability";

const EQUIPMENT = [
  "Stretchers & Gurneys",
  "Hospital Beds",
  "Exam & Procedure Tables",
  "Surgical Tables",
  "Wheelchairs",
  "Other equipment",
];

const WINDOWS = [
  { value: "morning", label: "Morning · 8:00–12:00" },
  { value: "afternoon", label: "Afternoon · 12:00–17:00" },
  { value: "flexible", label: "Flexible" },
];

const inputClass =
  "mt-2 w-full border border-input bg-background px-3 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-primary";
const labelClass = "font-mono text-[9px] uppercase tracking-[0.22em] text-muted-foreground";

const emptyForm = {
  name: "",
  email: "",
  phone: "",
  organization: "",
  equipment: "",
  brand: "",
  details: "",
  location: "",
  preferred_date: "",
  preferred_window: "flexible",
};

export default function ServiceRequestForm() {
  const [type, setType] = useState("service");
  const [form, setForm] = useState(emptyForm);
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");
  const [month, setMonth] = useState(startOfMonth(new Date()));
  const availability = useCalendarAvailability("repair-availability");

  const update = (field) => (event) =>
    setForm((prev) => ({ ...prev, [field]: event.target.value }));

  const isService = type === "service";

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.details.trim()) {
      setError("Add your name, email and a short description so we can help.");
      return;
    }
    if (isService && !form.preferred_date) {
      setError("Pick an available day you would like us to come out.");
      return;
    }
    if (isService && availability.unavailableDates.has(form.preferred_date)) {
      setError("That day is unavailable. Please choose another available date.");
      return;
    }
    setStatus("saving");
    setError("");
    try {
      if (isService) {
        const live = await availability.refresh();
        if (live?.has(form.preferred_date)) {
          setStatus("idle");
          setForm((prev) => ({ ...prev, preferred_date: "" }));
          setError("That day was just taken. Please choose another available date.");
          return;
        }
      }
      await base44.entities.ServiceRequest.create({
        ...form,
        request_type: type,
        status: "new",
        preferred_date: isService ? form.preferred_date : "",
        preferred_window: isService ? form.preferred_window : "flexible",
      });
      setStatus("sent");
    } catch (err) {
      setStatus("idle");
      setError("We couldn't send that. Please call 1-818-899-8090.");
    }
  };

  if (status === "sent") {
    return (
      <div className="border border-primary/40 bg-card p-8 md:p-10">
        <div className="font-mono text-[10px] uppercase tracking-[0.24em] text-primary">
          Request received
        </div>
        <h2 className="mt-3 font-heading text-2xl font-semibold uppercase tracking-[0.02em]">
          {isService ? "We'll confirm your visit" : "Your quote is on the way"}
        </h2>
        <p className="mt-3 max-w-lg text-sm leading-relaxed text-muted-foreground">
          {isService
            ? "A service coordinator will call to confirm the appointment window, usually within one business day."
            : "Our team will review the details and send pricing, usually within one business day."}
        </p>
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <a
            href="tel:+18188998090"
            className="bg-primary px-5 py-3 text-center font-mono text-[10px] uppercase tracking-[0.2em] text-primary-foreground"
          >
            Call 1-818-899-8090
          </a>
          <button
            type="button"
            onClick={() => {
              setForm(emptyForm);
              setStatus("idle");
            }}
            className="border border-border px-5 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-foreground"
          >
            Send another request
          </button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="border border-border bg-card p-6 md:p-8">
      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => setType("service")}
          className={`flex items-center justify-center gap-2 border px-3 py-3 font-mono text-[10px] uppercase tracking-[0.16em] transition-colors ${
            isService
              ? "border-primary bg-primary text-primary-foreground"
              : "border-border text-muted-foreground hover:text-foreground"
          }`}
        >
          <CalendarCheck className="h-3.5 w-3.5" />
          Schedule service
        </button>
        <button
          type="button"
          onClick={() => setType("quote")}
          className={`flex items-center justify-center gap-2 border px-3 py-3 font-mono text-[10px] uppercase tracking-[0.16em] transition-colors ${
            !isService
              ? "border-primary bg-primary text-primary-foreground"
              : "border-border text-muted-foreground hover:text-foreground"
          }`}
        >
          <FileText className="h-3.5 w-3.5" />
          Request a quote
        </button>
      </div>

      <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
        {isService
          ? "Tell us what needs fixing and when works for you. We service stretchers, hospital beds and exam tables on site or in our Pacoima shop."
          : "Tell us what you need priced — a repair, a part, or a replacement unit. We'll send a written quote."}
      </p>

      <div className="mt-6 grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className={labelClass}>
            Name *
          </label>
          <input id="name" required value={form.name} onChange={update("name")} className={inputClass} />
        </div>
        <div>
          <label htmlFor="organization" className={labelClass}>
            Facility
          </label>
          <input
            id="organization"
            value={form.organization}
            onChange={update("organization")}
            placeholder="Clinic or hospital"
            className={inputClass}
          />
        </div>
        <div>
          <label htmlFor="email" className={labelClass}>
            Email *
          </label>
          <input
            id="email"
            type="email"
            required
            value={form.email}
            onChange={update("email")}
            placeholder="you@clinic.com"
            className={inputClass}
          />
        </div>
        <div>
          <label htmlFor="phone" className={labelClass}>
            Phone
          </label>
          <input
            id="phone"
            type="tel"
            value={form.phone}
            onChange={update("phone")}
            placeholder="(818) 000-0000"
            className={inputClass}
          />
        </div>
        <div>
          <label htmlFor="equipment" className={labelClass}>
            Equipment
          </label>
          <select
            id="equipment"
            value={form.equipment}
            onChange={update("equipment")}
            className={inputClass}
          >
            <option value="">Select equipment</option>
            {EQUIPMENT.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="brand" className={labelClass}>
            Brand / model
          </label>
          <input
            id="brand"
            value={form.brand}
            onChange={update("brand")}
            placeholder="Stryker, Midmark…"
            className={inputClass}
          />
        </div>

        {isService && (
          <>
            <div className="sm:col-span-2">
              <div className="flex items-baseline justify-between gap-3">
                <span className={labelClass}>Preferred date *</span>
                {form.preferred_date && (
                  <button
                    type="button"
                    onClick={() => setForm((prev) => ({ ...prev, preferred_date: "" }))}
                    className="font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground transition-colors hover:text-foreground"
                  >
                    Clear date
                  </button>
                )}
              </div>
              <div className="mt-2">
                {availability.loading ? (
                  <div className="h-72 animate-pulse border border-border bg-secondary" />
                ) : (
                  <AvailabilityCalendar
                    month={month}
                    onMonthChange={setMonth}
                    unavailableDates={availability.unavailableDates}
                    selected={form.preferred_date}
                    onSelect={(key) => setForm((prev) => ({ ...prev, preferred_date: key }))}
                  />
                )}
              </div>
              <p className="mt-3 font-mono text-[9px] uppercase leading-relaxed tracking-[0.14em] text-muted-foreground">
                Crossed-out days are already booked or closed. We confirm every visit by phone.
              </p>
              {availability.error && (
                <p className="mt-2 text-xs leading-relaxed text-destructive">{availability.error}</p>
              )}
            </div>
            <div>
              <label htmlFor="preferred_window" className={labelClass}>
                Time window
              </label>
              <select
                id="preferred_window"
                value={form.preferred_window}
                onChange={update("preferred_window")}
                className={inputClass}
              >
                {WINDOWS.map((item) => (
                  <option key={item.value} value={item.value}>
                    {item.label}
                  </option>
                ))}
              </select>
            </div>
          </>
        )}

        <div className="sm:col-span-2">
          <label htmlFor="location" className={labelClass}>
            Service location
          </label>
          <input
            id="location"
            value={form.location}
            onChange={update("location")}
            placeholder="Address, city"
            className={inputClass}
          />
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="details" className={labelClass}>
            {isService ? "What's wrong? *" : "What should we quote? *"}
          </label>
          <textarea
            id="details"
            required
            rows={4}
            value={form.details}
            onChange={update("details")}
            placeholder={
              isService
                ? "E.g. Stryker stretcher — hydraulic pedal won't lock, brake sticks."
                : "E.g. Two Midmark exam tables need new upholstery and a service check."
            }
            className={`${inputClass} resize-none`}
          />
        </div>
      </div>

      {error && (
        <p className="mt-4 border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs leading-relaxed text-destructive">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={status === "saving"}
        className="mt-6 flex w-full items-center justify-center gap-2 bg-primary px-6 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
      >
        {status === "saving" ? (
          <>
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            Sending
          </>
        ) : isService ? (
          "Request service visit"
        ) : (
          "Request quote"
        )}
      </button>
      <p className="mt-3 text-center font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
        No obligation · We confirm every appointment by phone
      </p>
    </form>
  );
}