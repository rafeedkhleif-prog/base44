import { useState } from "react";
import { Link } from "react-router-dom";
import { Check, Loader2, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { formatPriceExact } from "@/lib/format";

const STATUS_TONE = {
  pending: "border-yellow-600/50 text-yellow-700",
  countered: "border-primary/50 text-primary",
  accepted: "border-emerald-600/50 text-emerald-700",
  declined: "border-destructive/50 text-destructive",
  withdrawn: "border-border text-muted-foreground",
};

const OPEN_STATUSES = ["pending", "countered"];

export default function OfferRow({ offer, onUpdated }) {
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState(offer.countered_amount || offer.amount || "");
  const [note, setNote] = useState(offer.counter_message || "");
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");

  const isOpen = OPEN_STATUSES.includes(offer.status);

  const update = async (patch, label) => {
    setBusy(label);
    setError("");
    try {
      const updated = await base44.entities.Offer.update(offer.id, patch);
      onUpdated(updated);
      setOpen(false);
    } catch (err) {
      setError(err?.message || "That change did not save.");
    } finally {
      setBusy("");
    }
  };

  const accept = () =>
    update(
      {
        status: "accepted",
        amount: offer.countered_amount || offer.amount,
        responded_at: new Date().toISOString(),
      },
      "accept"
    );

  const decline = () =>
    update({ status: "declined", responded_at: new Date().toISOString() }, "decline");

  const sendCounter = () => {
    const value = Number(amount);
    if (!Number.isFinite(value) || value <= 0) {
      setError("Enter a counter amount.");
      return;
    }
    update(
      {
        status: "countered",
        countered_amount: value,
        counter_message: note.trim(),
        counter_by: "seller",
        responded_at: new Date().toISOString(),
      },
      "counter"
    );
  };

  return (
    <div className="border border-border bg-card px-5 py-4">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-3">
            <span
              className={`border px-2 py-0.5 font-mono text-[9px] uppercase tracking-[0.16em] ${STATUS_TONE[offer.status] ?? STATUS_TONE.pending}`}
            >
              {offer.status}
            </span>
            {offer.paid_at && (
              <span className="border border-emerald-600/50 px-2 py-0.5 font-mono text-[9px] uppercase tracking-[0.16em] text-emerald-700">
                paid
              </span>
            )}
            <Link
              to={`/equipment/${offer.listing_id}`}
              className="truncate text-sm font-medium hover:text-primary"
            >
              {offer.listing_title || "Listing"}
            </Link>
          </div>
          <div className="mt-2 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
            {offer.buyer_name || "Buyer"} · {offer.buyer_email}
            {offer.buyer_phone ? ` · ${offer.buyer_phone}` : ""}
          </div>
          {offer.message && (
            <p className="mt-2 max-w-xl whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
              {offer.message}
            </p>
          )}
        </div>

        <div className="text-right">
          <div className="font-heading text-lg">{formatPriceExact(offer.amount)}</div>
          {offer.status === "countered" && offer.countered_amount ? (
            <div className="font-mono text-[10px] uppercase tracking-[0.14em] text-primary">
              counter {formatPriceExact(offer.countered_amount)}
            </div>
          ) : (
            <div className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
              asking {formatPriceExact(offer.asking_price)}
            </div>
          )}
        </div>
      </div>

      {isOpen && (
        <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-border pt-3">
          <button
            type="button"
            onClick={accept}
            disabled={Boolean(busy)}
            className="inline-flex items-center gap-1.5 bg-accent px-3 py-2 font-mono text-[9px] uppercase tracking-[0.16em] text-accent-foreground disabled:opacity-50"
          >
            {busy === "accept" ? (
              <Loader2 className="h-3 w-3 animate-spin" />
            ) : (
              <Check className="h-3 w-3" />
            )}
            Accept
          </button>
          <button
            type="button"
            onClick={() => setOpen((current) => !current)}
            className="inline-flex items-center gap-1.5 border border-border px-3 py-2 font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground hover:text-foreground"
          >
            {open ? "Cancel counter" : "Counter"}
          </button>
          <button
            type="button"
            onClick={decline}
            disabled={Boolean(busy)}
            className="inline-flex items-center gap-1.5 border border-border px-3 py-2 font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground hover:text-destructive disabled:opacity-50"
          >
            {busy === "decline" ? (
              <Loader2 className="h-3 w-3 animate-spin" />
            ) : (
              <X className="h-3 w-3" />
            )}
            Decline
          </button>
        </div>
      )}

      {isOpen && open && (
        <div className="mt-3 grid gap-3 border border-border bg-background p-3 sm:grid-cols-[160px_1fr_auto]">
          <Input
            type="number"
            min="1"
            step="1"
            value={amount}
            onChange={(event) => setAmount(event.target.value)}
            placeholder="Counter amount"
            className="border-border bg-card px-3 py-2 text-sm"
          />
          <Textarea
            rows={2}
            value={note}
            onChange={(event) => setNote(event.target.value)}
            placeholder="Message to the buyer"
            className="border-border bg-card px-3 py-2 text-sm"
          />
          <button
            type="button"
            onClick={sendCounter}
            disabled={Boolean(busy)}
            className="self-start bg-primary px-4 py-2 font-mono text-[9px] uppercase tracking-[0.16em] text-primary-foreground disabled:opacity-50"
          >
            {busy === "counter" ? <Loader2 className="h-3 w-3 animate-spin" /> : "Send counter"}
          </button>
        </div>
      )}

      {error && (
        <p className="mt-3 border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive">
          {error}
        </p>
      )}
    </div>
  );
}