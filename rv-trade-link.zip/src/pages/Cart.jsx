import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Loader2, Lock, ShoppingCart } from "lucide-react";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import CartLine from "@/components/cart/CartLine";
import CartShippingForm from "@/components/cart/CartShippingForm";
import useCart from "@/hooks/useCart";
import useCartShipping, { emptyAddress } from "@/hooks/useCartShipping";
import { removeFromCart, clearCart } from "@/lib/cart";
import { formatPriceExact } from "@/lib/format";
import { formatCents } from "@/lib/formatCents";
import { base44 } from "@/api/base44Client";

export default function Cart() {
  const ids = useCart();
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");
  const [address, setAddress] = useState(emptyAddress);

  const key = ids.join(",");

  useEffect(() => {
    let active = true;
    if (!ids.length) {
      setListings([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    Promise.all(ids.map((id) => base44.entities.Listing.get(id).catch(() => null)))
      .then((records) => {
        if (active) setListings(records.filter(Boolean));
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [key]);

  const payable = listings.filter(
    (listing) =>
      listing.status === "active" && (listing.quantity ?? 1) > 0 && !listing.price_on_request
  );
  const subtotal = payable.reduce((sum, listing) => sum + Number(listing.price || 0), 0);
  const blocked = listings.length - payable.length;
  const shipping = useCartShipping(payable, address);
  const shippingTotalCents = shipping.estimate?.totalCents ?? null;
  const total = shippingTotalCents !== null ? subtotal + shippingTotalCents / 100 : null;
  const shippingLabel =
    shipping.status === "calculating"
      ? "Calculating"
      : shipping.status === "ready"
        ? formatCents(shipping.estimate.totalCents)
        : "Invoiced after order";
  const shippingNote = !shipping.ratable
    ? "A unit in your cart has no packed dimensions on file yet, so shipping is quoted after your order and invoiced separately."
    : shipping.status === "unavailable"
      ? shipping.message
      : shipping.complete
        ? "Estimated UPS Ground shipping plus handling, priced on the address above."
        : "Enter the delivery address so we can price shipping.";

  const handleCheckout = async () => {
    setStatus("loading");
    setError("");
    try {
      const response = await base44.functions.invoke("create-checkout", {
        items: payable.map((listing) => listing.id),
        shipAddress: address,
        toZip: address.zip.trim(),
        destinationType: address.destinationType,
        shipDate: shipping.shipDate,
      });
      const redirectUrl = response?.data?.redirectUrl;
      if (!redirectUrl) throw new Error("No checkout URL returned");
      clearCart();
      window.location.href = redirectUrl;
    } catch (err) {
      setStatus("idle");
      setError(
        err?.response?.data?.error ||
          "Checkout could not start. Please call 1-818-899-8090 and we will complete your order."
      );
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <section className="border-b border-border">
          <div className="mx-auto w-full max-w-7xl px-5 py-12 md:px-8 md:py-16">
            <Link
              to="/equipment"
              className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-primary"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Inventory
            </Link>
            <div className="mt-6 font-mono text-[10px] uppercase tracking-[0.26em] text-primary">
              / Cart
            </div>
            <h1 className="mt-4 font-heading text-3xl font-semibold uppercase leading-[1.02] md:text-5xl">
              Your cart
            </h1>
          </div>
        </section>

        <section className="mx-auto w-full max-w-7xl px-5 py-12 md:px-8 md:py-16">
          {loading ? (
            <div className="flex h-40 items-center justify-center border border-border bg-card">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : !listings.length ? (
            <div className="border border-border bg-card px-6 py-16 text-center">
              <ShoppingCart className="mx-auto h-6 w-6 text-muted-foreground" />
              <h2 className="mt-4 font-heading text-xl font-semibold uppercase tracking-[0.02em]">
                Your cart is empty
              </h2>
              <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                Add units from the inventory and check out once for everything in your cart.
              </p>
              <Link
                to="/equipment"
                className="mt-7 inline-flex bg-primary px-5 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-primary-foreground"
              >
                Browse inventory
              </Link>
            </div>
          ) : (
            <div className="grid gap-10 lg:grid-cols-[1.5fr_1fr] lg:gap-14">
              <div>
                {listings.map((listing) => (
                  <CartLine key={listing.id} listing={listing} onRemove={removeFromCart} />
                ))}
                <Link
                  to="/equipment"
                  className="mt-6 inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-primary"
                >
                  <ArrowLeft className="h-3.5 w-3.5" />
                  Continue shopping
                </Link>
              </div>

              <aside className="lg:sticky lg:top-28 lg:self-start">
                <div className="border border-border bg-card p-6">
                  <div className="font-mono text-[9px] uppercase tracking-[0.24em] text-muted-foreground">
                    Order summary
                  </div>
                  <div className="mt-4 flex items-baseline justify-between gap-4">
                    <span className="text-sm text-muted-foreground">
                      {payable.length} {payable.length === 1 ? "unit" : "units"}
                    </span>
                    <span className="font-mono text-sm">{formatPriceExact(subtotal)}</span>
                  </div>
                  <div className="mt-2 flex items-baseline justify-between gap-4">
                    <span className="text-sm text-muted-foreground">Shipping</span>
                    <span className="font-mono text-[13px]">{shippingLabel}</span>
                  </div>
                  {total !== null && (
                    <div className="mt-2 flex items-baseline justify-between gap-4 border-t border-border pt-2">
                      <span className="font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">
                        Total
                      </span>
                      <span className="font-mono text-sm text-primary">
                        {formatPriceExact(total)}
                      </span>
                    </div>
                  )}
                  <p className="mt-3 text-[11px] leading-relaxed text-muted-foreground">
                    {shippingNote}
                  </p>

                  <CartShippingForm
                    address={address}
                    onChange={(field, value) =>
                      setAddress((current) => ({ ...current, [field]: value }))
                    }
                    complete={shipping.complete}
                  />
                  {blocked > 0 && (
                    <p className="mt-3 font-mono text-[9px] uppercase leading-relaxed tracking-[0.14em] text-destructive">
                      {blocked} {blocked === 1 ? "unit is" : "units are"} unavailable and will not be
                      charged — remove {blocked === 1 ? "it" : "them"} to continue.
                    </p>
                  )}

                  {error && (
                    <p className="mt-4 border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs leading-relaxed text-destructive">
                      {error}
                    </p>
                  )}

                  <button
                    type="button"
                    onClick={handleCheckout}
                    disabled={
                      !payable.length ||
                      blocked > 0 ||
                      status === "loading" ||
                      !shipping.complete ||
                      (shipping.ratable && shipping.status !== "ready")
                    }
                    className="mt-5 flex w-full items-center justify-center gap-2 bg-accent px-6 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-accent-foreground transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {status === "loading" ? (
                      <>
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        Starting checkout
                      </>
                    ) : (
                      "Checkout"
                    )}
                  </button>
                  <p className="mt-4 flex items-center justify-center gap-2 font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">
                    <Lock className="h-3 w-3" />
                    Secure checkout · card payment
                  </p>
                </div>
              </aside>
            </div>
          )}
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}