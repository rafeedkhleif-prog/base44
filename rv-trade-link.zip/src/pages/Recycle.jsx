import { Phone } from "lucide-react";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import RecycleScope from "@/components/recycle/RecycleScope";
import RecyclePickupForm from "@/components/recycle/RecyclePickupForm";

export default function Recycle() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <section className="border-b border-border">
          <div className="mx-auto w-full max-w-7xl px-5 pb-14 pt-14 md:px-8 md:pb-20 md:pt-20">
            <div className="font-mono text-[10px] uppercase tracking-[0.26em] text-muted-foreground">
              / Recycle & pickup
            </div>
            <h1 className="mt-6 max-w-3xl font-heading text-[2.1rem] font-semibold uppercase leading-[0.95] tracking-[-0.01em] sm:text-5xl">
              Recycle medical
              <br />
              equipment
              <span className="text-primary"> responsibly</span>
            </h1>
            <p className="mt-5 max-w-xl text-sm leading-relaxed text-muted-foreground md:text-base">
              We pick up your broken old equipment. If it can be repaired, we refurbish it and put it
              back to work — if it can't, we break it down and recycle the metal, electronics and
              usable parts.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a
                href="#pickup"
                className="inline-flex items-center justify-center bg-primary px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-primary-foreground transition-opacity hover:opacity-90"
              >
                Book a pickup
              </a>
              <a
                href="tel:+18188998090"
                className="inline-flex items-center justify-center gap-2 border border-border px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:border-primary/60 hover:text-primary"
              >
                <Phone className="h-3.5 w-3.5" />
                1-818-899-8090
              </a>
            </div>
          </div>
        </section>

        <section id="pickup">
          <div className="mx-auto grid w-full max-w-7xl gap-10 px-5 py-14 md:px-8 md:py-20 lg:grid-cols-[0.85fr_1.15fr] lg:gap-16">
            <RecycleScope />
            <div>
              <RecyclePickupForm />
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}