import { Link, useSearchParams } from "react-router-dom";
import { Check } from "lucide-react";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";

export default function ThankYou() {
  const [searchParams] = useSearchParams();
  const reference =
    searchParams.get("orderId") || searchParams.get("checkoutId") || searchParams.get("session_id");

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto w-full max-w-3xl px-5 py-20 md:px-8 md:py-28">
        <div className="grid h-12 w-12 place-items-center border border-primary/50 text-primary">
          <Check className="h-5 w-5" />
        </div>
        <div className="mt-6 font-mono text-[10px] uppercase tracking-[0.26em] text-primary">
          Payment submitted
        </div>
        <h1 className="mt-4 font-heading text-3xl font-semibold uppercase leading-[1.05] md:text-5xl">
          Thank you — your order is in
        </h1>
        <p className="mt-5 max-w-xl text-sm leading-relaxed text-muted-foreground">
          Your payment was submitted successfully. We are confirming it with the payment provider
          now; a receipt goes to the email you used at checkout, and our team will call to arrange
          freight and delivery.
        </p>

        {reference && (
          <div className="mt-8 border border-border bg-card px-5 py-4">
            <div className="font-mono text-[9px] uppercase tracking-[0.22em] text-muted-foreground">
              Order reference
            </div>
            <div className="mt-1 break-all font-mono text-xs text-foreground">{reference}</div>
          </div>
        )}

        <div className="mt-10 flex flex-col gap-3 sm:flex-row">
          <Link
            to="/equipment"
            className="bg-primary px-6 py-3.5 text-center font-mono text-[10px] uppercase tracking-[0.2em] text-primary-foreground"
          >
            Back to inventory
          </Link>
          <a
            href="tel:+18188998090"
            className="border border-border px-6 py-3.5 text-center font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-foreground"
          >
            Call 1-818-899-8090
          </a>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}