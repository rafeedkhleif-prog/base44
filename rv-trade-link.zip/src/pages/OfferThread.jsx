import { useEffect, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { ArrowLeft, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import { formatPriceExact } from "@/lib/format";

const TONE = {
  pending: "border-border text-muted-foreground",
  countered: "border-primary/50 text-primary",
  accepted: "border-emerald-600/50 text-emerald-700",
  declined: "border-destructive/50 text-destructive",
  withdrawn: "border-border text-muted-foreground",
};

const HEADLINE = {
  pending: "Waiting on our reply",
  countered: "We sent you a counter offer",
  accepted: "Offer accepted",
  declined: "Offer closed",
  withdrawn: "Offer withdrawn",
};

export default function OfferThread() {
  const { token } = useParams();
  const [searchParams] = useSearchParams();
  const returnedFromPayment = searchParams.get("paid") === "1";
  const [offer, setOffer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("idle");

  useEffect(() => {
    let active = true;
    setLoading(true);
    base44.functions
      .invoke("offer-thread", { token })
      .then((response) => {
        if (active) setOffer(response?.data?.offer ?? null);
      })
      .catch((err) => {
        if (active) setError(err?.response?.data?.error || "This offer link is not valid.");
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [token]);

  const payNow = async () => {
    setStatus("paying");
    setError("");
    try {
      const response = await base44.functions.invoke("create-checkout", {
        productId: offer.listing_id,
        offerToken: token,
        shippingLater: true,
      });
      const redirectUrl = response?.data?.redirectUrl;
      if (!redirectUrl) throw new Error("No checkout URL returned");
      window.location.href = redirectUrl;
    } catch (err) {
      setStatus("idle");
      setError(
        err?.response?.data?.error ||
          "Payment could not start. Please call 1-818-899-8090 and we will take it from there."
      );
    }
  };

  const reply = async (action) => {
    setStatus("saving");
    setError("");
    try {
      const response = await base44.functions.invoke("offer-thread", { token, action });
      setOffer(response?.data?.offer ?? offer);
      setStatus("idle");
    } catch (err) {
      setError(err?.response?.data?.error || "That reply could not be saved.");
      setStatus("idle");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto w-full max-w-2xl px-5 py-14 md:px-8 md:py-20">
        <Link
          to="/equipment"
          className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-primary"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Inventory
        </Link>

        {loading ? (
          <div className="mt-16 flex justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : !offer ? (
          <div className="mt-10 border border-border bg-card px-6 py-12 text-center">
            <h1 className="font-heading text-xl font-semibold uppercase">Offer not found</h1>
            <p className="mt-3 text-sm text-muted-foreground">
              {error || "Check the link in your offer confirmation."}
            </p>
          </div>
        ) : (
          <>
            <span
              className={`mt-6 inline-block border px-2 py-1 font-mono text-[9px] uppercase tracking-[0.18em] ${TONE[offer.status] ?? TONE.pending}`}
            >
              {offer.status}
            </span>
            <h1 className="mt-4 font-heading text-3xl font-semibold uppercase leading-tight">
              {HEADLINE[offer.status] || "Your offer"}
            </h1>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              {offer.listing_title} · asking {formatPriceExact(offer.asking_price)}
            </p>

            <dl className="mt-8 divide-y divide-border border-y border-border">
              <div className="flex items-center justify-between gap-4 py-3.5">
                <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                  Your offer
                </dt>
                <dd className="text-sm">{formatPriceExact(offer.amount)}</dd>
              </div>
              {offer.status === "countered" && offer.countered_amount ? (
                <div className="flex items-center justify-between gap-4 py-3.5">
                  <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-primary">
                    Our counter
                  </dt>
                  <dd className="font-heading text-lg text-primary">
                    {formatPriceExact(offer.countered_amount)}
                  </dd>
                </div>
              ) : null}
            </dl>

            {offer.message && (
              <p className="mt-6 whitespace-pre-line border-l-2 border-border pl-4 text-sm leading-relaxed text-muted-foreground">
                {offer.message}
              </p>
            )}

            {offer.counter_message && (
              <div className="mt-6 border border-primary/40 bg-primary/5 px-4 py-3">
                <div className="font-mono text-[9px] uppercase tracking-[0.18em] text-primary">
                  Message from us
                </div>
                <p className="mt-2 whitespace-pre-line text-sm leading-relaxed">
                  {offer.counter_message}
                </p>
              </div>
            )}

            {offer.status === "accepted" && (
              <div className="mt-8 border border-primary/40 bg-primary/5 px-4 py-4">
                {offer.paid_at ? (
                  <>
                    <div className="font-mono text-[9px] uppercase tracking-[0.18em] text-emerald-700">
                      Paid · {formatPriceExact(offer.amount)}
                    </div>
                    <p className="mt-2 text-sm leading-relaxed">
                      Thank you. Payment is in and we will contact you to arrange shipping.
                    </p>
                  </>
                ) : (
                  <>
                    <div className="font-mono text-[9px] uppercase tracking-[0.18em] text-primary">
                      Offer accepted · payment due
                    </div>
                    <p className="mt-2 text-sm leading-relaxed">
                      You agreed to pay {formatPriceExact(offer.amount)} for this unit. Pay now to
                      complete the purchase; shipping is quoted and invoiced separately.
                    </p>
                    <button
                      type="button"
                      onClick={payNow}
                      disabled={status === "paying"}
                      className="mt-4 flex w-full items-center justify-center gap-2 bg-primary px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-primary-foreground disabled:opacity-50"
                    >
                      {status === "paying" ? (
                        <>
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          Starting secure checkout
                        </>
                      ) : (
                        `Pay ${formatPriceExact(offer.amount)}`
                      )}
                    </button>
                    {returnedFromPayment && (
                      <p className="mt-3 text-[12px] leading-relaxed text-muted-foreground">
                        We have not confirmed the payment yet. Refresh this page in a moment; the
                        confirmation comes from the payment provider.
                      </p>
                    )}
                  </>
                )}
              </div>
            )}

            {offer.status === "countered" && (
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <button
                  type="button"
                  onClick={() => reply("accept")}
                  disabled={status === "saving"}
                  className="flex-1 bg-primary px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-primary-foreground disabled:opacity-50"
                >
                  Accept counter
                </button>
                <button
                  type="button"
                  onClick={() => reply("decline")}
                  disabled={status === "saving"}
                  className="flex-1 border border-border px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground disabled:opacity-50"
                >
                  Decline
                </button>
              </div>
            )}

            {error && (
              <p className="mt-4 border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive">
                {error}
              </p>
            )}

            <p className="mt-8 border-t border-border pt-5 text-sm leading-relaxed text-muted-foreground">
              Questions? Call{" "}
              <a href="tel:+18188998090" className="hover:text-primary">
                1-818-899-8090
              </a>{" "}
              or email{" "}
              <a href="mailto:info@medicalrv.com" className="hover:text-primary">
                info@medicalrv.com
              </a>
              .
            </p>
          </>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}