import { useState } from "react";
import { Navigate } from "react-router-dom";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import SellForm from "@/components/sell/SellForm";
import EbayExportImport from "@/components/sell/EbayExportImport";
import MyListings from "@/components/sell/MyListings";
import SellerProfilePhoto from "@/components/sell/SellerProfilePhoto";
import { useAuth } from "@/lib/AuthContext";

const STEPS = [
  { index: "01", title: "Describe the unit", body: "Model, condition, accessories and any faults." },
  { index: "02", title: "Add photos", body: "Up to 14 photos and a video — buyers trust what they can see." },
  { index: "03", title: "Set your price", body: "Buyers pay online; the listing closes when it sells." },
];

export default function Sell() {
  const { user, isLoadingAuth } = useAuth();
  const [importVersion, setImportVersion] = useState(0);

  if (!isLoadingAuth && user?.role !== "admin") {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <section className="border-b border-border">
          <div className="mx-auto w-full max-w-7xl px-5 py-12 md:px-8 md:py-16">
            <div className="font-mono text-[10px] uppercase tracking-[0.26em] text-accent">
              / Sell your equipment
            </div>
            <h1 className="mt-4 max-w-3xl font-heading text-3xl font-semibold uppercase leading-[1.02] md:text-5xl">
              Turn surplus equipment into working capital
            </h1>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground">
              List beds, stretchers, monitors or a whole mobile unit in a few minutes. We review
              every submission, and buyers pay through secure online checkout.
            </p>

            <div className="mt-10 grid gap-6 border-t border-border pt-8 sm:grid-cols-3">
              {STEPS.map((step) => (
                <div key={step.index}>
                  <span className="font-mono text-[10px] tracking-[0.24em] text-primary">
                    {step.index}
                  </span>
                  <h2 className="mt-3 font-heading text-base font-semibold uppercase tracking-[0.03em]">
                    {step.title}
                  </h2>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto w-full max-w-3xl px-5 py-12 md:px-8 md:py-16">
          <SellerProfilePhoto user={user} />
          <EbayExportImport user={user} onComplete={() => setImportVersion((version) => version + 1)} />
          <SellForm user={user} />
          <MyListings userId={user?.id} refreshKey={importVersion} />
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}