import { useCallback, useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import SettingsCard from "@/components/shipping/admin/SettingsCard";
import DatasetList from "@/components/shipping/admin/DatasetList";
import DatasetImportForm from "@/components/shipping/admin/DatasetImportForm";
import { useAuth } from "@/lib/AuthContext";

export default function ShippingAdmin() {
  const { user, isLoadingAuth } = useAuth();
  const isAdmin = user?.role === "admin";
  const [settings, setSettings] = useState(null);
  const [datasets, setDatasets] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const [settingsPage, datasetPage] = await Promise.all([
      base44.entities.ShippingSettings.list({ sort: "-updated_date", limit: 1 }),
      base44.entities.RateDataset.list({ sort: "-created_date", limit: 50 }),
    ]);
    setSettings(settingsPage?.items?.[0] ?? null);
    setDatasets(datasetPage?.items ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    if (!isAdmin) return;
    load();
  }, [isAdmin, load]);

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto w-full max-w-5xl px-5 py-12 md:px-8">
        <div className="font-mono text-[10px] uppercase tracking-[0.24em] text-primary">
          Administrator
        </div>
        <h1 className="mt-3 font-heading text-3xl font-semibold uppercase tracking-[0.02em] md:text-4xl">
          Shipping rates
        </h1>
        <p className="mt-3 max-w-3xl text-sm leading-relaxed text-muted-foreground">
          Estimates are calculated inside the app from imported UPS Ground retail rate data. Buyers
          never enter a price and no UPS credentials are used.
        </p>

        {isLoadingAuth || (isAdmin && loading) ? (
          <div className="mt-12 h-24 animate-pulse border border-border bg-card" />
        ) : !isAdmin ? (
          <p className="mt-10 border border-border bg-card px-4 py-6 text-sm text-muted-foreground">
            Administrator access is required to view or change shipping rate data.
          </p>
        ) : (
          <div className="mt-10 space-y-6">
            <SettingsCard settings={settings} onSaved={load} />
            <DatasetList datasets={datasets} onChanged={load} />
            <DatasetImportForm originZip={settings?.origin_zip || "91340"} onImported={load} />
          </div>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}