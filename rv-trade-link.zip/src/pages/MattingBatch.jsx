import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import BatchControls from "@/components/matting/BatchControls";
import BatchReview from "@/components/matting/BatchReview";
import { useAuth } from "@/lib/AuthContext";
import usePhotoBatch from "@/hooks/usePhotoBatch";

export default function MattingBatch() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const batch = usePhotoBatch(isAdmin);
  const { counts, audit, building, running, status, fatal, device, revision, onBuild, onRun, onStop, onAction } = batch;

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-canvas">
        <SiteHeader />
        <main className="mx-auto w-full max-w-[1330px] px-5 py-24 md:px-10">
          <h1 className="font-heading text-2xl text-ink">Admins only</h1>
          <p className="mt-2 text-[14px] text-ink-body">This batch tool is restricted to administrators.</p>
        </main>
        <SiteFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-canvas">
      <SiteHeader />
      <main className="mx-auto w-full max-w-[1000px] px-5 py-12 md:px-10">
        <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink-meta">Image preparation batch</p>
        <h1 className="mt-2 font-heading text-3xl text-ink">White background, logo band</h1>
        <p className="mt-2 max-w-[680px] text-[14px] leading-relaxed text-ink-body">
          Truly white studio photos keep the original image without segmentation. Other photos require
          a verified mask and your review before application. Good results replace their exact gallery slots
          as the batch progresses; original galleries, source mappings and files are retained for rollback.
          Keep this tab open and the device awake. Closing it stops work; there is no durable server executor.
        </p>

        <div className="mt-6">
          <BatchControls
            counts={counts}
            audit={audit}
            building={building}
            running={running}
            onBuild={onBuild}
            onRun={onRun}
            onStop={onStop}
          />
        </div>

        {(status || device) && (
          <p className="mt-3 font-mono text-[10px] uppercase tracking-[0.12em] text-ink-meta">
            {device ? `engine ${device}` : "segmentation loads only when needed"}
            {status ? ` · ${status}` : ""}
          </p>
        )}
        {fatal && (
          <p className="mt-4 rounded-lg border border-primary/30 bg-primary/5 px-3 py-2.5 font-mono text-[11px] leading-relaxed text-primary">
            {fatal}
          </p>
        )}

        <BatchReview revision={revision} running={running || building} onAction={onAction} />
      </main>
      <SiteFooter />
    </div>
  );
}