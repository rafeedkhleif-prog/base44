import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, MapPin, Pencil } from "lucide-react";
import { base44 } from "@/api/base44Client";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import ListingGallery from "@/components/listings/ListingGallery";
import BuyPanel from "@/components/listings/BuyPanel";
import ListingCard from "@/components/listings/ListingCard";
import { Image } from "@/components/ui/image";
import { categoryLabel, conditionLabel } from "@/data/catalog";
import { categoryPhoto } from "@/data/categoryPhotos";
import { useAuth } from "@/lib/AuthContext";

export default function ListingDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [listing, setListing] = useState(null);
  const [related, setRelated] = useState([]);
  const [loading, setLoading] = useState(true);
  const [missing, setMissing] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);
    base44.entities.Listing.get(id)
      .then((record) => {
        if (active) setListing(record);
      })
      .catch(() => {
        if (active) setMissing(true);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [id]);

  useEffect(() => {
    if (!listing?.category) return;
    let active = true;
    base44.entities.Listing.filter(
      { category: listing.category, status: "active" },
      { sort: "-created_date", limit: 4 }
    ).then((page) => {
      if (active) setRelated((page.items ?? []).filter((item) => item.id !== listing.id).slice(0, 3));
    });
    return () => {
      active = false;
    };
  }, [listing?.category, listing?.id]);

  useEffect(() => {
    if (!missing || loading) return;
    const meta = document.createElement("meta");
    meta.name = "prerender-status-code";
    meta.content = "404";
    document.head.appendChild(meta);
    return () => {
      document.head.removeChild(meta);
    };
  }, [missing, loading]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="mx-auto grid w-full max-w-7xl gap-10 px-5 py-16 md:px-8 lg:grid-cols-[1.4fr_1fr]">
          <div className="aspect-[4/3] animate-pulse border border-border bg-card" />
          <div className="space-y-4">
            <div className="h-3 w-24 animate-pulse bg-secondary" />
            <div className="h-8 w-3/4 animate-pulse bg-secondary" />
            <div className="h-3 w-full animate-pulse bg-secondary" />
          </div>
        </div>
      </div>
    );
  }

  if (missing || !listing) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="mx-auto w-full max-w-3xl px-5 py-24 text-center md:px-8">
          <div className="font-mono text-[10px] uppercase tracking-[0.26em] text-primary">404</div>
          <h1 className="mt-4 font-heading text-3xl font-semibold uppercase">Unit not found</h1>
          <p className="mt-3 text-sm text-muted-foreground">
            This listing may have sold or been removed.
          </p>
          <Link
            to="/equipment"
            className="mt-8 inline-flex items-center gap-2 bg-primary px-5 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-primary-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Back to inventory
          </Link>
        </div>
        <SiteFooter />
      </div>
    );
  }

  const measured = (value) => Number(value) > 0;
  const sizeLabel = (length, width, height) =>
    [length, width, height].some(measured)
      ? `${[length, width, height].map((side) => (measured(side) ? side : "—")).join(" × ")} in`
      : "";
  const weightLabel = (value) => (measured(value) ? `${value} lb` : "");

  const specs = [
    { label: "Brand", value: listing.brand || "—" },
    { label: "Category", value: categoryLabel(listing.category) },
    { label: "Condition", value: conditionLabel(listing.condition) },
    weightLabel(listing.item_weight_lbs) && {
      label: "Item weight",
      value: weightLabel(listing.item_weight_lbs),
    },
    sizeLabel(listing.item_length_in, listing.item_width_in, listing.item_height_in) && {
      label: "Item dimensions",
      value: sizeLabel(listing.item_length_in, listing.item_width_in, listing.item_height_in),
    },
    weightLabel(listing.weight_lbs) && {
      label: "Shipping weight",
      value: weightLabel(listing.weight_lbs),
    },
    sizeLabel(listing.length_in, listing.width_in, listing.height_in) && {
      label: "Package dimensions",
      value: sizeLabel(listing.length_in, listing.width_in, listing.height_in),
    },
    { label: "Location", value: listing.location || "Pacoima, CA" },
    { label: "Seller", value: listing.seller_name || "Medical ReVitalization, Inc." },
  ].filter(Boolean);

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <div className="mx-auto w-full max-w-7xl px-5 pt-8 md:px-8">
          <Link
            to="/equipment"
            className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-primary"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Inventory
          </Link>
        </div>

        <div className="mx-auto grid w-full max-w-7xl gap-10 px-5 py-8 md:px-8 md:py-12 lg:grid-cols-[1.5fr_1fr] lg:gap-14">
          <div>
            <ListingGallery
              images={listing.images}
              videoUrl={listing.video_url}
              title={listing.title}
              fallbackImage={listing.condition === "refurbished" ? categoryPhoto(listing) : undefined}
            />

            <div className="mt-10 border-t border-border pt-8">
              <h2 className="font-mono text-[10px] uppercase tracking-[0.26em] text-muted-foreground">
                Description
              </h2>
              <p className="mt-4 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
                {listing.description || "No description provided for this unit."}
              </p>

              {(listing.description_images || []).length > 0 && (
                <div className="mt-6 grid gap-3 sm:grid-cols-2">
                  {listing.description_images.map((url) => (
                    <div key={url} className="aspect-[4/3] border border-border bg-card">
                      <Image src={url} alt="" fittingType="fit" className="h-full w-full" />
                    </div>
                  ))}
                </div>
              )}

              {listing.condition_notes && (
                <div className="mt-6 border-l-2 border-primary/60 pl-4">
                  <h3 className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                    Condition notes
                  </h3>
                  <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
                    {listing.condition_notes}
                  </p>
                </div>
              )}
            </div>

            <div className="mt-10 border-t border-border pt-8">
              <h2 className="font-mono text-[10px] uppercase tracking-[0.26em] text-muted-foreground">
                Specifications
              </h2>
              <dl className="mt-4 divide-y divide-border border-y border-border">
                {specs.map((spec) => (
                  <div key={spec.label} className="flex items-center justify-between gap-6 py-3.5">
                    <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                      {spec.label}
                    </dt>
                    <dd className="text-right text-sm">{spec.value}</dd>
                  </div>
                ))}
              </dl>
            </div>

          </div>

          <div className="lg:sticky lg:top-24 lg:self-start">
            <div className="font-mono text-[10px] uppercase tracking-[0.22em] text-primary">
              {listing.brand || "Medical equipment"}
            </div>
            <h1 className="mt-3 font-heading text-2xl font-semibold uppercase leading-tight tracking-[0.01em] md:text-4xl">
              {listing.title}
            </h1>
            <div className="mt-4 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
              <MapPin className="h-3.5 w-3.5" />
              {listing.location || "Pacoima, CA"}
            </div>

            {listing.seller_photo_url && (
              <div className="mt-4 flex items-center gap-2">
                <span className="h-7 w-7 shrink-0 overflow-hidden rounded-full border border-border bg-card">
                  <Image
                    src={listing.seller_photo_url}
                    alt="Seller profile photo"
                    fittingType="fill"
                    className="h-full w-full"
                  />
                </span>
                <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
                  {listing.seller_name || "Medical ReVitalization, Inc."}
                </span>
              </div>
            )}

            {isAdmin && (
              <Link
                to={`/sell/${listing.id}`}
                className="mt-5 inline-flex items-center gap-2 border border-border px-4 py-2.5 font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground transition-colors hover:border-primary/60 hover:text-primary"
              >
                <Pencil className="h-3 w-3" />
                Edit listing
              </Link>
            )}

            <div className="mt-6">
              <BuyPanel listing={listing} />
            </div>
          </div>
        </div>

        {related.length > 0 && (
          <section className="border-t border-border">
            <div className="mx-auto w-full max-w-7xl px-5 py-14 md:px-8">
              <h2 className="font-mono text-[10px] uppercase tracking-[0.26em] text-muted-foreground">
                More in {categoryLabel(listing.category)}
              </h2>
              <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {related.map((item) => (
                  <ListingCard key={item.id} listing={item} />
                ))}
              </div>
            </div>
          </section>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}