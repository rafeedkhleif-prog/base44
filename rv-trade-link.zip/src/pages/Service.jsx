import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import ServiceRequestForm from "@/components/service/ServiceRequestForm";
import ServiceScope from "@/components/service/ServiceScope";

export default function Service() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <section className="border-b border-border">
          <div className="mx-auto w-full max-w-7xl px-5 pb-14 pt-14 md:px-8 md:pb-20 md:pt-20">
            <div className="font-mono text-[10px] uppercase tracking-[0.26em] text-muted-foreground">
              / Repair & service
            </div>
            <h1 className="mt-6 max-w-3xl font-heading text-[2.1rem] font-semibold uppercase leading-[0.95] tracking-[-0.01em] sm:text-5xl">
              Fix it, service it,
              <span className="text-primary"> quote it</span>
            </h1>
            <p className="mt-5 max-w-xl text-sm leading-relaxed text-muted-foreground md:text-base">
              We repair stretchers, hospital beds and exam tables from all major brands, including
              Midmark and Stryker. Book a service visit or ask for a quote — we'll confirm by phone.
            </p>
          </div>
        </section>

        <section>
          <div className="mx-auto grid w-full max-w-7xl gap-10 px-5 py-14 md:px-8 md:py-20 lg:grid-cols-[0.85fr_1.15fr] lg:gap-16">
            <ServiceScope />
            <div>
              <ServiceRequestForm />
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}