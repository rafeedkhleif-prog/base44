import { useCallback, useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import OrderRow from "@/components/orders/OrderRow";
import CustomerList from "@/components/orders/CustomerList";
import { ExternalLink, Loader2 } from "lucide-react";

export default function Orders() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [orders, setOrders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const [purchases, customerPage] = await Promise.all([
      base44.entities.Base44Purchase.filter({}, { sort: "-created_date", limit: 50 }),
      base44.entities.Customer.list({ sort: "-lastOrderAt", limit: 50 }),
    ]);
    setOrders(purchases?.items ?? []);
    setCustomers(customerPage?.items ?? []);
  }, []);

  useEffect(() => {
    if (!isAdmin) {
      setLoading(false);
      return;
    }
    load().finally(() => setLoading(false));
  }, [isAdmin, load]);

  const awaitingShipping = orders.filter((order) => {
    const status = order.shippingPaymentStatus || "pending";
    return order.status === "paid" && (status === "pending" || status === "invoiced");
  });
  const otherOrders = orders.filter((order) => !awaitingShipping.includes(order));

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      <main className="mx-auto w-full max-w-5xl px-5 py-12 md:px-8 md:py-16">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <div className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
              Internal
            </div>
            <h1 className="mt-3 font-heading text-3xl font-semibold tracking-tight md:text-4xl">
              Orders &amp; customers
            </h1>
          </div>
          <a
            href="https://qbo.intuit.com/app/sales"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-accent px-5 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-accent-foreground transition-opacity hover:opacity-90"
          >
            All orders in QuickBooks
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </div>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground">
          Every paid item lands here. When shipping was not charged with the item, enter the freight
          or carrier cost below and the buyer is emailed a link to pay it.
        </p>

        {!isAdmin ? (
          <p className="mt-10 border border-border bg-card px-5 py-8 text-center font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            This page is limited to the shop team
          </p>
        ) : loading ? (
          <div className="mt-16 flex items-center justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <>
            <section className="mt-10">
              <div className="flex items-baseline justify-between">
                <h2 className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
                  Shipping to invoice
                </h2>
                <span className="font-mono text-[10px] text-muted-foreground">
                  {awaitingShipping.length}
                </span>
              </div>
              <div className="mt-4 space-y-4">
                {awaitingShipping.length === 0 ? (
                  <p className="border border-border bg-card px-5 py-8 text-center font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                    Nothing waiting on a shipping charge
                  </p>
                ) : (
                  awaitingShipping.map((order) => (
                    <OrderRow key={order.id} purchase={order} onInvoiced={load} />
                  ))
                )}
              </div>
            </section>

            <section className="mt-12">
              <div className="flex items-baseline justify-between">
                <h2 className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
                  All orders
                </h2>
                <span className="font-mono text-[10px] text-muted-foreground">{orders.length}</span>
              </div>
              <div className="mt-4 space-y-4">
                {otherOrders.length === 0 ? (
                  <p className="border border-border bg-card px-5 py-8 text-center font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                    No orders yet
                  </p>
                ) : (
                  otherOrders.map((order) => (
                    <OrderRow key={order.id} purchase={order} onInvoiced={load} />
                  ))
                )}
              </div>
            </section>

            <section className="mt-12">
              <div className="flex items-baseline justify-between">
                <h2 className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
                  Customers
                </h2>
                <span className="font-mono text-[10px] text-muted-foreground">
                  {customers.length}
                </span>
              </div>
              <div className="mt-4">
                <CustomerList customers={customers} />
              </div>
            </section>
          </>
        )}
      </main>

      <SiteFooter />
    </div>
  );
}