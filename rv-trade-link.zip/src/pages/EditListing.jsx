import { useEffect, useState } from "react";
import { Link, Navigate, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { base44 } from "@/api/base44Client";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import SellForm from "@/components/sell/SellForm";
import DeleteListingButton from "@/components/sell/DeleteListingButton";
import { useAuth } from "@/lib/AuthContext";

export default function EditListing() {
  const { id } = useParams();
  const { user, isLoadingAuth } = useAuth();
  const [listing, setListing] = useState(null);
  const [loading, setLoading] = useState(true);
  const [missing, setMissing] = useState(false);

  useEffect(() => {
    let active = true;
    base44.entities.Listing.get(id)
      .then((record) => {
        if (active) setListing(record);
      })
      .catch(() => {
        if (active) setMissing(true);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [id]);

  if (!isLoadingAuth && user?.role !== "admin") {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <section className="border-b border-border">
          <div className="mx-auto w-full max-w-7xl px-5 py-12 md:px-8 md:py-16">
            <Link
              to={listing ? `/equipment/${id}` : "/equipment"}
              className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-primary"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Back
            </Link>
            <div className="mt-6 font-mono text-[10px] uppercase tracking-[0.26em] text-accent">
              / Edit listing
            </div>
            <div className="mt-4 flex flex-wrap items-end justify-between gap-6">
              <h1 className="max-w-3xl font-heading text-3xl font-semibold uppercase leading-[1.02] md:text-5xl">
                {loading ? "Loading unit" : listing?.title || "Unit not found"}
              </h1>
              {!loading && listing && (
                <DeleteListingButton listingId={listing.id} title={listing.title} />
              )}
            </div>
          </div>
        </section>

        <section className="mx-auto w-full max-w-3xl px-5 py-12 md:px-8 md:py-16">
          {loading ? (
            <div className="h-64 animate-pulse border border-border bg-card" />
          ) : missing || !listing ? (
            <p className="text-sm text-muted-foreground">This listing could not be found.</p>
          ) : (
            <SellForm user={user} listing={listing} />
          )}
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}