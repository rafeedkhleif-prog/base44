import { useEffect, useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { ArrowLeft, Users } from "lucide-react";
import NewsletterComposer from "@/components/newsletter/NewsletterComposer";
import SubscriberList from "@/components/newsletter/SubscriberList";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";

export default function NewsletterAdmin() {
  const { user, isLoadingAuth } = useAuth();
  const isAdmin = user?.role === "admin";
  const [subscribers, setSubscribers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAdmin) return;
    (async () => {
      const rows = [];
      let cursor;
      do {
        const page = await base44.entities.Subscriber.filter(
          {},
          { sort: "-created_date", limit: 500, ...(cursor ? { cursor } : {}) }
        );
        rows.push(...(page?.items || []));
        cursor = page?.has_more ? page.next_cursor : null;
      } while (cursor);
      setSubscribers(rows);
      setLoading(false);
    })();
  }, [isAdmin]);

  const handleRemove = async (subscriber) => {
    await base44.entities.Subscriber.delete(subscriber.id);
    setSubscribers((prev) => prev.filter((item) => item.id !== subscriber.id));
  };

  if (!isLoadingAuth && !isAdmin) return <Navigate to="/" replace />;

  const activeCount = subscribers.filter((item) => item.status === "active").length;

  return (
    <div className="min-h-screen bg-secondary">
      <header className="border-b border-border bg-accent text-accent-foreground">
        <div className="mx-auto flex h-16 w-full max-w-7xl items-center justify-between px-5 md:px-8">
          <div className="flex items-center gap-3">
            <span className="grid h-8 w-8 place-items-center border border-primary/70 font-mono text-[10px] font-semibold text-primary">
              MRI
            </span>
            <span className="font-mono text-[10px] uppercase tracking-[0.24em]">
              Admin · Newsletter
            </span>
          </div>
          <Link
            to="/"
            className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-accent-foreground/70 transition-colors hover:text-primary"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Back to site
          </Link>
        </div>
      </header>

      <main className="mx-auto w-full max-w-7xl px-5 py-10 md:px-8 md:py-14">
        <div className="flex flex-col gap-4 border-b border-border pb-8 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="font-heading text-2xl font-semibold uppercase tracking-[0.02em] md:text-3xl">
              Newsletter
            </h1>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">
              Each issue you send here is also published on the public newsletter page.
            </p>
          </div>
          <div className="flex items-center gap-2 border border-border bg-card px-4 py-3">
            <Users className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
              {activeCount} active subscribers
            </span>
          </div>
        </div>

        <div className="mt-8 grid gap-8 lg:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]">
          <NewsletterComposer subscriberCount={activeCount} disabled={loading} />
          <SubscriberList
            subscribers={subscribers}
            loading={loading}
            onRemove={handleRemove}
          />
        </div>
      </main>
    </div>
  );
}