import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import PilotPhotoCard from "@/components/matting/PilotPhotoCard";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/AuthContext";
import useMattingWorker from "@/hooks/useMattingWorker";
import preparePilotPhoto from '@/lib/preparePilotPhoto';
import pilotResultPatch from '@/lib/pilotResultPatch';
import PilotDiagnosis from '@/components/matting/PilotDiagnosis';
import PilotApproval from '@/components/matting/PilotApproval';
import { loadLogo } from "@/lib/mattingComposite";
import ModelNotice from "@/components/matting/ModelNotice";
import photoError from "@/lib/photoError";


const PILOT_SIZE = 3;
// Known real originals exercise white equipment, a studio stretcher and iPhone HEIC.
const PILOT = [
  { listingId: "6afb231f38c52038e821e165", title: "Stryker 1115", kind: "WEBP", originalUrl: "https://media.base44.com/images/public/6aeb6aa1c91d4c8d5bcd4ce8/4de616c28_Stryker-1115-Prime-Series__90419__22728.webp" },
  { listingId: "6afb234fd305a3e3d05bc623", title: "Stryker 1005", kind: "WEBP", originalUrl: "https://media.base44.com/images/public/6aeb6aa1c91d4c8d5bcd4ce8/fad76052c_Stryker-1005-SM104-M-Series-Stretcher__71938.webp" },
  { listingId: "6afb482622c43aa1b708af3f", title: "Intelect ultrasound original", kind: "HEIC", originalUrl: "https://media.base44.com/images/public/6aeb6aa1c91d4c8d5bcd4ce8/2c3d852bf_IMG_1455.HEIC" },
];

export default function MattingPilot() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [photos, setPhotos] = useState([]);
  const [running, setRunning] = useState(false);
  const [fatal, setFatal] = useState("");

  const worker = useMattingWorker();
  const resultUrls = useRef([]);

  useEffect(() => {
    if (!isAdmin) return;
    setPhotos(PILOT.map((photo, i) => ({ ...photo, key: `${photo.listingId}-${i}`, stage: "idle" })));
  }, [isAdmin]);

  useEffect(
    () => () => resultUrls.current.forEach((url) => URL.revokeObjectURL(url)),
    [],
  );

  const update = (key, patch) =>
    setPhotos((prev) => prev.map((p) => (p.key === key ? { ...p, ...patch } : p)));

  const runPilot = async () => {
    if (running || !photos.length) return;
    setRunning(true);
    setFatal("");
    resultUrls.current.forEach(url => URL.revokeObjectURL(url));
    resultUrls.current = [];
    setPhotos(PILOT.map((photo, i) => ({ ...photo, key: `${photo.listingId}-${i}`, stage: 'idle' })));
    try {
      const logo = await loadLogo();
      for (const photo of photos) {
        update(photo.key, { stage: "decoding", error: "" });
        try {
          let resultUrl;
          const result = await preparePilotPhoto({
            url: photo.originalUrl, worker, logo,
            onStage: stage => update(photo.key, { stage }),
            onPreview: patch => update(photo.key, patch),
            onCandidate: candidate => {
              resultUrl = URL.createObjectURL(candidate.blob);
              resultUrls.current.push(resultUrl);
              update(photo.key, { ...pilotResultPatch(candidate), resultUrl, stage: candidate.qualityAccepted ? 'comparing' : 'rejected' });
            },
          });
          const nativeResultUrl = result.nativeBlob ? URL.createObjectURL(result.nativeBlob) : '';
          if (nativeResultUrl) resultUrls.current.push(nativeResultUrl);
          update(photo.key, { ...pilotResultPatch(result), resultUrl, nativeResultUrl, stage: result.qualityAccepted ? 'done' : 'rejected' });
        } catch (error) {
          update(photo.key, { stage: "error", engineConfirmed: false, error: photoError(error, `${photo.title}, browser pilot`) });
        }
      }
    } catch (error) {
      setFatal(photoError(error, "512 browser pilot"));
    } finally {
      setRunning(false);
    }
  };



  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-canvas">
        <SiteHeader />
        <main className="mx-auto w-full max-w-[1330px] px-5 py-24 md:px-10">
          <h1 className="font-heading text-2xl text-ink">Admins only</h1>
          <p className="mt-2 text-[14px] text-ink-body">This preview tool is restricted to administrators.</p>
        </main>
        <SiteFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-canvas">
      <SiteHeader />
      <main className="mx-auto w-full max-w-[1330px] px-5 py-12 md:px-10">
        <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink-meta">Image preparation pilot</p>
        <h1 className="mt-2 font-heading text-3xl text-ink">Local matting preview</h1>
        <p className="mt-2 max-w-[680px] text-[14px] leading-relaxed text-ink-body">
          Truly white studio photos bypass segmentation and keep the original equipment intact. Non-white
          photos use a conservative mask and need visual review. The exact supplied MRI logo sits below
          the equipment. These three real originals are preview-only; nothing is written to inventory here.{" "}
          <Link to="/matting-batch" className="text-sage underline underline-offset-4">
            Open the resumable batch
          </Link>
          .
        </p>

        <div className="mt-6 flex flex-wrap items-center gap-3">
          <Button onClick={runPilot} disabled={running || !photos.length} className="rounded-full px-6">
            {running ? "Running pilot…" : `Process ${PILOT_SIZE} photos`}
          </Button>
          <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-ink-meta">
            engine: {worker.device || "WASM fp32, fixed 512"} · {worker.stage || "pilot runs all three through the real browser graph"}
          </span>
        </div>

        {(fatal || worker.error) && (
          <p className="mt-4 rounded-lg border border-primary/30 bg-primary/5 px-3 py-2.5 font-mono text-[11px] leading-relaxed text-primary">
            {fatal || worker.error}
          </p>
        )}

        <PilotDiagnosis />
        <PilotApproval photos={photos} />
        <ModelNotice />
        <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {photos.map((photo) => (
            <PilotPhotoCard key={photo.key} photo={photo} />
          ))}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}