import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Loader2 } from "lucide-react";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import NewsletterSignup from "@/components/site/NewsletterSignup";
import NewsletterIssueView from "@/components/newsletter/NewsletterIssueView";
import LetterUpload from "@/components/newsletter/LetterUpload";
import IssueDeleteButton from "@/components/newsletter/IssueDeleteButton";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";

export default function Newsletter() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [issue, setIssue] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.NewsletterIssue.list({ sort: "-created_date", limit: 1 })
      .then((page) => setIssue(page?.items?.[0] || null))
      .finally(() => setLoading(false));
  }, []);

  const handleLetterUploaded = async ({ url, name }) => {
    const created = await base44.entities.NewsletterIssue.create({
      headline: name.replace(/\.[^.]+$/, "").replace(/[-_]+/g, " "),
      message: "Read the full letter below.",
      issue_date: new Date().toISOString().slice(0, 10),
      letter_url: url,
      letter_name: name,
    });
    setIssue(created);
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <section className="border-b border-border bg-secondary">
          <div className="mx-auto w-full max-w-7xl px-5 py-14 md:px-8 md:py-20">
            <p className="font-mono text-[10px] uppercase tracking-[0.26em] text-primary">
              Newsletter
            </p>
            <h1 className="mt-4 max-w-2xl font-heading text-4xl font-semibold uppercase leading-[0.98] tracking-[0.01em] md:text-6xl">
              New arrivals and price drops
            </h1>

          </div>
        </section>

        <section className="mx-auto grid w-full max-w-7xl gap-10 px-5 py-12 md:px-8 md:py-16 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)] lg:gap-14">
          <div>
            {loading ? (
              <div className="flex h-48 items-center justify-center border border-border bg-card">
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              </div>
            ) : issue ? (
              <div>
                <NewsletterIssueView issue={issue} />
                {isAdmin && (
                  <div className="mt-4 flex justify-end">
                    <IssueDeleteButton issue={issue} onDeleted={() => setIssue(null)} />
                  </div>
                )}
              </div>
            ) : (
              <div className="border border-border bg-card p-7 md:p-12">
                <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                  Latest issue
                </p>
                <h2 className="mt-5 font-heading text-2xl font-semibold uppercase leading-tight">
                  The next issue is being put together
                </h2>
                <p className="mt-4 max-w-lg text-sm leading-relaxed text-muted-foreground">
                  Subscribe below and the first issue will reach you the moment it goes out.
                </p>
                {isAdmin && (
                  <div className="mt-7 border-t border-border pt-6">
                    <p className="font-mono text-[9px] uppercase tracking-[0.22em] text-muted-foreground">
                      Admin · publish the next issue
                    </p>
                    <LetterUpload onUploaded={handleLetterUploaded} />
                  </div>
                )}
              </div>
            )}
          </div>

          <aside className="lg:sticky lg:top-28 lg:self-start">
            <div className="border border-border bg-card p-7">
              <NewsletterSignup source="newsletter page" />
              <div className="mt-8 border-t border-border pt-6">
                <Link
                  to="/equipment"
                  className="font-mono text-[10px] uppercase tracking-[0.2em] text-primary transition-opacity hover:opacity-80"
                >
                  Browse current inventory →
                </Link>
              </div>
              {isAdmin && (
                <div className="mt-6 border-t border-border pt-6">
                  <Link
                    to="/newsletter-admin"
                    className="font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground transition-colors hover:text-foreground"
                  >
                    Admin · compose and send
                  </Link>
                </div>
              )}
            </div>
          </aside>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}