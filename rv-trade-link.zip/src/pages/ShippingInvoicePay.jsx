import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { formatCents } from "@/lib/formatCents";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import { ArrowRight, Check, Loader2, Lock, Receipt } from "lucide-react";

export default function ShippingInvoicePay() {
  const { token } = useParams();
  const [invoice, setInvoice] = useState(null);
  const [loading, setLoading] = useState(true);
  const [missing, setMissing] = useState(false);
  const [paying, setPaying] = useState(false);
  const [error, setError] = useState("");

  const returnedFromPayment =
    new URLSearchParams(window.location.search).get("paid") === "1";

  useEffect(() => {
    let active = true;
    base44.functions
      .invoke("get-shipping-invoice", { token })
      .then((response) => {
        if (!active) return;
        setInvoice(response?.data?.invoice ?? null);
        setMissing(!response?.data?.invoice);
      })
      .catch(() => {
        if (active) setMissing(true);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [token]);

  const pay = async () => {
    setPaying(true);
    setError("");
    try {
      const response = await base44.functions.invoke("create-checkout", {
        shippingInvoiceId: invoice.id,
        token: invoice.token,
      });
      const redirectUrl = response?.data?.redirectUrl;
      if (!redirectUrl) throw new Error("No checkout URL returned");
      window.location.href = redirectUrl;
    } catch (err) {
      setPaying(false);
      setError(
        err?.response?.data?.error ||
          "The payment could not start. Please call 1-818-899-8090 and we will take it by phone."
      );
    }
  };

  const paid = invoice?.status === "paid" || returnedFromPayment;

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      <main className="mx-auto w-full max-w-2xl px-5 py-12 md:px-8 md:py-20">
        <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
          <Receipt className="h-3.5 w-3.5" />
          Shipping invoice
        </div>

        {loading ? (
          <div className="mt-16 flex items-center justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : missing ? (
          <div className="mt-8 border border-border bg-card px-6 py-10">
            <h1 className="font-heading text-2xl font-semibold tracking-tight">
              This invoice link is not valid
            </h1>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              The link may have expired or been replaced. Call us at 1-818-899-8090 and we will
              resend it.
            </p>
            <Link
              to="/equipment"
              className="mt-6 inline-flex items-center gap-2 bg-accent px-5 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-accent-foreground"
            >
              Browse inventory
              <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        ) : (
          <div className="mt-6 border border-border bg-card">
            <div className="border-b border-border px-6 py-6">
              <h1 className="font-heading text-2xl font-semibold tracking-tight">
                {invoice.listingTitle}
              </h1>
              <div className="mt-2 font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
                Order {invoice.orderRef || "—"}
                {invoice.service ? ` · ${invoice.service}` : ""}
              </div>
            </div>

            <div className="flex items-baseline justify-between border-b border-border px-6 py-5">
              <span className="font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">
                Shipping &amp; handling
              </span>
              <span className="font-heading text-2xl font-semibold tracking-tight">
                {formatCents(invoice.amountCents)}
              </span>
            </div>

            {invoice.notes && (
              <p className="border-b border-border px-6 py-4 text-sm leading-relaxed text-muted-foreground">
                {invoice.notes}
              </p>
            )}

            <div className="px-6 py-6">
              {paid ? (
                <div>
                  <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-primary">
                    <Check className="h-3.5 w-3.5" />
                    Shipping payment received
                  </div>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    Thank you. Your shipment is released for dispatch and a receipt has been sent to
                    your email. Call 1-818-899-8090 with any questions.
                  </p>
                </div>
              ) : invoice.status === "void" ? (
                <p className="text-sm leading-relaxed text-muted-foreground">
                  This invoice has been withdrawn. Call 1-818-899-8090 and we will reissue it.
                </p>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={pay}
                    disabled={paying}
                    className="flex w-full items-center justify-center gap-2 bg-accent px-6 py-4 font-mono text-[11px] uppercase tracking-[0.2em] text-accent-foreground transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {paying ? (
                      <>
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        Starting checkout
                      </>
                    ) : (
                      <>
                        Pay {formatCents(invoice.amountCents)}
                        <ArrowRight className="h-3.5 w-3.5" />
                      </>
                    )}
                  </button>

                  {error && (
                    <p className="mt-4 border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs leading-relaxed text-destructive">
                      {error}
                    </p>
                  )}

                  <p className="mt-4 flex items-center justify-center gap-2 font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground">
                    <Lock className="h-3 w-3" />
                    Secure checkout · card payment
                  </p>
                </>
              )}
            </div>
          </div>
        )}
      </main>

      <SiteFooter />
    </div>
  );
}