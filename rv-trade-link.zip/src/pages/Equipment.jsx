import { useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import ListingCard from "@/components/listings/ListingCard";
import ListingFilters from "@/components/listings/ListingFilters";
import ListingPagination from "@/components/listings/ListingPagination";
import { sortInventoryListings } from "@/lib/newArrival";

const PAGE_SIZE = 30;

const postedTime = (listing) => {
  const time = new Date(listing?.created_date ?? 0).getTime();
  return Number.isNaN(time) ? 0 : time;
};

const priceOf = (listing) => typeof listing?.price === "number" ? listing.price : 0;

// Newest keeps the default inventory order (new arrivals first); the other
// options sort the whole inventory by posting date or price.
function sortListings(listings, sort) {
  if (sort === "newest") return sortInventoryListings(listings);
  const items = [...(listings ?? [])];
  if (sort === "oldest") return items.sort((a, b) => postedTime(a) - postedTime(b));
  if (sort === "price-asc") return items.sort((a, b) => priceOf(a) - priceOf(b));
  return items.sort((a, b) => priceOf(b) - priceOf(a));
}

export default function Equipment() {
  const [searchParams, setSearchParams] = useSearchParams();
  const category = searchParams.get("category") || "all";
  const brand = searchParams.get("brand") || "all";
  const sort = searchParams.get("sort") || "newest";
  const condition = searchParams.get("condition") || "all";
  const [brands, setBrands] = useState([]);
  const [search, setSearch] = useState("");
  const [term, setTerm] = useState("");
  const [allListings, setAllListings] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.Listing.aggregate({ query: { status: "active" }, groupBy: "brand" }).then(
      (result) => {
        const values = (result.rows ?? []).
        map((row) => row.brand).
        filter((value) => typeof value === "string" && value.trim());
        setBrands(values.sort((a, b) => a.localeCompare(b)));
      }
    );
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => setTerm(search.trim()), 300);
    return () => clearTimeout(timer);
  }, [search]);

  const buildQuery = () => {
    const query = { status: "active" };
    if (category !== "all") query.category = category;
    if (brand !== "all") query.brand = brand;
    if (condition !== "all") query.condition = condition;
    if (term) query.title = { $regex: term, $options: "i" };
    return query;
  };

  useEffect(() => {
    let active = true;
    setLoading(true);
    setPage(1);

    const loadAll = async () => {
      const query = buildQuery();
      const items = [];
      let cursor = null;
      do {
        const result = await base44.entities.Listing.filter(query, {
          sort: "-created_date",
          limit: 200,
          ...(cursor ? { cursor } : {})
        });
        items.push(...(result.items ?? []));
        cursor = result.has_more ? result.next_cursor : null;
      } while (cursor);
      return items;
    };

    loadAll().
    then((items) => {
      if (active) setAllListings(items);
    }).
    finally(() => {
      if (active) setLoading(false);
    });

    return () => {
      active = false;
    };
  }, [category, brand, condition, term]);

  const sortedListings = useMemo(() => sortListings(allListings, sort), [allListings, sort]);
  const total = sortedListings.length;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const listings = sortedListings.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const changeCategory = (next) => {
    const params = new URLSearchParams(searchParams);
    if (next === "all") params.delete("category");else
    params.set("category", next);
    setSearchParams(params, { replace: true });
  };

  const changeBrand = (next) => {
    const params = new URLSearchParams(searchParams);
    if (next === "all") params.delete("brand");else
    params.set("brand", next);
    setSearchParams(params, { replace: true });
  };

  const changeCondition = (next) => {
    const params = new URLSearchParams(searchParams);
    if (next === "all") params.delete("condition");else
    params.set("condition", next);
    setSearchParams(params, { replace: true });
  };

  const goToPage = (next) => {
    setPage(next);
    document.
    getElementById("inventory-results")?.
    scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const changeSort = (next) => {
    const params = new URLSearchParams(searchParams);
    if (next === "newest") params.delete("sort");else
    params.set("sort", next);
    setSearchParams(params, { replace: true });
    setPage(1);
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <section className="border-b border-border">
          <div className="mx-auto w-full max-w-7xl px-5 py-12 md:px-8 md:py-16">
            <div className="font-mono text-[10px] uppercase tracking-[0.26em] text-primary">
              / Inventory
            </div>
            <h1 className="mt-4 font-heading text-3xl font-semibold uppercase leading-[1.02] md:text-5xl">
              {condition === "refurbished" ? "refurbished equipment" : "medical equipment"}
            </h1>
          </div>
        </section>

        <ListingFilters
          category={category}
          onCategoryChange={changeCategory}
          condition={condition}
          onConditionChange={changeCondition}
          brand={brand}
          brands={brands}
          onBrandChange={changeBrand}
          search={search}
          onSearchChange={setSearch}
          sort={sort}
          onSortChange={changeSort}
          resultCount={total} />
        

        <section id="inventory-results" className="mx-auto w-full max-w-7xl px-5 py-12 md:px-8 md:py-16">
          {loading ?
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
              {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((item) =>
            <div key={item} className="animate-pulse border border-border bg-card">
                  <div className="aspect-[4/3] bg-secondary" />
                  <div className="space-y-3 p-5">
                    <div className="h-2 w-16 bg-secondary" />
                    <div className="h-3 w-3/4 bg-secondary" />
                    <div className="h-2 w-20 bg-secondary" />
                  </div>
                </div>
            )}
            </div> :
          !total ?
          <div className="border border-border bg-card px-6 py-16 text-center">
              <h2 className="font-heading text-xl font-semibold uppercase tracking-[0.02em]">
                No units match that search
              </h2>
              <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                Our stock changes weekly. Clear the filters to see everything, or tell us what you
                need and we will source it.
              </p>
              <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
                <button
                type="button"
                onClick={() => {
                  changeCategory("all");
                  changeBrand("all");
                  changeCondition("all");
                  setSearch("");
                }}
                className="border border-border px-5 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-foreground">
                
                  Clear filters
                </button>
                <Link
                to="/#contact"
                className="bg-primary px-5 py-3 font-mono text-[10px] uppercase tracking-[0.2em] text-primary-foreground">
                
                  Request equipment
                </Link>
              </div>
            </div> :

          <>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
                {listings.map((listing) =>
              <ListingCard key={listing.id} listing={listing} />
              )}
              </div>
              <ListingPagination
              page={currentPage}
              totalPages={totalPages}
              onChange={goToPage} />
            
            </>
          }
        </section>
      </main>
      <SiteFooter />
    </div>);

}