import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import Hero from "@/components/home/Hero";
import PartnerLogos from "@/components/home/PartnerLogos";
import ServicesGrid from "@/components/home/ServicesGrid";
import AboutBand from "@/components/home/AboutBand";
import SellCta from "@/components/home/SellCta";
import ContactSection from "@/components/home/ContactSection";
import { useAuth } from "@/lib/AuthContext";

export default function Home() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  return (
    <div className="soft-theme min-h-screen bg-canvas font-soft font-light text-ink">
      <SiteHeader />
      <main>
        <Hero />
        <PartnerLogos />
        <ServicesGrid />
        <AboutBand />
        {isAdmin && <SellCta />}
        <ContactSection />
      </main>
      <SiteFooter />
    </div>
  );
}