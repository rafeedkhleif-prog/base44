import { useCallback, useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import OfferRow from "@/components/offers/OfferRow";

const OPEN_STATUSES = ["pending", "countered"];

export default function OffersAdmin() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [offers, setOffers] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const page = await base44.entities.Offer.filter({}, { sort: "-created_date", limit: 100 });
    setOffers(page?.items ?? []);
  }, []);

  useEffect(() => {
    if (!isAdmin) {
      setLoading(false);
      return;
    }
    load().finally(() => setLoading(false));
  }, [isAdmin, load]);

  const replace = (updated) =>
    setOffers((current) => current.map((item) => (item.id === updated.id ? updated : item)));

  const openOffers = offers.filter((offer) => OPEN_STATUSES.includes(offer.status));
  const closedOffers = offers.filter((offer) => !OPEN_STATUSES.includes(offer.status));

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      <main className="mx-auto w-full max-w-4xl px-5 py-12 md:px-8 md:py-16">
        <div className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
          Internal
        </div>
        <h1 className="mt-3 font-heading text-3xl font-semibold tracking-tight md:text-4xl">
          Offers
        </h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground">
          Every best offer a buyer sends from an inventory page lands here. Accept it, counter it, or
          decline it; the buyer follows the answer on their private offer link.
        </p>

        {!isAdmin ? (
          <p className="mt-10 border border-border bg-card px-5 py-8 text-center font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            This page is limited to the shop team
          </p>
        ) : loading ? (
          <div className="mt-16 flex justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <>
            <section className="mt-10">
              <h2 className="font-mono text-[10px] uppercase tracking-[0.22em] text-primary">
                Waiting on us · {openOffers.length}
              </h2>
              <div className="mt-4 space-y-3">
                {openOffers.length ? (
                  openOffers.map((offer) => (
                    <OfferRow key={offer.id} offer={offer} onUpdated={replace} />
                  ))
                ) : (
                  <p className="border border-border bg-card px-5 py-8 text-center text-sm text-muted-foreground">
                    No offers waiting.
                  </p>
                )}
              </div>
            </section>

            <section className="mt-12">
              <h2 className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                Closed · {closedOffers.length}
              </h2>
              <div className="mt-4 space-y-3">
                {closedOffers.length ? (
                  closedOffers.map((offer) => (
                    <OfferRow key={offer.id} offer={offer} onUpdated={replace} />
                  ))
                ) : (
                  <p className="border border-border bg-card px-5 py-8 text-center text-sm text-muted-foreground">
                    No answered offers yet.
                  </p>
                )}
              </div>
            </section>
          </>
        )}
      </main>

      <SiteFooter />
    </div>
  );
}