import { useCallback, useEffect, useMemo, useState } from "react";
import { format, startOfMonth } from "date-fns";
import { base44 } from "@/api/base44Client";
import SiteHeader from "@/components/site/SiteHeader";
import SiteFooter from "@/components/site/SiteFooter";
import AvailabilityCalendar from "@/components/repair/AvailabilityCalendar";
import AppointmentForm from "@/components/repair/AppointmentForm";
import AppointmentList from "@/components/repair/AppointmentList";
import { useAuth } from "@/lib/AuthContext";

export default function RepairAdmin() {
  const { user, isLoadingAuth } = useAuth();
  const isAdmin = user?.role === "admin";
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [month, setMonth] = useState(startOfMonth(new Date()));
  const [selectedDate, setSelectedDate] = useState(format(new Date(), "yyyy-MM-dd"));

  const load = useCallback(async () => {
    const page = await base44.entities.RepairAppointment.list({ sort: "date", limit: 300 });
    setItems(page?.items ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    if (!isAdmin) return;
    load();
  }, [isAdmin, load]);

  const unavailableDates = useMemo(() => new Set(items.map((item) => item.date)), [items]);

  const handleDelete = async (item) => {
    await base44.entities.RepairAppointment.delete(item.id);
    load();
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl px-5 py-12 md:px-8">
        <div className="font-mono text-[10px] uppercase tracking-[0.24em] text-primary">
          Administrator
        </div>
        <h1 className="mt-3 font-heading text-3xl font-semibold uppercase tracking-[0.02em] md:text-4xl">
          Repair calendar
        </h1>
        <p className="mt-3 max-w-3xl text-sm leading-relaxed text-muted-foreground">
          Book visits taken by phone or email, and close days you cannot service. The Repair page
          shows customers these days as unavailable and blocks them from requesting them. Customer
          details stay on this page.
        </p>

        {isLoadingAuth || (isAdmin && loading) ? (
          <div className="mt-12 h-24 animate-pulse border border-border bg-card" />
        ) : !isAdmin ? (
          <p className="mt-10 border border-border bg-card px-4 py-6 text-sm text-muted-foreground">
            Administrator access is required to view or change the repair calendar.
          </p>
        ) : (
          <div className="mt-10 space-y-8">
            <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
              <div>
                <AvailabilityCalendar
                  month={month}
                  onMonthChange={setMonth}
                  unavailableDates={unavailableDates}
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  allowTaken
                />
                <p className="mt-3 font-mono text-[9px] uppercase leading-relaxed tracking-[0.14em] text-muted-foreground">
                  Pick a day on the calendar to load it into the form.
                </p>
              </div>
              <AppointmentForm date={selectedDate} onSaved={load} />
            </div>

            <div>
              <h2 className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
                Calendar entries
              </h2>
              <div className="mt-3">
                <AppointmentList items={items} onDelete={handleDelete} />
              </div>
            </div>
          </div>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}