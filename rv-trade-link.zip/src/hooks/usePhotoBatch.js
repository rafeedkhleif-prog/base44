import { useCallback, useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import useMattingWorker from "@/hooks/useMattingWorker";
import preparePhoto from "@/lib/mattingPipeline";
import { loadLogo } from "@/lib/mattingComposite";
import { photoBatch, applyPrepared, withPhotoTabLock, pause } from "@/lib/photoBatchClient";

export default function usePhotoBatch(isAdmin) {
  const [counts, setCounts] = useState({});
  const [audit, setAudit] = useState(null);
  const [building, setBuilding] = useState(false);
  const [running, setRunning] = useState(false);
  const [status, setStatus] = useState("");
  const [fatal, setFatal] = useState("");
  const [revision, setRevision] = useState(0);
  const stop = useRef(false);
  const worker = useMattingWorker();
  const refresh = useCallback(async () => { setCounts(await photoBatch("counts")); setRevision(v => v + 1); }, []);
  useEffect(() => {
    if (isAdmin) Promise.all([photoBatch("audit").then(setAudit), refresh()]).catch(e => setFatal(e.message));
    return () => { stop.current = true; };
  }, [isAdmin, refresh]);
  useEffect(() => {
    if (!running && !building) return;
    const warn = e => { e.preventDefault(); e.returnValue = ""; };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [running, building]);
  const onBuild = async () => {
    setBuilding(true); setFatal("");
    try {
      await withPhotoTabLock(async () => {
        let cursor, listed = 0, slots = 0, result;
        do {
          result = await photoBatch("build", { cursor });
          listed += result.listings; slots += result.slots;
          setStatus(`Audited ${listed} listings and ${slots} gallery slots`);
          cursor = result.has_more ? result.next_cursor : null;
          await pause(2500);
        } while (cursor);
        setAudit(await photoBatch("finalize"));
        await refresh();
        setStatus("Queue built. Inspect the pilot before running production application.");
      });
    } catch (e) { setFatal(e.message); } finally { setBuilding(false); }
  };
  const onRun = async () => {
    if (running) return;
    setRunning(true); setFatal(""); stop.current = false;
    try {
      await withPhotoTabLock(async () => {
        const logo = await loadLogo();
        let lastRefresh = 0;
        while (!stop.current) {
          const began = Date.now();
          const work = await photoBatch("next");
          if (work.type === "idle") break;
          if (work.type === "busy") { setStatus("Another browser holds a photo claim. Resume after it stops or expires."); break; }
          if (work.type === "apply") await applyPrepared(work.prep_id);
          if (work.type === "process") {
            const record = work.record;
            setStatus(`Preparing ${record.listing_title || record.source_kind}`);
            let result;
            try { result = await preparePhoto({ url: record.source_url, worker, logo }); }
            catch (e) { await photoBatch("fail", { prep_id: record.id, claim_token: record.claim_token, error: e.message }); }
            if (result) {
              // Public because these are the storefront's public equipment photographs.
              const { file_url } = await base44.integrations.Core.UploadPublicFile({ file: new File([result.blob], `${record.id}-white-mri.png`, { type: "image/png" }) });
              const saved = await photoBatch("finish", { prep_id: record.id, claim_token: record.claim_token, result: { outputUrl: file_url, bytes: result.blob.size, coverage: result.coverage, inkShare: result.inkShare, detailRetention: result.detailRetention, method: result.method, ms: result.ms } });
              if (saved.verified) await applyPrepared(record.id);
            }
          }
          if (Date.now() - lastRefresh > 10000) { await refresh(); lastRefresh = Date.now(); }
          await pause(Math.max(0, 3000 - (Date.now() - began)));
        }
        await refresh();
        if (!stop.current) setStatus("Pass finished. Failed, conflicted and non-white previews remain pending review.");
      });
    } catch (e) { setFatal(e.message); } finally { setRunning(false); }
  };
  const onAction = async (action, row) => {
    setFatal("");
    try {
      await withPhotoTabLock(async () => {
        if (action === "rollback") {
          if (!window.confirm("Restore this listing's original gallery in its original order? Concurrent edits will block rollback; no files will be deleted.")) return;
          await photoBatch(action, { backup_id: row.backup_id });
        } else {
          if (action === "approve" && !window.confirm("I inspected the original and result: the full equipment, labels and edges are intact. Apply this result to every mapped slot?")) return;
          const result = await photoBatch(action, { slot_id: row.id });
          if (action === "approve") await applyPrepared(result.prep_id);
        }
        await refresh();
      });
    } catch (e) { setFatal(e.message); }
  };
  return { counts, audit, building, running, status, fatal: fatal || worker.error, device: worker.device, revision, onBuild, onRun, onStop: () => { stop.current = true; setStatus("Stopping after this photo and its application"); }, onAction };
}