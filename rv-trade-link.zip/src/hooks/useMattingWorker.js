import { useCallback, useEffect, useRef, useState } from "react";
import photoError from "@/lib/photoError";

const LOAD_TIMEOUT_MS = 600000;
const SEGMENT_TIMEOUT_MS = 240000;

// Owns the inference worker: one model load, sequential photo jobs, a timeout per job so a
// wedged inference surfaces as an error instead of an endless spinner.
export default function useMattingWorker() {
  const workerRef = useRef(null);
  const pendingRef = useRef(new Map());
  const [device, setDevice] = useState("");
  const [error, setError] = useState("");
  const [stage, setStage] = useState("");

  const ensureWorker = useCallback(() => {
    if (workerRef.current) return workerRef.current;
    const worker = new Worker(new URL("../workers/matting.worker.js", import.meta.url), {
      type: "module",
    });
    worker.onmessage = (event) => {
      const { id, type, device: engine, mask, maskWidth, maskHeight, diagnostics, message, stage: nextStage, detail } = event.data || {};
      if (engine) setDevice(engine);
      const resolver = pendingRef.current.get(id);
      if (!resolver) return;
      if (type === "stage") {
        setStage(detail || nextStage);
        resolver.onStage?.(nextStage);
      } else if (type === "ready") {
        pendingRef.current.delete(id);
        resolver.resolve({});
      } else if (type === "mask") {
        pendingRef.current.delete(id);
        resolver.resolve({ mask, maskWidth, maskHeight, diagnostics });
      } else if (type === "error") {
        pendingRef.current.delete(id);
        resolver.reject(new Error(message));
      }
    };
    worker.onerror = (event) => {
      const reason = photoError(event.message || "The inference worker crashed", "512 WASM worker");
      setError(reason);
      for (const [, resolver] of pendingRef.current) resolver.reject(new Error(reason));
      pendingRef.current.clear();
      worker.terminate();
      workerRef.current = null;
    };
    workerRef.current = worker;
    return worker;
  }, []);

  const request = useCallback(
    (payload, transfer, timeoutMs, label, onStage) =>
      new Promise((resolve, reject) => {
        setError("");
        const worker = ensureWorker();
        const id = `${payload.type}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
        const timer = setTimeout(() => {
          if (!pendingRef.current.has(id)) return;
          const reason = new Error(`${label} timed out after ${Math.round(timeoutMs / 1000)}s`);
          worker.terminate();
          workerRef.current = null;
          for (const [, resolver] of pendingRef.current) resolver.reject(reason);
          pendingRef.current.clear();
        }, timeoutMs);
        pendingRef.current.set(id, {
          onStage,
          resolve: (value) => {
            clearTimeout(timer);
            resolve(value);
          },
          reject: (reason) => {
            clearTimeout(timer);
            reject(reason);
          },
        });
        worker.postMessage({ ...payload, id }, transfer);
      }),
    [ensureWorker],
  );

  const load = useCallback(
    () => request({ type: "load" }, [], LOAD_TIMEOUT_MS, "Model load"),
    [request],
  );

  const segment = useCallback(
    (rgba, width, height, onStage, options = {}) =>
      request({ type: "segment", rgba, width, height, ...options }, [rgba.buffer, ...(options.expectedLogits ? [options.expectedLogits.buffer] : [])], SEGMENT_TIMEOUT_MS, "512 WASM mask inference", onStage),
    [request],
  );

  useEffect(
    () => () => {
      workerRef.current?.terminate();
      workerRef.current = null;
      pendingRef.current.clear();
    },
    [],
  );

  return { device, error, stage, load, segment };
}