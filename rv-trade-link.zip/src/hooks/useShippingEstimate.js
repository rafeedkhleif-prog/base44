import { useCallback, useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";

// Shipping is priced for the next business day: tomorrow, and a weekend rolls to Monday.
// The buyer never picks the date.
const defaultShipDate = () => {
  const date = new Date();
  date.setDate(date.getDate() + 1);
  while (date.getDay() === 0 || date.getDay() === 6) {
    date.setDate(date.getDate() + 1);
  }
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${date.getFullYear()}-${month}-${day}`;
};

const asText = (value) => (value === 0 || value ? String(value) : "");

function initialInputs(listing) {
  return {
    toZip: "",
    shipDate: defaultShipDate(),
    destinationType: "residential",
    weightLbs: asText(listing?.weight_lbs),
    lengthIn: asText(listing?.length_in),
    widthIn: asText(listing?.width_in),
    heightIn: asText(listing?.height_in),
  };
}

const isComplete = (inputs) =>
  /^\d{5}$/.test(String(inputs.toZip).trim()) &&
  /^\d{4}-\d{2}-\d{2}$/.test(String(inputs.shipDate)) &&
  ["weightLbs", "lengthIn", "widthIn", "heightIn"].every((key) => Number(inputs[key]) > 0);

export default function useShippingEstimate(listing) {
  const [inputs, setInputs] = useState(() => initialInputs(listing));
  const [fromZip, setFromZip] = useState("");
  const [estimate, setEstimate] = useState(null);
  const [status, setStatus] = useState("idle");
  const [message, setMessage] = useState("");
  const [restoredAt, setRestoredAt] = useState("");
  const requestRef = useRef(0);
  const touchedRef = useRef(false);

  // Restore the estimate saved against this listing when it is reopened.
  useEffect(() => {
    if (!listing?.id) return undefined;
    let active = true;
    base44.functions
      .invoke("shipping-estimate", { listingId: listing.id, restore: true })
      .then((response) => {
        const saved = response?.data?.saved;
        if (!active || !saved) return;
        setFromZip(saved.fromZip || "");
        setInputs({
          toZip: saved.toZip || "",
          shipDate: defaultShipDate(),
          destinationType: saved.destinationType || "residential",
          weightLbs: asText(saved.weightLbs),
          lengthIn: asText(saved.lengthIn),
          widthIn: asText(saved.widthIn),
          heightIn: asText(saved.heightIn),
        });
        setEstimate(saved);
        setStatus("ready");
        setRestoredAt(saved.calculatedAt || saved.shipDate || "");
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [listing?.id]);

  const calculate = useCallback(
    async (override) => {
      const payload = override ?? inputs;
      if (!isComplete(payload)) {
        setEstimate(null);
        setStatus("idle");
        setMessage("");
        return;
      }
      const requestId = requestRef.current + 1;
      requestRef.current = requestId;
      setStatus("calculating");
      setMessage("");
      try {
        const response = await base44.functions.invoke("shipping-estimate", {
          listingId: listing?.id,
          ...payload,
        });
        if (requestId !== requestRef.current) return;
        const data = response?.data ?? {};
        if (data.ok && data.estimate) {
          setEstimate(data.estimate);
          setFromZip(data.estimate.fromZip || "");
          setStatus("ready");
          setRestoredAt("");
        } else {
          setEstimate(null);
          setStatus("unavailable");
          setMessage(data.message || "Estimated shipping is unavailable.");
        }
      } catch (error) {
        if (requestId !== requestRef.current) return;
        setEstimate(null);
        setStatus("unavailable");
        setMessage(
          error?.response?.data?.message || "Estimated shipping is unavailable right now."
        );
      }
    },
    [inputs, listing?.id]
  );

  const updateInput = useCallback((key, value) => {
    touchedRef.current = true;
    setInputs((previous) => ({ ...previous, [key]: value }));
  }, []);

  // Recalculate automatically once every detail is valid.
  useEffect(() => {
    if (!touchedRef.current) return undefined;
    if (!isComplete(inputs)) return undefined;
    const timer = setTimeout(() => calculate(inputs), 700);
    return () => clearTimeout(timer);
  }, [inputs, calculate]);

  return {
    inputs,
    updateInput,
    fromZip,
    estimate,
    status,
    message,
    restoredAt,
    calculate,
    complete: isComplete(inputs),
  };
}