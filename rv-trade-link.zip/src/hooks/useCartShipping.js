import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

const PACKAGE_KEYS = ["weight_lbs", "length_in", "width_in", "height_in"];

// Shipping is priced for the next business day: tomorrow, and a weekend rolls to Monday.
const defaultShipDate = () => {
  const date = new Date();
  date.setDate(date.getDate() + 1);
  while (date.getDay() === 0 || date.getDay() === 6) {
    date.setDate(date.getDate() + 1);
  }
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${date.getFullYear()}-${month}-${day}`;
};

export const emptyAddress = {
  street: "",
  city: "",
  state: "",
  zip: "",
  destinationType: "residential",
};

export const isAddressComplete = (address) =>
  String(address?.street || "").trim().length > 3 &&
  Boolean(String(address?.city || "").trim()) &&
  Boolean(String(address?.state || "").trim()) &&
  /^\d{5}$/.test(String(address?.zip || "").trim());

// Prices the whole cart for the delivery address: each unit is rated as its own package and the
// handling fee is counted once for the order. Mirrors what create-checkout charges server-side.
export default function useCartShipping(listings, address) {
  const [estimate, setEstimate] = useState(null);
  const [status, setStatus] = useState("idle");
  const [message, setMessage] = useState("");

  const ids = listings.map((listing) => listing.id).join(",");
  const complete = isAddressComplete(address);
  const ratable =
    listings.length > 0 &&
    listings.every((listing) => PACKAGE_KEYS.every((key) => Number(listing[key]) > 0));
  const shipDate = defaultShipDate();

  useEffect(() => {
    if (!complete || !ratable) {
      setEstimate(null);
      setStatus("idle");
      setMessage("");
      return undefined;
    }
    let active = true;
    setStatus("calculating");
    setMessage("");
    const timer = setTimeout(() => {
      Promise.all(
        listings.map((listing) =>
          base44.functions
            .invoke("shipping-estimate", {
              listingId: listing.id,
              toZip: String(address.zip).trim(),
              destinationType: address.destinationType || "residential",
              shipDate,
              weightLbs: listing.weight_lbs,
              lengthIn: listing.length_in,
              widthIn: listing.width_in,
              heightIn: listing.height_in,
            })
            .then((response) => response?.data ?? {})
            .catch(() => ({}))
        )
      ).then((results) => {
        if (!active) return;
        if (results.length && results.every((result) => result.ok && result.estimate)) {
          const upsCents = results.reduce((sum, result) => sum + (result.estimate.upsCents || 0), 0);
          const handlingCents = results[0].estimate.handlingCents || 0;
          setEstimate({
            upsCents,
            handlingCents,
            totalCents: upsCents + handlingCents,
            service: results[0].estimate.service || "UPS Ground",
          });
          setStatus("ready");
        } else {
          setEstimate(null);
          setStatus("unavailable");
          setMessage(
            results.find((result) => result.message)?.message ||
              "Shipping cannot be priced for this address — it will be invoiced after your order."
          );
        }
      });
    }, 400);
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [ids, complete, ratable, shipDate, address.zip, address.destinationType]);

  return { estimate, status, message, complete, ratable, shipDate };
}