import { useEffect, useState } from "react";
import { readCart } from "@/lib/cart";

// Listing ids currently in the buyer's cart, kept in sync across tabs and components.
export default function useCart() {
  const [ids, setIds] = useState(() => readCart());

  useEffect(() => {
    const sync = () => setIds(readCart());
    window.addEventListener("cart:change", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("cart:change", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  return ids;
}