import { useState } from "react";
import { prepareEbayExport } from "@/lib/ebayExportSource";
import { runEbayExportImport } from "@/lib/ebayImportRun";

const initialState = { files: [], prepared: null, phase: "idle", progress: null, summary: null, error: "" };
const filePath = (file) => file.webkitRelativePath || file.name;

export default function useEbayExportImport({ user, onComplete }) {
  const [state, setState] = useState(initialState);
  const update = (fields) => setState((previous) => ({ ...previous, ...fields }));
  const pick = async (event, replace = false) => {
    const next = Array.from(event.target.files || []);
    event.target.value = "";
    if (!next.length) return;
    const startsExport = replace || next.some((file) => /^(?:index\.html?|listings\.(?:json|csv))$/i.test(file.name));
    const paths = new Set(next.map(filePath));
    const files = startsExport ? next : [...state.files.filter((file) => !paths.has(filePath(file))), ...next];
    update({ files, prepared: null, phase: "checking", summary: null, error: "", progress: null });
    try {
      update({ prepared: await prepareEbayExport(files) });
    } catch (error) {
      update({ error: error?.message || "The export could not be read. Choose a ZIP containing its index and photo folders." });
    } finally {
      update({ phase: "idle" });
    }
  };
  const run = async () => {
    if (!state.prepared?.canImport || state.phase !== "idle") return;
    update({ phase: "importing", error: "", summary: null });
    try {
      const summary = await runEbayExportImport({ prepared: state.prepared, seller: user, onProgress: (progress) => update({ progress }) });
      update({ summary });
      if (summary.created || summary.updated) onComplete?.();
    } catch (error) {
      update({ error: error?.message || "The import could not run." });
    } finally {
      update({ phase: "idle", progress: null });
    }
  };
  return { ...state, busy: state.phase !== "idle", pick, run, reset: () => setState(initialState) };
}