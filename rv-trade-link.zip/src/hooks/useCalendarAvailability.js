import { useCallback, useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

// Reads a public availability list (repair or pickup). Only dates come back —
// never appointment details.
export default function useCalendarAvailability(functionName) {
  const [unavailableDates, setUnavailableDates] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const refresh = useCallback(async () => {
    try {
      const response = await base44.functions.invoke(functionName, {});
      const list = response?.data?.unavailableDates ?? [];
      const next = new Set(list);
      setUnavailableDates(next);
      setError("");
      return next;
    } catch (err) {
      setError("Live availability could not be loaded. Please call 1-818-899-8090 to confirm a day.");
      return null;
    } finally {
      setLoading(false);
    }
  }, [functionName]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { unavailableDates, loading, error, refresh };
}