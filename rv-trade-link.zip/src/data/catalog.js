// Static catalog shared by the site chrome and the equipment filters.
export const CATEGORIES = [
  { slug: "hospital-beds", label: "Hospital Beds" },
  { slug: "gurneys", label: "Gurneys & Stretchers" },
  { slug: "exam-tables", label: "Exam & Procedure Tables" },
  { slug: "surgical-tables", label: "Surgical Tables" },
  { slug: "surgical-lights", label: "Surgical Lights" },
  { slug: "surgical-instruments", label: "Surgical Instruments" },
  { slug: "patient-monitors", label: "Patient Monitors" },
  { slug: "vital-signs", label: "Vital Signs Equipment" },
  { slug: "blood-pressure-monitors", label: "Blood Pressure Monitors" },
  { slug: "ekg-monitors", label: "EKG / ECG Monitors" },
  { slug: "monitors", label: "Other Monitors" },
  { slug: "defibrillators", label: "Defibrillators" },
  { slug: "ventilators", label: "Ventilators" },
  { slug: "anesthesia", label: "Anesthesia" },
  { slug: "pumps", label: "Pumps" },
  { slug: "sterilizers", label: "Sterilizers" },
  { slug: "ultrasound", label: "Ultrasound" },
  { slug: "diagnostic-imaging", label: "X-Ray & Imaging" },
  { slug: "endoscopy", label: "Endoscopy" },
  { slug: "lab-equipment", label: "Lab Equipment" },
  { slug: "respiratory", label: "Respiratory Therapy" },
  { slug: "physical-therapy", label: "Physical Therapy" },
  { slug: "ophthalmology", label: "Ophthalmology" },
  { slug: "dental", label: "Dental Equipment" },
  { slug: "wheelchairs", label: "Wheelchairs" },
  { slug: "carts", label: "Carts & Stands" },
  { slug: "batteries", label: "Batteries" },
  { slug: "mobile-units", label: "Mobile Medical Units" },
  { slug: "parts-accessories", label: "Parts & Accessories" },
  { slug: "other-equipment", label: "Other Equipment" },
];

export const CONDITIONS = [
  { value: "new", label: "New" },
  { value: "refurbished", label: "Refurbished" },
  { value: "used", label: "Used" },
  { value: "for-parts", label: "For parts only" },
];

export const conditionLabel = (value) =>
  CONDITIONS.find((c) => c.value === value)?.label ?? "Refurbished";

export const categoryLabel = (slug) =>
  CATEGORIES.find((c) => c.slug === slug)?.label ?? "Medical Equipment";