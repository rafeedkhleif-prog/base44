// Catalogue photo shown for each equipment category on refurbished units, so
// every refurbished listing has a clean photo even when the seller sent none.
const BASE = "https://media.base44.com/images/public/6aeb6aa1c91d4c8d5bcd4ce8/";

export const CATEGORY_PHOTOS = {
  "hospital-beds": BASE + "06ffd8b2e_generated_image.png",
  gurneys: BASE + "59bedf203_generated_image.png",
  "exam-tables": BASE + "85b8de520_generated_image.png",
  "surgical-tables": BASE + "1ab57c1af_generated_image.png",
  "surgical-lights": BASE + "2528d4f7c_generated_image.png",
  "surgical-instruments": BASE + "2df1d61f7_generated_image.png",
  "patient-monitors": BASE + "5a6c711d7_generated_image.png",
  "vital-signs": BASE + "5a6c711d7_generated_image.png",
  "blood-pressure-monitors": BASE + "5a6c711d7_generated_image.png",
  monitors: BASE + "5a6c711d7_generated_image.png",
  "ekg-monitors": BASE + "55aec01f8_generated_image.png",
  defibrillators: BASE + "60a3d17c6_generated_image.png",
  ventilators: BASE + "b1605fb3f_generated_image.png",
  anesthesia: BASE + "8b681b76b_generated_image.png",
  pumps: BASE + "371d7e2b1_generated_image.png",
  sterilizers: BASE + "951fa149a_generated_image.png",
  "lab-equipment": BASE + "3a95a478a_generated_image.png",
  ultrasound: BASE + "3885e6a72_generated_image.png",
  "diagnostic-imaging": BASE + "338f040a8_generated_image.png",
  endoscopy: BASE + "6aae8299a_generated_image.png",
  respiratory: BASE + "dbd44bac1_generated_image.png",
  "physical-therapy": BASE + "34ddce380_generated_image.png",
  ophthalmology: BASE + "9c33e513e_generated_image.png",
  dental: BASE + "65385a625_generated_image.png",
  wheelchairs: BASE + "b1ba39d84_generated_image.png",
  carts: BASE + "567749b07_generated_image.png",
  batteries: BASE + "8ca5503da_generated_image.png",
  "parts-accessories": BASE + "8ca5503da_generated_image.png",
  "mobile-units": BASE + "7f585ca18_generated_image.png",
  "other-equipment": BASE + "421a42dfb_generated_image.png",
};

export const DEFAULT_CATEGORY_PHOTO = BASE + "421a42dfb_generated_image.png";

// Catalogue photo for a listing, picked by category.
export const categoryPhoto = (listing) =>
  CATEGORY_PHOTOS[listing?.category] ?? DEFAULT_CATEGORY_PHOTO;

// A listing shows its own photo when it has one, so the picture matches the
// exact model; a refurbished unit with no photo falls back to its category's
// catalogue photo.
export const listingPhoto = (listing) =>
  listing?.images?.[0] || (listing?.condition === "refurbished" ? categoryPhoto(listing) : undefined);