// Base44 Payments checkout starter — base44/functions/create-checkout/entry.ts
//
// Provided by the platform. Do NOT rewrite the plumbing (session construct + persisting the
// join key + return-URL resolution). Edit only the region marked `// ===== APP-SPECIFIC =====`
// to resolve — SERVER-SIDE — what the buyer is purchasing and its price.
//
// PUBLIC by default: a buyer does NOT need to be logged in to check out. Backend function routes
// are callable anonymously, and storefront buyers often have no account — requiring login here is
// what blocks real purchases. If a buyer IS signed in we record their app-user id as the
// fulfillment target; otherwise the purchase is retained for a verified email claim. Never 401 here.
//
// CRITICAL: Wix's checkout has NO custom-metadata field, so the returned `checkoutSession.id` is
// the ONLY thing that ties this payment back to this purchase. We persist it on a pending
// Base44Purchase BEFORE redirecting; the webhook resolves the purchase by that same id
// (order.checkoutId === checkoutSession.id). Skipping this write makes fulfillment impossible.

import { createClientFromRequest } from "npm:@base44/sdk";
import {
  estimateShipment,
  loadRateSources,
  normalizeShippingInput,
} from "../../shared/upsRate.ts";

type CheckoutProduct = {
  name: string; price: string; currency: string; maxQuantity: number;
  subscriptionInfo?: {
    subscriptionSettings: {
      frequency: string; interval?: number; autoRenewal?: boolean; billingCycles?: number;
      freeTrialPeriod?: { frequency: string; interval: number };
    };
    title?: string; description?: string;
  };
};

const CONSTRUCT_URL = "https://www.wixapis.com/payments/platform/v1/checkout-sessions/construct";

// The app's public base URL for the buyer's return links. Use the platform-injected
// `X-Base44-App-Url` header (server-set from app state — correct behind custom domains), then the
// server-owned `WIX_CHECKOUT_APP_URL` secret. We do NOT fall back to the request `Origin`: it's
// caller-controlled, so a spoofed Origin would make Wix send the paid buyer to an attacker page
// (open redirect). Both sources above are always present for a connected payments app.
function resolveAppUrl(req: Request): string {
  return (
    req.headers.get("x-base44-app-url") ||
    Deno.env.get("WIX_CHECKOUT_APP_URL") ||
    ""
  );
}

Deno.serve(async (req: Request) => {
  try {
    if (req.method !== "POST") {
      return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405 });
    }
    // Read per request, never at module scope: disconnecting payments blanks these, and a warm
    // isolate that captured them at startup would keep charging with the old credentials.
    const WIX_API_KEY = Deno.env.get("WIX_CHECKOUT_API_KEY");
    const WIX_SITE_ID = Deno.env.get("WIX_CHECKOUT_SITE_ID");
    if (!WIX_API_KEY || !WIX_SITE_ID) {
      console.error("create-checkout: Wix payment config not set");
      return new Response(JSON.stringify({ error: "Payments not configured" }), { status: 500 });
    }

    const appUrl = resolveAppUrl(req);
    if (!appUrl) {
      // Fail closed: with no server-owned app URL (both the X-Base44-App-Url header AND the
      // WIX_CHECKOUT_APP_URL secret are absent — e.g. a slug-less or partially-wired app) we'd build
      // relative return links like `/ThankYou` and strand the paid buyer. Never fall back to the
      // caller-controlled Origin (open redirect). Reconnecting payments repopulates the secret.
      console.error("create-checkout: no app URL (X-Base44-App-Url header and WIX_CHECKOUT_APP_URL both empty)");
      return new Response(JSON.stringify({ error: "Payments not configured" }), { status: 500 });
    }
    const base44 = createClientFromRequest(req);

    // Capture the buyer's app-user id IF signed in — but never REQUIRE it. This is the
    // fulfillment target the webhook grants to; when absent (anonymous buyer) the webhook grants
    // by the email the buyer enters on Wix's checkout page.
    let appUser = null;
    try {
      appUser = await base44.auth.me();
    } catch (_) {
      appUser = null;
    }

    const body = await req.json().catch(() => ({}));

    // ===== APP-SPECIFIC =====
    // Two things can be paid here: a unit from the marketplace, or the separate shipping invoice
    // issued for a unit whose shipping was not charged with the item. Both amounts are resolved
    // server-side from records the buyer cannot write.
    let invoice: any = null;
    let invoiceCents = 0;
    let offer: any = null;
    const invoiceId = typeof body.shippingInvoiceId === "string" ? body.shippingInvoiceId : "";
    if (invoiceId) {
      const invoiceToken = typeof body.token === "string" ? body.token : "";
      if (!invoiceToken) {
        return new Response(JSON.stringify({ error: "Missing invoice link" }), { status: 400 });
      }
      invoice = await base44.asServiceRole.entities.ShippingInvoice
        .get(invoiceId)
        .catch((e: any) => (e?.status === 404 ? null : Promise.reject(e)));
      if (!invoice || invoice.token !== invoiceToken) {
        return new Response(JSON.stringify({ error: "Shipping invoice not found" }), { status: 404 });
      }
      if (invoice.status === "paid") {
        return new Response(JSON.stringify({ error: "This shipping invoice is already paid" }), { status: 409 });
      }
      invoiceCents = Number(invoice.amountCents);
      if (!Number.isSafeInteger(invoiceCents) || invoiceCents < 50) {
        console.error("create-checkout: shipping invoice amount invalid", { invoiceId, amountCents: invoice.amountCents });
        return new Response(JSON.stringify({ error: "Invoice amount is not available" }), { status: 409 });
      }
    }

    let product: CheckoutProduct;
    let productId = "";
    let quantity = 1;
    let price = "0";
    let shipping: any = null;
    let destinationZip = "";
    let shippingService = "";
    let shippingCents = 0;
    let itemCents = 0;
    let totalCents = 0;
    let productName = "";
    let currency = "USD";
    let subscriptionInfo: any = null;
    let freeTrial = false;
    let shippingMode: "rated" | "freight" | "invoiced_later" = "rated";
    // Where Wix returns the buyer. Both MUST be real, PUBLICLY reachable routes in this app: the
    // returning buyer is often anonymous, so a missing or login-gated route strands a paid customer.
    let thankYouPath = "/ThankYou";
    const postFlowPath = "/equipment";
    // Cart checkout: every unit is a separate line item, and the listing ids are what the webhook
    // retires from stock once the payment is confirmed.
    const cartIds: string[] = Array.isArray(body.items)
      ? ([...new Set(body.items.filter((value: unknown) => typeof value === "string" && value))] as string[]).slice(0, 10)
      : [];
    const cartItems: any[] = [];
    const cartListingIds: string[] = [];
    // Delivery address the cart order ships to, saved with the purchase for the shop.
    let shipToAddress = "";
    let shipToType = "";

    if (invoice) {
      // Shipping invoice: charge only the freight/shipping amount the team invoiced for an item
      // that was already paid for. Return the buyer to the invoice page, which then reads as paid.
      productName = `Shipping & handling — ${invoice.listingTitle || "equipment"}`;
      currency = invoice.currency || "USD";
      price = (invoiceCents / 100).toFixed(2);
      product = { name: productName, price, currency, maxQuantity: 1 };
      totalCents = invoiceCents;
      thankYouPath = `/shipping-invoice/${encodeURIComponent(invoice.token)}?paid=1`;
    } else if (cartIds.length) {
      // A cart pays for several units at once. Every line item's price is read from its own Listing
      // record server-side, so the buyer can never set a price. One consolidated shipment is quoted
      // on the packed weights and destination after the order and invoiced separately, so checkout
      // charges exactly the units' asking prices.
      const records: any[] = [];
      for (const id of cartIds) {
        const record = await base44.asServiceRole.entities.Listing
          .get(id)
          .catch((e: any) => (e?.status === 404 ? null : Promise.reject(e)));
        if (!record || record.status !== "active") {
          return new Response(
            JSON.stringify({ error: "One of the units in your cart is no longer available" }),
            { status: 409 },
          );
        }
        const unitPrice = Number(record.price);
        if (record.price_on_request || !Number.isFinite(unitPrice) || unitPrice <= 0) {
          console.error("create-checkout: cart unit has no online price", { listingId: id, price: record.price });
          return new Response(
            JSON.stringify({ error: `${record.title || "A unit"} in your cart must be priced by phone` }),
            { status: 409 },
          );
        }
        records.push(record);
      }
      cartListingIds.push(...records.map((record) => record.id));
      for (const record of records) {
        cartItems.push({
          name: String(record.title || "Medical equipment"),
          quantity: 1,
          price: Number(record.price).toFixed(2),
        });
      }
      itemCents = records.reduce((sum, record) => sum + Math.round(Number(record.price) * 100), 0);
      quantity = records.length;
      productName = `Marketplace cart — ${records.length} ${records.length === 1 ? "unit" : "units"}`;

      // Shipping is priced on the delivery address the buyer entered in the cart. Each unit is rated
      // as its own package and our handling fee is counted once for the order, so the charged amount
      // is always recomputed here from published rates — never taken from the browser.
      const shipDate = String(body.shipDate || "").slice(0, 10) || new Date().toISOString().slice(0, 10);
      const toZip = String(body.toZip || "").trim();
      const deliveryType = body.destinationType === "commercial" ? "commercial" : "residential";
      const address = body.shipAddress && typeof body.shipAddress === "object" ? body.shipAddress : {};
      const street = String((address as any).street || "").trim().slice(0, 120);
      const city = String((address as any).city || "").trim().slice(0, 80);
      const state = String((address as any).state || "").trim().slice(0, 40);
      shipToAddress = [street, `${city}${state ? `, ${state}` : ""} ${toZip}`.trim()]
        .filter(Boolean)
        .join(", ");
      shipToType = deliveryType;

      const rateSources = /^\d{5}$/.test(toZip) ? await loadRateSources(base44, shipDate) : null;
      let upsCents = 0;
      let handlingCents = 0;
      let service = "";
      let rated = Boolean(rateSources);
      if (rateSources) {
        for (const record of records) {
          // A unit with no packed weight and dimensions cannot be rated, so the whole order's
          // shipping falls back to a quote and a separate invoice (never free shipping).
          const packed = (["weight_lbs", "length_in", "width_in", "height_in"] as const).every(
            (key) => Number((record as any)[key]) > 0,
          );
          if (!packed) {
            rated = false;
            break;
          }
          // Package details come from the listing record only: a buyer cannot cheapen the rate by
          // posting their own weight or box size.
          const normalized = normalizeShippingInput(
            {
              toZip,
              destinationType: deliveryType,
              shipDate,
              weightLbs: record.weight_lbs,
              lengthIn: record.length_in,
              widthIn: record.width_in,
              heightIn: record.height_in,
            },
            { fromZip: rateSources.settings?.origin_zip },
          );
          if (normalized.ok !== true) {
            rated = false;
            break;
          }
          const rating = estimateShipment({ input: normalized.input, ...(rateSources as any) });
          if (rating.ok !== true) {
            rated = false;
            break;
          }
          upsCents += rating.estimate.upsCents;
          handlingCents = rating.estimate.handlingCents;
          service = rating.estimate.service;
        }
      }
      shipping = null;
      if (rated && upsCents + handlingCents > 0) {
        shippingCents = upsCents + handlingCents;
        destinationZip = toZip;
        shippingService = service || "UPS Ground";
        shippingMode = "rated";
      } else {
        shippingCents = 0;
        shippingMode = "invoiced_later";
        console.warn("create-checkout: cart shipping invoiced later", { cartIds, toZip });
      }
      totalCents = itemCents + shippingCents;
      product = { name: productName, price: (totalCents / 100).toFixed(2), currency: "USD", maxQuantity: 1 };
    } else {
      // The catalog is the marketplace itself: each Listing record holds the seller's asking price.
      // The price and currency are read from the record server-side; never from the request body.
      // Buyers never create or update Listing records (only the seller or an admin can), so the
      // stored price cannot be set by the person paying.
      productId = typeof body.productId === "string" ? body.productId : "";
      if (!productId) {
        return new Response(JSON.stringify({ error: "Missing listing" }), { status: 400 });
      }
      const listing = await base44.asServiceRole.entities.Listing
        .get(productId)
        .catch((e: any) => (e?.status === 404 ? null : Promise.reject(e)));
      if (!listing) {
        return new Response(JSON.stringify({ error: "Listing not found" }), { status: 404 });
      }
      if (listing.status !== "active") {
        return new Response(JSON.stringify({ error: "This listing is no longer available" }), { status: 409 });
      }

      // An accepted best offer is paid at the agreed amount. The offer record is server-owned: the
      // buyer can only pay a token for an offer the shop has already accepted.
      const offerToken = typeof body.offerToken === "string" ? body.offerToken.trim() : "";
      if (offerToken) {
        const found = await base44.asServiceRole.entities.Offer.filter({ token: offerToken }, { limit: 1 });
        offer = found?.items?.[0] ?? null;
        if (!offer) {
          return new Response(JSON.stringify({ error: "Offer not found" }), { status: 404 });
        }
        if (offer.listing_id !== listing.id) {
          return new Response(JSON.stringify({ error: "This offer is for a different unit" }), { status: 400 });
        }
        if (offer.status !== "accepted") {
          return new Response(JSON.stringify({ error: "This offer has not been accepted yet" }), { status: 409 });
        }
        if (offer.paid_at) {
          return new Response(JSON.stringify({ error: "This offer is already paid" }), { status: 409 });
        }
      }

      const unitPrice = offer ? Number(offer.amount) : Number(listing.price);
      if (!Number.isFinite(unitPrice) || unitPrice <= 0) {
        console.error("create-checkout: listing has an invalid price", { productId, price: listing.price });
        return new Response(JSON.stringify({ error: "Listing price is not available" }), { status: 409 });
      }
      itemCents = Math.round(unitPrice * 100);
      productName = String(listing.title || "Medical equipment");
      // Each listing is a single physical unit.
      quantity = 1;
      // Configure subscriptions (including freeTrialPeriod) in the server-owned catalog.
      subscriptionInfo = null;
      freeTrial = false;

      if (offer) {
        // An accepted offer is charged on its own: shipping is quoted and invoiced after the sale.
        shipping = null;
        shippingCents = 0;
        totalCents = itemCents;
        shippingMode = "invoiced_later";
        thankYouPath = `/offer/${encodeURIComponent(offer.token)}?paid=1`;
        // Wix takes decimal prices in major units: JPY "5000", USD "19.90", KWD "4.999".
        product = { name: productName, price: unitPrice.toFixed(2), currency: "USD", maxQuantity: 1 };
      } else {
        // A unit with no packed weight and dimensions cannot be rated by UPS, so it ships as freight:
        // quoted after the order and billed separately. Checkout then charges the unit price only.
        const freight = !(["weight_lbs", "length_in", "width_in", "height_in"] as const).every(
          (key) => Number((listing as any)[key]) > 0,
        );
        // Shipping is priced from the imported UPS retail datasets and recomputed here. The buyer's
        // package details are inputs only; the charge itself is always server-resolved.
        const shipDate = String(body.shipDate || "").slice(0, 10) || new Date().toISOString().slice(0, 10);
        const rateSources = freight ? null : await loadRateSources(base44, shipDate);
        const normalized = rateSources
          ? normalizeShippingInput(body, {
              fromZip: rateSources.settings?.origin_zip,
              weightLbs: listing.weight_lbs,
              lengthIn: listing.length_in,
              widthIn: listing.width_in,
              heightIn: listing.height_in,
            })
          : null;
        if (normalized && normalized.ok !== true) {
          return new Response(JSON.stringify({ error: normalized.message, missing: normalized.missing }), { status: 400 });
        }
        const rating = normalized && normalized.ok === true
          ? estimateShipment({ input: normalized.input, ...(rateSources as any) })
          : null;
        // The buyer may accept having shipping invoiced separately. That is only honoured when no rate
        // can be produced at all; a ratable shipment is always charged, so the flag can never skip it.
        const shippingLater = body.shippingLater === true;
        let rateResult: any = rating;
        if (rateResult && rateResult.ok !== true && shippingLater) {
          console.warn("create-checkout: no rate available, invoicing shipping later", {
            productId, code: rateResult.code,
          });
          rateResult = null;
        }
        if (rateResult && rateResult.ok !== true) {
          console.error("create-checkout: shipping unavailable", { productId, code: rateResult.code });
          return new Response(JSON.stringify({ error: rateResult.message, missing: rateResult.missing }), { status: 409 });
        }
        shipping = rateResult && rateResult.ok === true ? rateResult.estimate : null;
        destinationZip = shipping ? shipping.toZip : "";
        shippingService = shipping ? shipping.service : "";
        // UPS estimate plus our handling fee, counted once for the whole shipment.
        shippingCents = shipping ? shipping.totalCents : 0;
        totalCents = itemCents + shippingCents;
        // No shipping charge at checkout is a shipping balance waiting to be invoiced, never free shipping.
        shippingMode = shipping ? "rated" : freight ? "freight" : "invoiced_later";
        product = { name: productName, price: unitPrice.toFixed(2), currency: "USD", maxQuantity: 1 };
      }
    }
    price = product.price;
    if (typeof price !== "string" || !/^\d+(?:\.\d+)?$/.test(price)) {
      return new Response(JSON.stringify({ error: "Invalid product price" }), { status: 400 });
    }
    const shippingPrice = (shippingCents / 100).toFixed(2);
    const total = (totalCents / 100).toFixed(2);
    if (totalCents < 50) {
      return new Response(JSON.stringify({ error: "Amount must be at least 0.50" }), { status: 400 });
    }
    // ===== END APP-SPECIFIC =====

    const constructBody = {
      cart: {
        items: [
          ...(cartItems.length
            ? cartItems
            : [{ name: productName, quantity, price, ...(subscriptionInfo ? { subscriptionInfo } : {}) }]),
          ...(shippingCents > 0
            ? [{ name: `Shipping & handling — ${shippingService} to ${destinationZip}`, quantity: 1, price: shippingPrice }]
            : []),
        ],
        // Prefill the signed-in buyer's email if we have one; anonymous buyers enter it on Wix.
        ...(appUser?.email ? { customerInfo: { email: appUser.email } } : {}),
      },
      callbackUrls: {
        thankYouPageUrl: `${appUrl}${thankYouPath}`,
        postFlowUrl: `${appUrl}${postFlowPath}`,
      },
    };

    const wixRes = await fetch(CONSTRUCT_URL, {
      method: "POST",
      headers: {
        "Authorization": WIX_API_KEY,
        "wix-site-id": WIX_SITE_ID,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(constructBody),
    });

    if (!wixRes.ok) {
      const errText = await wixRes.text();
      console.error("create-checkout: Wix construct failed", { status: wixRes.status, errText });
      return new Response(JSON.stringify({ error: "Could not start checkout" }), { status: 502 });
    }

    const { checkoutSession } = await wixRes.json();
    const checkoutSessionId: string = checkoutSession?.id;
    const redirectUrl: string = checkoutSession?.redirectUrl;

    if (!checkoutSessionId || !redirectUrl) {
      console.error("create-checkout: missing checkoutSession id/redirectUrl", checkoutSession);
      return new Response(JSON.stringify({ error: "Could not start checkout" }), { status: 502 });
    }

    // A shipping invoice payment needs no new purchase row: the invoice already belongs to the
    // original order. Save the session id so the webhook can confirm the shipping charge.
    if (invoice) {
      await base44.asServiceRole.entities.ShippingInvoice.update(invoice.id, {
        paymentSessionId: checkoutSessionId,
      });
      return new Response(JSON.stringify({ redirectUrl }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      });
    }

    // PERSIST THE JOIN KEY (the whole point). Pending until the webhook flips it to "paid".
    // asServiceRole so the row is trustworthy — Base44Purchase RLS blocks client writes, so a buyer
    // can't forge a paid purchase. appUserId is the fulfillment target when known; null for an
    // anonymous buyer (claim only after server-side email verification).
    await base44.asServiceRole.entities.Base44Purchase.create({
      checkoutSessionId,
      status: "pending",
      appUserId: appUser?.id ?? null,
      buyerEmail: appUser?.email ?? null,
      // The server-resolved product key — the webhook grant reads this to decide what to unlock.
      // A cart leaves productId empty and lists every purchased unit in productIds.
      productId: productId || null,
      productIds: cartListingIds,
      productName,
      // Where a cart order ships: the address the buyer entered, and the address type rated.
      ...(shipToAddress ? { shipTo: shipToAddress, destinationType: shipToType } : {}),
      // Persist the validated quantity so the webhook's grant can award the RIGHT count
      // (seats/credits/items) for a multi-unit purchase — the grant runs later from this row and has
      // no other authoritative count. (Fixed-entitlement plans keep quantity 1.)
      quantity,
      // The initial trial order is zero; cart price remains the recurring price.
      amount: freeTrial ? "0" : total,
      ...(subscriptionInfo ? { recurringAmount: total, freeTrial } : {}),
      currency,
      buyerName: appUser?.full_name ?? null,
      // Item and shipping are paid on separate invoices when no shipping rate could be produced.
      itemPaymentStatus: "pending",
      itemAmount: (itemCents / 100).toFixed(2),
      shippingAmount: (shippingCents / 100).toFixed(2),
      shippingMode,
      shippingPaymentStatus: shippingMode === "rated" ? "included" : "pending",
    });

    // Tie the accepted offer to this checkout so the payment webhook can confirm it was paid.
    if (offer) {
      await base44.asServiceRole.entities.Offer.update(offer.id, {
        checkout_session_id: checkoutSessionId,
      });
    }

    // Keep the priced shipment as an ordered record; the buyer-facing estimate row is separate, so
    // ordered history survives later recalculations. Freight units have no rated shipment yet.
    if (shipping && productId) await base44.asServiceRole.entities.Shipment.create({
      listing_id: productId,
      status: "ordered",
      order_ref: checkoutSessionId,
      buyer_email: appUser?.email ?? null,
      from_country: "US",
      from_zip: shipping.fromZip,
      to_country: "US",
      to_zip: destinationZip,
      ship_date: shipping.shipDate,
      destination_type: shipping.destinationType,
      weight_lbs: shipping.weightLbs,
      length_in: shipping.lengthIn,
      width_in: shipping.widthIn,
      height_in: shipping.heightIn,
      service: shipping.service,
      rate_basis: shipping.rateBasis,
      zone: shipping.zone,
      actual_lb: shipping.actualLb,
      dim_lb: shipping.dimLb,
      billable_lb: shipping.billableLb,
      base_cents: shipping.baseCents,
      surcharge_cents: shipping.surchargeCents,
      surcharge_lines: shipping.surchargeLines,
      ups_cents: shipping.upsCents,
      handling_cents: shipping.handlingCents,
      total_cents: shipping.totalCents,
      currency: shipping.currency,
      dataset_id: shipping.datasetId,
      dataset_version: shipping.datasetVersion,
      dataset_effective_from: shipping.datasetEffectiveFrom,
      calculated_at: shipping.calculatedAt,
    });

    return new Response(JSON.stringify({ redirectUrl }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("create-checkout: unhandled error", err);
    return new Response(JSON.stringify({ error: "Internal error" }), { status: 500 });
  }
});