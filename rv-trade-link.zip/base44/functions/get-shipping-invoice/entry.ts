// Public lookup for the buyer's shipping invoice page. The long random token in the link is the
// only key: no sign-in is needed, and only the fields the page shows are returned.
import { createClientFromRequest } from "npm:@base44/sdk";

export default async function (req: Request): Promise<Response> {
  try {
    if (req.method !== "POST") {
      return Response.json({ error: "Method not allowed" }, { status: 405 });
    }
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const token = typeof body.token === "string" ? body.token.trim() : "";
    if (!token) return Response.json({ error: "Invoice link is incomplete" }, { status: 400 });

    const matches = await base44.asServiceRole.entities.ShippingInvoice.filter({ token });
    const invoice = matches?.[0];
    if (!invoice) return Response.json({ error: "Invoice not found" }, { status: 404 });

    return Response.json({
      invoice: {
        id: invoice.id,
        token: invoice.token,
        status: invoice.status,
        amountCents: invoice.amountCents,
        currency: invoice.currency || "USD",
        service: invoice.service ?? "",
        notes: invoice.notes ?? "",
        listingTitle: invoice.listingTitle ?? "Equipment",
        orderRef: invoice.orderRef || invoice.checkoutSessionId || "",
        sentAt: invoice.sentAt ?? null,
        paidAt: invoice.paidAt ?? null,
      },
    });
  } catch (error: any) {
    console.error("get-shipping-invoice: unhandled error", error);
    return Response.json({ error: "Could not load the invoice" }, { status: 500 });
  }
}