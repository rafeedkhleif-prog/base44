// Issues (or re-issues) the separate shipping invoice for an order whose item was already paid.
// Admin only: the amount becomes a real charge the buyer can pay from a link in the email.
import { createClientFromRequest } from "npm:@base44/sdk";

export default async function (req: Request): Promise<Response> {
  try {
    if (req.method !== "POST") {
      return Response.json({ error: "Method not allowed" }, { status: 405 });
    }
    const base44 = createClientFromRequest(req);
    const user = await base44.auth
      .me()
      .catch((e: any) => (e?.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
    if (user.role !== "admin") return Response.json({ error: "Forbidden" }, { status: 403 });

    const body = await req.json().catch(() => ({}));
    const purchaseId = typeof body.purchaseId === "string" ? body.purchaseId : "";
    const amountCents = Number(body.amountCents);
    const service = typeof body.service === "string" ? body.service.trim().slice(0, 120) : "";
    const notes = typeof body.notes === "string" ? body.notes.trim().slice(0, 500) : "";
    if (!purchaseId) return Response.json({ error: "Order is required" }, { status: 400 });
    if (!Number.isSafeInteger(amountCents) || amountCents < 50) {
      return Response.json({ error: "Enter a shipping amount of at least $0.50" }, { status: 400 });
    }

    const appUrl = req.headers.get("x-base44-app-url") || Deno.env.get("WIX_CHECKOUT_APP_URL") || "";
    if (!appUrl) {
      console.error("send-shipping-invoice: no app URL (X-Base44-App-Url header and WIX_CHECKOUT_APP_URL both empty)");
      return Response.json({ error: "App URL is not configured" }, { status: 500 });
    }

    const purchase = await base44.asServiceRole.entities.Base44Purchase
      .get(purchaseId)
      .catch((e: any) => (e?.status === 404 ? null : Promise.reject(e)));
    if (!purchase) return Response.json({ error: "Order not found" }, { status: 404 });
    // Shipping is invoiced against a paid item; anything else has no order to attach it to yet.
    if (purchase.status !== "paid") {
      return Response.json({ error: "The item payment for this order is not confirmed yet" }, { status: 409 });
    }

    const existing = (await base44.asServiceRole.entities.ShippingInvoice.filter({ purchaseId }))?.[0];
    // The token is the buyer's link key: reuse it so an updated invoice keeps working.
    const token = existing?.token || crypto.randomUUID();
    const fields = {
      purchaseId,
      orderRef: purchase.orderId ?? null,
      checkoutSessionId: purchase.checkoutSessionId ?? null,
      listingId: purchase.productId ?? null,
      listingTitle: purchase.productName ?? "Equipment",
      buyerEmail: purchase.buyerEmail ?? null,
      buyerName: purchase.buyerName ?? null,
      amountCents,
      currency: purchase.currency || "USD",
      service: service || "Freight",
      notes: notes || null,
      status: "sent",
      token,
      sentAt: new Date().toISOString(),
    };
    const invoice = existing
      ? await base44.asServiceRole.entities.ShippingInvoice.update(existing.id, fields)
      : await base44.asServiceRole.entities.ShippingInvoice.create(fields);

    // The order's shipping balance is now invoiced, not free and not paid.
    await base44.asServiceRole.entities.Base44Purchase.update(purchase.id, {
      shippingPaymentStatus: "invoiced",
      shippingInvoicedCents: amountCents,
      shippingInvoiceId: invoice.id,
    });

    const paymentUrl = `${appUrl}/shipping-invoice/${encodeURIComponent(token)}`;
    let emailed = false;
    let emailError: string | null = null;
    if (purchase.buyerEmail) {
      try {
        await base44.asServiceRole.integrations.Core.SendEmail({
          to: purchase.buyerEmail,
          template_name: "ShippingInvoice",
          category: "transactional",
          variables: {
            buyer_name: purchase.buyerName || purchase.buyerEmail,
            listing_title: fields.listingTitle,
            amount: `$${(amountCents / 100).toFixed(2)}`,
            service: fields.service,
            order_ref: purchase.orderId || purchase.checkoutSessionId || "",
            payment_url: paymentUrl,
          },
        });
        emailed = true;
      } catch (err: any) {
        // The invoice exists either way — the team can send the link by hand.
        emailError = err?.message || "The email could not be sent";
        console.error("send-shipping-invoice: email failed", { invoiceId: invoice.id, error: emailError });
      }
    } else {
      emailError = "This order has no buyer email on file";
    }

    return Response.json({
      invoiceId: invoice.id,
      paymentUrl,
      emailed,
      emailError,
      buyerEmail: purchase.buyerEmail ?? null,
      amountCents,
    });
  } catch (error: any) {
    console.error("send-shipping-invoice: unhandled error", error);
    return Response.json({ error: "Could not create the shipping invoice" }, { status: 500 });
  }
}