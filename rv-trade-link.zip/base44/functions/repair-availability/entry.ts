import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { unavailableDatesFor } from '../../shared/calendarAvailability.ts';

// Public endpoint: tells requesters which repair days are taken without exposing
// any appointment details. Only the date strings leave the server.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const unavailableDates = await unavailableDatesFor(base44, 'RepairAppointment');
    return Response.json({ unavailableDates });
  } catch (error) {
    console.log('repair-availability failed', error?.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}