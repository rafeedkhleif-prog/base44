// Calculates the estimated UPS shipping charge for a package from the imported rate datasets,
// adds our handling fee once, and stores the estimate on the listing's shipment record.
// Public: a buyer estimating freight does not need an account.

import { createClientFromRequest } from "npm:@base44/sdk@0.8.54";
import {
  estimateShipment,
  loadRateSources,
  normalizeShippingInput,
  normalizeZip,
} from "../../shared/upsRate.ts";

function pageItems(result: any): any[] {
  if (Array.isArray(result)) return result;
  return Array.isArray(result?.items) ? result.items : [];
}

function savedToEstimate(record: any) {
  return {
    zone: record.zone ?? 0,
    actualLb: record.actual_lb ?? 0,
    dimLb: record.dim_lb ?? 0,
    billableLb: record.billable_lb ?? 0,
    baseCents: record.base_cents ?? 0,
    surchargeCents: record.surcharge_cents ?? 0,
    surchargeLines: Array.isArray(record.surcharge_lines) ? record.surcharge_lines : [],
    upsCents: record.ups_cents ?? 0,
    handlingCents: record.handling_cents ?? 0,
    totalCents: record.total_cents ?? 0,
    service: record.service || "UPS Ground",
    rateBasis: record.rate_basis || "retail",
    currency: record.currency || "USD",
    datasetId: record.dataset_id || "",
    datasetVersion: record.dataset_version || "",
    datasetEffectiveFrom: record.dataset_effective_from || "",
    calculatedAt: record.calculated_at || record.updated_date || "",
    fromZip: record.from_zip || "",
    toZip: record.to_zip || "",
    shipDate: record.ship_date || "",
    destinationType: record.destination_type || "residential",
    weightLbs: record.weight_lbs ?? 0,
    lengthIn: record.length_in ?? 0,
    widthIn: record.width_in ?? 0,
    heightIn: record.height_in ?? 0,
  };
}

export default async function (req: Request): Promise<Response> {
  try {
    if (req.method !== "POST") {
      return Response.json({ error: "Method not allowed" }, { status: 405 });
    }
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const listingId = typeof body.listingId === "string" ? body.listingId : "";

    // Restore the last saved estimate for this listing so a reopened record shows its inputs.
    if (body.restore === true) {
      if (!listingId) return Response.json({ ok: true, saved: null });
      const result = await base44.asServiceRole.entities.Shipment.filter(
        { listing_id: listingId },
        { sort: "-updated_date", limit: 1 }
      );
      const record = pageItems(result)[0] ?? null;
      if (!record || !record.calculated_at) return Response.json({ ok: true, saved: null });
      return Response.json({ ok: true, saved: savedToEstimate(record) });
    }

    const { settings, dataset, zoneRows, rateRows, ruleRows } = await loadRateSources(
      base44,
      String(body.shipDate || "").slice(0, 10) || new Date().toISOString().slice(0, 10)
    );
    const normalized = normalizeShippingInput(body, {
      fromZip: settings?.origin_zip,
      weightLbs: undefined,
    });
    if (normalized.ok !== true) {
      return Response.json(normalized, { status: 400 });
    }

    const result = estimateShipment({
      input: normalized.input,
      settings,
      dataset,
      zoneRows,
      rateRows,
      ruleRows,
    });
    if (result.ok !== true) {
      console.log("shipping-estimate: unavailable", { listingId, code: result.code });
      return Response.json(result, { status: 200 });
    }

    const estimate = result.estimate;
    if (!listingId) {
      return Response.json({ ok: true, estimate });
    }

    // Replace the current estimate for this lane; ordered/shipped records are left untouched.
    const existingResult = await base44.asServiceRole.entities.Shipment.filter({
      listing_id: listingId,
      status: "estimated",
    });
    const existing = pageItems(existingResult).find(
      (row: any) =>
        String(row.to_zip || "") === estimate.toZip &&
        String(row.destination_type || "residential") === estimate.destinationType
    );

    const payload = {
      listing_id: listingId,
      status: "estimated",
      from_country: "US",
      from_zip: estimate.fromZip,
      to_country: "US",
      to_zip: normalizeZip(estimate.toZip),
      ship_date: estimate.shipDate,
      destination_type: estimate.destinationType,
      weight_lbs: estimate.weightLbs,
      length_in: estimate.lengthIn,
      width_in: estimate.widthIn,
      height_in: estimate.heightIn,
      service: estimate.service,
      rate_basis: estimate.rateBasis,
      zone: estimate.zone,
      actual_lb: estimate.actualLb,
      dim_lb: estimate.dimLb,
      billable_lb: estimate.billableLb,
      base_cents: estimate.baseCents,
      surcharge_cents: estimate.surchargeCents,
      surcharge_lines: estimate.surchargeLines,
      ups_cents: estimate.upsCents,
      handling_cents: estimate.handlingCents,
      total_cents: estimate.totalCents,
      currency: estimate.currency,
      dataset_id: estimate.datasetId,
      dataset_version: estimate.datasetVersion,
      dataset_effective_from: estimate.datasetEffectiveFrom,
      calculated_at: estimate.calculatedAt,
    };

    if (existing) {
      await base44.asServiceRole.entities.Shipment.update(existing.id, payload);
    } else {
      await base44.asServiceRole.entities.Shipment.create(payload);
    }

    return Response.json({ ok: true, estimate });
  } catch (error) {
    console.error("shipping-estimate: error", error);
    return Response.json({ ok: false, error: "Estimate failed" }, { status: 500 });
  }
}