import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const FALLBACK_APP_URL = 'https://rv-trade-link.base44.app';
const BATCH_SIZE = 5;

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const payload = await req.json().catch(() => ({}));
    const headline = String(payload.headline || '').trim().slice(0, 140);
    const message = String(payload.message || '').trim().slice(0, 4000);
    const ctaLabel = String(payload.ctaLabel || '').trim().slice(0, 40) || 'Browse inventory';
    const rawCta = String(payload.ctaUrl || '').trim().slice(0, 500);
    if (!headline || !message) {
      return Response.json({ error: 'A headline and a message are required.' }, { status: 400 });
    }

    // Optional letter attached to the issue. Only files this app uploaded are accepted, so the
    // attachment can never be pointed at an arbitrary third-party URL.
    const rawLetter = String(payload.letterUrl || '').trim().slice(0, 500);
    const letterName = String(payload.letterName || '').trim().slice(0, 120);
    if (rawLetter && !/^https:\/\/(media\.base44\.com|static\.wixstatic\.com)\//i.test(rawLetter)) {
      return Response.json({ error: 'That letter file is not valid. Upload it again.' }, { status: 400 });
    }
    const letterUrl = rawLetter;

    const appUrl = (req.headers.get('X-Base44-App-Url') || FALLBACK_APP_URL).replace(/\/$/, '');
    const ctaUrl = rawCta
      ? rawCta.startsWith('http')
        ? rawCta
        : `${appUrl}${rawCta.startsWith('/') ? '' : '/'}${rawCta}`
      : `${appUrl}/equipment`;
    const issueDate = new Date().toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    });

    // The admin screen publishes the issue to the newsletter tab before calling us; only publish
    // here when the caller did not already do it.
    const issueId = String(payload.issueId || '').trim();
    if (!issueId) {
      await base44.asServiceRole.entities.NewsletterIssue.create({
        headline,
        message,
        cta_label: ctaLabel,
        cta_url: rawCta || '/equipment',
        issue_date: new Date().toISOString().slice(0, 10),
        ...(letterUrl ? { letter_url: letterUrl, letter_name: letterName } : {}),
      });
    }

    const page = await base44.asServiceRole.entities.Subscriber.filter(
      { status: 'active' },
      { limit: 500 }
    );
    const subscribers = page?.items || [];
    if (!subscribers.length) return Response.json({ sent: 0, failed: 0, total: 0, published: true });

    let sent = 0;
    let failed = 0;
    const failures = [];

    for (let i = 0; i < subscribers.length; i += BATCH_SIZE) {
      const batch = subscribers.slice(i, i + BATCH_SIZE);
      const results = await Promise.allSettled(
        batch.map((subscriber) =>
          base44.asServiceRole.integrations.Core.SendEmail({
            to: subscriber.email,
            template_name: 'Newsletter',
            category: 'marketing',
            variables: {
              headline,
              preheader: message.replace(/\s+/g, ' ').slice(0, 120),
              message: message.replace(/\n/g, '<br />'),
              cta_url: ctaUrl,
              cta_label: ctaLabel,
              issue_date: issueDate,
              first_name: (subscriber.name || '').split(' ')[0] || 'there',
              letter_note: letterUrl
                ? `Attached to this issue: ${letterName || 'the letter'}.`
                : '',
            },
            ...(letterUrl
              ? { attachments: [{ filename: letterName || 'Newsletter-letter.pdf', file_url: letterUrl }] }
              : {}),
          })
        )
      );

      results.forEach((result, index) => {
        const email = batch[index].email;
        if (result.status === 'fulfilled' && result.value?.success !== false) {
          sent += 1;
        } else {
          failed += 1;
          const reason =
            result.status === 'rejected'
              ? result.reason?.message || 'error'
              : result.value?.reason || result.value?.message || 'error';
          console.error('Newsletter send failed', email, reason);
          failures.push({ email, reason });
        }
      });
    }

    return Response.json({ sent, failed, total: subscribers.length, failures: failures.slice(0, 10) });
  } catch (error) {
    console.error('send-newsletter error', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}