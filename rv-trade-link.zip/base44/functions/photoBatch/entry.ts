import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { auditGallery, buildPage, finalizeQueue, queueCounts } from '../../shared/photoBatchBuild.ts';
import { nextPhoto, finishPhoto, failPhoto, reviewPhoto } from '../../shared/photoBatchJobs.ts';
import { applyPhoto, rollbackGallery } from '../../shared/photoBatchStore.ts';
import { acquirePhotoWrite, releasePhotoWrite } from '../../shared/photoBatchLock.ts';
import { pilotApproved, approvePilot } from '../../shared/photoPilotGate.ts';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch(e => e.status === 401 ? null : Promise.reject(e));
    if (!user || user.role !== 'admin') return Response.json({ error: 'Administrators only' }, { status: 403 });
    const input = await req.json().catch(() => ({}));
    const entities = base44.entities;
    const key = ['apply', 'finish', 'fail'].includes(input.action) ? 'prep_id' : ['approve', 'retry'].includes(input.action) ? 'slot_id' : input.action === 'rollback' ? 'backup_id' : null;
    if (key && (typeof input[key] !== 'string' || !/^[A-Za-z0-9_-]{1,80}$/.test(input[key]))) return Response.json({ error: `Valid ${key} required` }, { status: 400 });
    if (['finish', 'fail'].includes(input.action) && (typeof input.claim_token !== 'string' || input.claim_token.length > 80 || !input.claim_token)) return Response.json({ error: 'Browser claim required' }, { status: 400 });
    if (['next', 'apply', 'approve'].includes(input.action) && !await pilotApproved(entities)) return Response.json({ error: 'Production is locked until the actual 512 browser pilot succeeds and is approved' }, { status: 409 });
    const mutates = ['build', 'finalize', 'next', 'finish', 'fail', 'apply', 'approve', 'retry', 'rollback', 'approvePilot'].includes(input.action);
    const lock = mutates ? await acquirePhotoWrite(entities) : null;
    if (lock?.error) return Response.json(lock, { status: lock.httpStatus });
    let result;
    try {
    switch (input.action) {
      case 'audit': result = await auditGallery(entities); break;
      case 'counts': result = { ...await queueCounts(entities), pilotApproved: await pilotApproved(entities) }; break;
      case 'approvePilot': result = await approvePilot(entities, input, user); break;
      case 'build':
        if (input.cursor && (typeof input.cursor !== 'string' || input.cursor.length > 4000)) return Response.json({ error: 'Invalid cursor' }, { status: 400 });
        result = await buildPage(entities, input.cursor); break;
      case 'finalize': result = await finalizeQueue(entities); break;
      case 'next': result = await nextPhoto(entities); break;
      case 'finish': result = await finishPhoto(entities, input, Deno.env.get('BASE44_APP_ID')); break;
      case 'fail': result = await failPhoto(entities, input); break;
      case 'apply': result = await applyPhoto(entities, input.prep_id); break;
      case 'approve': case 'retry': result = await reviewPhoto(entities, input); break;
      case 'rollback': result = await rollbackGallery(entities, input.backup_id); break;
      default: return Response.json({ error: 'Unknown operation' }, { status: 400 });
    }
    } finally { if (lock) await releasePhotoWrite(entities, lock); }
    return Response.json(result, { status: result.httpStatus || 200 });
  } catch (error) {
    console.error('Photo batch:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}