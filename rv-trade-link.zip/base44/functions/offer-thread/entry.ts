import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const FIELDS = [
  "id",
  "listing_id",
  "listing_title",
  "asking_price",
  "buyer_name",
  "amount",
  "message",
  "status",
  "countered_amount",
  "counter_message",
  "counter_by",
  "created_date",
  "responded_at",
  "paid_at",
];

// Only the buyer-facing fields; the token and email never leave the server.
function pick(record) {
  const out = {};
  FIELDS.forEach((field) => {
    out[field] = record[field] ?? null;
  });
  return out;
}

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const token = typeof body.token === "string" ? body.token.trim() : "";
    if (!token) {
      return Response.json({ error: "An offer link is required" }, { status: 400 });
    }

    const { items } = await base44.asServiceRole.entities.Offer.filter(
      { token },
      { limit: 1 }
    );
    const offer = items && items[0];
    if (!offer) {
      return Response.json({ error: "This offer link is not valid" }, { status: 404 });
    }

    const action = body.action;
    if (action !== "accept" && action !== "decline") {
      return Response.json({ offer: pick(offer) });
    }

    if (offer.status !== "countered") {
      return Response.json(
        { error: "This offer is not waiting on your reply", offer: pick(offer) },
        { status: 409 }
      );
    }

    const update =
      action === "accept"
        ? {
            status: "accepted",
            amount: offer.countered_amount ?? offer.amount,
            responded_at: new Date().toISOString(),
          }
        : { status: "declined", responded_at: new Date().toISOString() };

    const updated = await base44.asServiceRole.entities.Offer.update(offer.id, update);
    return Response.json({ offer: pick(updated) });
  } catch (error) {
    console.log("offer-thread failed", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
}