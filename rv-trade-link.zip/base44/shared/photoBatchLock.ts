// A short database mutex for writes, not a runner. No work continues after a tab closes.
export async function acquirePhotoWrite(entities) {
  const page = await entities.PhotoBatchControl.filter({ name: 'gallery' }, { limit: 1 });
  const control = page.items[0];
  if (!control) return { error: 'Gallery write control has not been initialized', httpStatus: 503 };
  if (control.token && Date.parse(control.lease_until) > Date.now()) return { error: 'Another gallery write is in progress. Retry after it finishes.', httpStatus: 409 };
  const token = crypto.randomUUID();
  await entities.PhotoBatchControl.updateMany({ id: control.id, updated_date: control.updated_date, token: control.token || '' }, { $set: { token, lease_until: new Date(Date.now() + 6 * 60 * 1000).toISOString() } });
  const claimed = await entities.PhotoBatchControl.get(control.id);
  if (claimed.token !== token) return { error: 'Another gallery write acquired the lock', httpStatus: 409 };
  return { id: control.id, token };
}
export async function releasePhotoWrite(entities, lock) {
  await entities.PhotoBatchControl.updateMany({ id: lock.id, token: lock.token }, { $set: { token: '', lease_until: new Date(0).toISOString() } });
}