// Shared UPS retail rate engine.
// Uses imported, published rate datasets only: an origin-specific zone chart, a base rate
// table and surcharge rules. Never estimates a zone from ZIP arithmetic and never invents a rate.

export type ShippingInput = {
  fromZip: string;
  toZip: string;
  shipDate: string;
  destinationType: "residential" | "commercial";
  weightLbs: number;
  lengthIn: number;
  widthIn: number;
  heightIn: number;
};

export type ShippingEstimate = {
  zone: number;
  actualLb: number;
  dimLb: number;
  billableLb: number;
  baseCents: number;
  surchargeCents: number;
  surchargeLines: string[];
  upsCents: number;
  handlingCents: number;
  totalCents: number;
  service: string;
  rateBasis: string;
  currency: string;
  datasetId: string;
  datasetVersion: string;
  datasetEffectiveFrom: string;
  calculatedAt: string;
  fromZip: string;
  toZip: string;
  shipDate: string;
  destinationType: string;
  weightLbs: number;
  lengthIn: number;
  widthIn: number;
  heightIn: number;
};

export type EstimateResult =
  | { ok: true; estimate: ShippingEstimate }
  | { ok: false; code: string; message: string; missing: string[] };

export const HANDLING_FALLBACK_CENTS = 300;

export function normalizeZip(value: unknown): string {
  const digits = String(value ?? "").replace(/[^0-9]/g, "");
  return digits.length === 5 ? digits : "";
}

export function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

export function normalizeDate(value: unknown): string {
  const raw = String(value ?? "").trim().slice(0, 10);
  return /^\d{4}-\d{2}-\d{2}$/.test(raw) ? raw : "";
}

function positiveNumber(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const num = Number(value);
  return Number.isFinite(num) && num > 0 ? num : null;
}

function optionalNumber(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

export function normalizeShippingInput(raw: any, defaults: Record<string, any> = {}): EstimateResult | { ok: true; input: ShippingInput } {
  const source = raw ?? {};
  const fromZip = normalizeZip(source.fromZip ?? defaults.fromZip);
  if (!fromZip) {
    return { ok: false, code: "invalid_input", message: "Ship-from ZIP is not configured in shipping settings.", missing: ["Shipping settings: ship-from ZIP"] };
  }
  const toZip = normalizeZip(source.toZip ?? source.destinationZip ?? source.zip);
  if (!toZip) {
    return { ok: false, code: "invalid_input", message: "Enter a valid 5-digit destination ZIP code.", missing: [] };
  }
  const weightLbs = positiveNumber(source.weightLbs ?? defaults.weightLbs);
  const lengthIn = positiveNumber(source.lengthIn ?? defaults.lengthIn);
  const widthIn = positiveNumber(source.widthIn ?? defaults.widthIn);
  const heightIn = positiveNumber(source.heightIn ?? defaults.heightIn);
  if (weightLbs === null || lengthIn === null || widthIn === null || heightIn === null) {
    return {
      ok: false,
      code: "invalid_input",
      message: "Enter a positive packed weight and box length, width and height.",
      missing: [],
    };
  }
  const destinationType = source.destinationType === "commercial" ? "commercial" : "residential";
  const shipDate = normalizeDate(source.shipDate) || todayIso();
  return {
    ok: true,
    input: { fromZip, toZip, shipDate, destinationType, weightLbs, lengthIn, widthIn, heightIn },
  };
}

function matchesConditions(rule: any, context: { zone: number; billableLb: number; destinationType: string }): boolean {
  const types = Array.isArray(rule.destination_types) ? rule.destination_types : [];
  if (types.length > 0 && !types.includes(context.destinationType)) return false;
  const minWeight = optionalNumber(rule.min_weight_lb);
  if (minWeight !== null && context.billableLb < minWeight) return false;
  const maxWeight = optionalNumber(rule.max_weight_lb);
  if (maxWeight !== null && context.billableLb > maxWeight) return false;
  const zoneMin = optionalNumber(rule.zone_min);
  if (zoneMin !== null && context.zone < zoneMin) return false;
  const zoneMax = optionalNumber(rule.zone_max);
  if (zoneMax !== null && context.zone > zoneMax) return false;
  return true;
}

function formatCents(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}

export function estimateShipment(params: {
  input: ShippingInput;
  settings: any;
  dataset: any;
  zoneRows: any[];
  rateRows: any[];
  ruleRows: any[];
  now?: Date;
}): EstimateResult {
  const { input, settings, dataset, zoneRows, rateRows, ruleRows } = params;
  const now = params.now ?? new Date();
  const missing: string[] = [];

  if (!settings || !normalizeZip(settings.origin_zip)) {
    return {
      ok: false,
      code: "missing_settings",
      message: "Shipping is not configured yet. An administrator must save the business ship-from ZIP.",
      missing: ["Shipping settings"],
    };
  }
  if (!dataset) {
    return {
      ok: false,
      code: "missing_dataset",
      message: `No active UPS Ground retail rate dataset covers ${input.shipDate}. An administrator must import one.`,
      missing: ["UPS rate dataset"],
    };
  }
  if (normalizeZip(dataset.origin_zip) !== input.fromZip) {
    return {
      ok: false,
      code: "missing_zone_chart",
      message: `The imported zone chart is for origin ${dataset.origin_zip || "unknown"}, but the business ships from ${input.fromZip}.`,
      missing: ["UPS zone chart for the current origin ZIP"],
    };
  }

  const zones = Array.isArray(zoneRows) ? zoneRows : [];
  if (zones.length === 0) {
    return {
      ok: false,
      code: "missing_zone_chart",
      message: `The UPS zone chart for origin ${input.fromZip} has not been imported.`,
      missing: ["UPS zone chart"],
    };
  }

  const zip3 = input.toZip.slice(0, 3);
  let zone: number | null = null;
  for (const row of zones) {
    const prefixes = Array.isArray(row.zip3_list) ? row.zip3_list : [];
    if (prefixes.includes(zip3)) {
      zone = Number(row.zone);
      break;
    }
  }
  if (zone === null || !Number.isFinite(zone) || zone <= 0) {
    return {
      ok: false,
      code: "unsupported_destination",
      message: `ZIP ${input.toZip} is not covered by the imported UPS Ground zone chart for origin ${input.fromZip}. Freight or special shipping quote required.`,
      missing: [],
    };
  }

  const dimDivisor = optionalNumber(dataset.dim_divisor) || 139;
  const minBillableLb = optionalNumber(dataset.min_billable_lb) || 1;
  const maxWeightLb = optionalNumber(dataset.max_weight_lb) || 150;
  const maxLengthIn = optionalNumber(dataset.max_length_in) || 108;
  const maxLengthPlusGirthIn = optionalNumber(dataset.max_length_plus_girth_in) || 165;

  const actualLb = Math.ceil(input.weightLbs);
  const dimLb = Math.ceil((input.lengthIn * input.widthIn * input.heightIn) / dimDivisor);
  const billableLb = Math.max(actualLb, dimLb, minBillableLb);
  const girth = 2 * (input.widthIn + input.heightIn);
  const lengthPlusGirth = input.lengthIn + girth;

  if (
    billableLb > maxWeightLb ||
    input.lengthIn > maxLengthIn ||
    lengthPlusGirth > maxLengthPlusGirthIn
  ) {
    return {
      ok: false,
      code: "freight_required",
      message: "Freight or special shipping quote required.",
      missing: [],
    };
  }

  const tables = Array.isArray(rateRows) ? rateRows : [];
  const table = tables.find((row) => Number(row.zone) === zone) ?? null;
  if (!table) {
    return {
      ok: false,
      code: "missing_rate",
      message: `No UPS Ground retail rates are imported for zone ${zone}.`,
      missing: [`UPS Ground retail rate table, zone ${zone}`],
    };
  }
  const rates = Array.isArray(table.rates_cents) ? table.rates_cents : [];
  const baseCents = Number(rates[billableLb]);
  if (!Number.isFinite(baseCents) || baseCents <= 0) {
    return {
      ok: false,
      code: "missing_rate",
      message: `No UPS Ground retail rate is imported for zone ${zone} at ${billableLb} lb.`,
      missing: [`UPS Ground retail rate, zone ${zone}, ${billableLb} lb`],
    };
  }

  const rules = Array.isArray(ruleRows) ? ruleRows : [];
  const context = { zone, billableLb, destinationType: input.destinationType };
  const componentRules = rules
    .filter((rule) => rule.is_fuel !== true && matchesConditions(rule, context))
    .sort((a, b) => (optionalNumber(a.precedence) ?? 100) - (optionalNumber(b.precedence) ?? 100));

  const applied: any[] = [];
  for (const rule of componentRules) {
    const code = String(rule.code || rule.label || "SURCHARGE");
    if (rule.stackable === false && applied.some((item) => item.code === code)) continue;
    const value = Number(rule.value);
    if (!Number.isFinite(value)) continue;
    const cents = rule.kind === "percent" ? Math.round((baseCents * value) / 100) : Math.round(value);
    applied.push({ code, label: String(rule.label || code), cents, fuelApplies: rule.fuel_applies === true });
  }

  const fuelRule = rules.find((rule) => rule.is_fuel === true && matchesConditions(rule, context)) ?? null;
  if (!fuelRule && dataset.requires_fuel_rule !== false) {
    return {
      ok: false,
      code: "missing_fuel_rule",
      message: `No UPS fuel surcharge rule applies for ${input.shipDate}. An administrator must import the current fuel rule.`,
      missing: ["UPS fuel surcharge rule"],
    };
  }
  if (fuelRule) {
    const fuelPercent = Number(fuelRule.value);
    if (!Number.isFinite(fuelPercent)) {
      return {
        ok: false,
        code: "missing_fuel_rule",
        message: "The imported UPS fuel surcharge rule has an invalid percentage.",
        missing: ["UPS fuel surcharge rule"],
      };
    }
    const fuelBase = baseCents + applied.filter((item) => item.fuelApplies).reduce((sum, item) => sum + item.cents, 0);
    const fuelCents = Math.round((fuelBase * fuelPercent) / 100);
    applied.push({
      code: String(fuelRule.code || "FUEL"),
      label: `${fuelRule.label || "Fuel surcharge"} (${fuelPercent}%)`,
      cents: fuelCents,
      fuelApplies: false,
    });
  }

  const surchargeCents = applied.reduce((sum, item) => sum + item.cents, 0);
  const upsCents = baseCents + surchargeCents;
  const handlingCents = Math.max(0, Math.round(optionalNumber(settings.handling_cents) ?? HANDLING_FALLBACK_CENTS));
  const totalCents = upsCents + handlingCents;

  const estimate: ShippingEstimate = {
    zone,
    actualLb,
    dimLb,
    billableLb,
    baseCents,
    surchargeCents,
    surchargeLines: applied.map((item) => `${item.label}: ${formatCents(item.cents)}`),
    upsCents,
    handlingCents,
    totalCents,
    service: String(dataset.service || settings.service || "UPS Ground"),
    rateBasis: String(dataset.rate_basis || settings.rate_basis || "retail"),
    currency: String(settings.currency || "USD"),
    datasetId: String(dataset.id || ""),
    datasetVersion: String(dataset.version || ""),
    datasetEffectiveFrom: String(dataset.effective_from || ""),
    calculatedAt: now.toISOString(),
    fromZip: input.fromZip,
    toZip: input.toZip,
    shipDate: input.shipDate,
    destinationType: input.destinationType,
    weightLbs: input.weightLbs,
    lengthIn: input.lengthIn,
    widthIn: input.widthIn,
    heightIn: input.heightIn,
  };

  return { ok: true, estimate };
}

function pageItems(result: any): any[] {
  if (Array.isArray(result)) return result;
  return Array.isArray(result?.items) ? result.items : [];
}

function datasetApplies(dataset: any, shipDate: string): boolean {
  const from = normalizeDate(dataset.effective_from);
  const to = normalizeDate(dataset.effective_to);
  if (from && shipDate < from) return false;
  if (to && shipDate > to) return false;
  return true;
}

// Loads the business settings plus the published datasets in effect for the shipping date.
export async function loadRateSources(base44: any, shipDate: string) {
  const settingsResult = await base44.asServiceRole.entities.ShippingSettings.list({ sort: "-updated_date", limit: 1 });
  const settings = pageItems(settingsResult)[0] ?? null;

  const datasetResult = await base44.asServiceRole.entities.RateDataset.filter({ status: "active" });
  const basisOf = (row: any) => String(row.rate_basis ?? "retail").trim().toLowerCase();
  const serviceOf = (row: any) => String(row.service ?? "UPS Ground").trim().toLowerCase();
  const candidates = pageItems(datasetResult)
    .filter((row: any) => basisOf(row) === "retail")
    .filter((row: any) => serviceOf(row) === "ups ground")
    .filter((row: any) => datasetApplies(row, shipDate))
    .sort((a: any, b: any) => String(b.effective_from || "").localeCompare(String(a.effective_from || "")));
  const dataset = candidates[0] ?? null;

  if (!dataset) {
    return { settings, dataset: null, zoneRows: [], rateRows: [], ruleRows: [] };
  }

  const [zoneResult, rateResult, ruleResult] = await Promise.all([
    base44.asServiceRole.entities.RateZone.filter({ dataset_id: dataset.id }),
    base44.asServiceRole.entities.RateTable.filter({ dataset_id: dataset.id }),
    base44.asServiceRole.entities.SurchargeRule.filter({ dataset_id: dataset.id }),
  ]);

  return {
    settings,
    dataset,
    zoneRows: pageItems(zoneResult),
    rateRows: pageItems(rateResult),
    ruleRows: pageItems(ruleResult),
  };
}