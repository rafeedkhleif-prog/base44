import { VERSION } from './photoBatchStore.ts';
const MODEL_ID = 'studioludens/birefnet-lite-512';
const PILOT_SOURCES = [
  'https://media.base44.com/images/public/6aeb6aa1c91d4c8d5bcd4ce8/4de616c28_Stryker-1115-Prime-Series__90419__22728.webp',
  'https://media.base44.com/images/public/6aeb6aa1c91d4c8d5bcd4ce8/fad76052c_Stryker-1005-SM104-M-Series-Stretcher__71938.webp',
  'https://media.base44.com/images/public/6aeb6aa1c91d4c8d5bcd4ce8/2c3d852bf_IMG_1455.HEIC',
];
export async function pilotApproved(entities) {
  const page = await entities.PhotoBatchControl.filter({ name: 'gallery' }, { limit: 1 });
  return page.items[0]?.pilot_version === VERSION && page.items[0]?.pilot_model === MODEL_ID;
}
export async function approvePilot(entities, input, user) {
  if (input.model_id !== MODEL_ID || input.version !== VERSION || input.backend !== 'wasm' || input.dtype !== 'fp32' || !Array.isArray(input.samples) || input.samples.length !== 3 || !PILOT_SOURCES.every(url => input.samples.some(s => s.source_url === url && s.engineConfirmed === true && s.outputReady === true))) {
    return { error: 'All three actual 512 WASM fp32 browser previews must succeed and be inspected', httpStatus: 400 };
  }
  const page = await entities.PhotoBatchControl.filter({ name: 'gallery' }, { limit: 1 });
  await entities.PhotoBatchControl.update(page.items[0].id, { pilot_version: VERSION, pilot_model: MODEL_ID, pilot_browser: 'WASM fp32, fixed 512, admin-inspected browser previews', pilot_approved_at: new Date().toISOString(), pilot_approved_by: user.id });
  return { approved: true, started: false };
}