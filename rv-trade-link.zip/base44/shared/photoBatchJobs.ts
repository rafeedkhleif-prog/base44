import { VERSION, getRecord, setAll, sourceKey } from './photoBatchStore.ts';
export async function nextPhoto(entities) {
  // Only expired browser claims are recovered. Opening a second tab never steals live work.
  const expired = await entities.PhotoPrep.filter({ status: 'processing', lease_until: { $lt: new Date().toISOString() } }, { limit: 20 });
  for (const p of expired.items) {
    await entities.PhotoPrep.updateMany({ id: p.id, status: 'processing', claim_token: p.claim_token, lease_until: p.lease_until }, { $set: { status: 'queued', claim_token: '', error: 'Interrupted browser job recovered' } });
    await setAll(entities.PhotoSlot, { prep_id: p.id, current: true, status: 'processing' }, { status: 'queued' });
  }
  const ready = await entities.PhotoSlot.filter({ current: true, status: 'done' }, { limit: 1, sort: 'id' });
  if (ready.items.length) return { type: 'apply', prep_id: ready.items[0].prep_id };
  const slots = await entities.PhotoSlot.filter({ current: true, status: 'queued' }, { limit: 1, sort: 'id' });
  if (!slots.items.length) return { type: 'idle' };
  const slot = slots.items[0];
  const prep = await getRecord(entities.PhotoPrep, slot.prep_id);
  if (!prep) { await entities.PhotoSlot.update(slot.id, { status: 'failed', error: 'Missing source mapping' }); return { type: 'again' }; }
  if (prep.status === 'done' && prep.verified && prep.pipeline_version === VERSION) {
    await setAll(entities.PhotoSlot, { prep_id: prep.id, current: true, status: 'queued' }, { status: 'done', output_url: prep.output_url });
    return { type: 'apply', prep_id: prep.id };
  }
  if (prep.status === 'failed' || prep.status === 'review') {
    await setAll(entities.PhotoSlot, { prep_id: prep.id, current: true, status: 'queued' }, { status: prep.status, output_url: prep.output_url || '', error: prep.error || '' });
    return { type: 'again' };
  }
  if (prep.status === 'processing') return { type: 'busy', until: prep.lease_until };
  const token = crypto.randomUUID();
  await entities.PhotoPrep.updateMany({ id: prep.id, updated_date: prep.updated_date, status: prep.status }, { $set: { status: 'processing', claim_token: token, lease_until: new Date(Date.now() + 15 * 60 * 1000).toISOString(), attempts: (prep.attempts || 0) + 1 } });
  const claimed = await entities.PhotoPrep.get(prep.id);
  if (claimed.claim_token !== token) return { type: 'again' };
  await setAll(entities.PhotoSlot, { prep_id: prep.id, current: true, status: 'queued' }, { status: 'processing' });
  return { type: 'process', record: claimed };
}
export function validResult(input, appId) {
  const r = input.result;
  if (!r || !['white-original', 'segmented'].includes(r.method)) return false;
  const prefix = `https://media.base44.com/images/public/${appId}/`;
  const legacy = `https://base44.app/api/apps/${appId}/files/mp/public/${appId}/`;
  if (typeof r.outputUrl !== 'string' || !(r.outputUrl.startsWith(prefix) || r.outputUrl.startsWith(legacy)) || !/\/[^/?]+\.png$/.test(r.outputUrl)) return false;
  if (![r.coverage, r.inkShare, r.detailRetention].every(n => typeof n === 'number' && Number.isFinite(n) && n >= 0 && n <= 1)) return false;
  if (!Number.isFinite(r.bytes) || r.bytes < 1 || r.bytes > 35 * 1024 * 1024 || !Number.isFinite(r.ms) || r.ms < 0) return false;
  if (r.method === 'white-original') return r.coverage === 1 && r.detailRetention === 1 && r.inkShare >= 0.001;
  return r.coverage >= 0.02 && r.coverage <= 0.9 && r.inkShare >= 0.01 && r.detailRetention >= 0.85;
}
export async function finishPhoto(entities, input, appId) {
  if (!validResult(input, appId)) return { error: 'Result failed safety validation; original gallery retained', httpStatus: 400 };
  const prep = await getRecord(entities.PhotoPrep, input.prep_id);
  if (!prep || prep.status !== 'processing' || !input.claim_token || prep.claim_token !== input.claim_token) return { error: 'Browser claim expired or changed', httpStatus: 409 };
  const r = input.result, verified = r.method === 'white-original';
  const status = verified ? 'done' : 'review';
  const error = verified ? '' : 'Non-white photo: inspect the equipment, labels and edges, then approve. Original remains installed.';
  await entities.PhotoPrep.update(prep.id, { status, verified, output_url: r.outputUrl, lookup_keys: [await sourceKey(prep.source_url), await sourceKey(r.outputUrl)], output_kb: Math.round(r.bytes / 1024), mask_coverage: r.coverage, ink_share: r.inkShare, detail_retention: r.detailRetention, method: r.method, duration_ms: r.ms, pipeline_version: VERSION, claim_token: '', error });
  await setAll(entities.PhotoSlot, { prep_id: prep.id, current: true, status: { $in: ['queued', 'processing', 'failed'] } }, { status, output_url: r.outputUrl, error });
  return { prep_id: prep.id, verified, status };
}
export async function failPhoto(entities, input) {
  const prep = await getRecord(entities.PhotoPrep, input.prep_id);
  if (!prep || prep.claim_token !== input.claim_token || prep.status !== 'processing') return { error: 'Browser claim expired', httpStatus: 409 };
  const error = String(input.error || 'Photo failed verification').slice(0, 600);
  await entities.PhotoPrep.update(prep.id, { status: 'failed', verified: false, error, claim_token: '' });
  await setAll(entities.PhotoSlot, { prep_id: prep.id, current: true, status: { $in: ['queued', 'processing'] } }, { status: 'failed', error });
  return { failed: true };
}
export async function reviewPhoto(entities, input) {
  const slot = await getRecord(entities.PhotoSlot, input.slot_id);
  if (!slot || !slot.current || slot.status === 'skipped') return { error: 'Current mapped slot required', httpStatus: 400 };
  const prep = await getRecord(entities.PhotoPrep, slot.prep_id);
  if (!prep) return { error: 'Mapping not found', httpStatus: 404 };
  if (input.action === 'approve') {
    if (prep.status !== 'review' || prep.pipeline_version !== VERSION || prep.ink_share < 0.01 || prep.detail_retention < 0.85) return { error: 'Unsafe or missing preview cannot be approved', httpStatus: 400 };
    await entities.PhotoPrep.update(prep.id, { status: 'done', verified: true, error: '' });
    await setAll(entities.PhotoSlot, { prep_id: prep.id, current: true, status: 'review' }, { status: 'done', error: '' });
  } else {
    const cached = prep.status === 'done' && prep.verified && prep.pipeline_version === VERSION;
    if (!cached) await entities.PhotoPrep.update(prep.id, { status: 'queued', verified: false, claim_token: '', error: '' });
    await setAll(entities.PhotoSlot, { prep_id: prep.id, current: true, status: { $in: ['failed', 'conflicted', 'rolled_back'] } }, { status: cached ? 'done' : 'queued', error: '' });
  }
  return { prep_id: prep.id };
}