// Shared day-availability lookup for the admin calendars (repair and pickup).
// Only day keys are returned, so a public caller never sees appointment details.

export async function unavailableDatesFor(base44: any, entityName: string): Promise<string[]> {
  const today = new Date().toISOString().slice(0, 10);
  const page = await base44.asServiceRole.entities[entityName].filter(
    { date: { $gte: today } },
    { sort: 'date', limit: 500 },
  );

  const booked = new Set<string>();
  for (const row of page?.items ?? []) {
    if (row?.date) booked.add(String(row.date).slice(0, 10));
  }

  return [...booked].sort();
}