export const APPROVED_URL = 'https://base44.app/api/apps/6aeb6aa1c91d4c8d5bcd4ce8/files/mp/public/6aeb6aa1c91d4c8d5bcd4ce8/adbaefe65_ultrasound-applicator-white-mri.png';
export const VERSION = 'original-safe-512-v3';
export const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
export async function sourceKey(url) {
  const bytes = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(url)));
  return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
}
export async function* pages(entity, query, limit = 200) {
  let cursor;
  do {
    const p = await entity.filter(query, { limit, sort: 'id', ...(cursor ? { cursor } : {}) });
    yield p.items;
    if (p.has_more && (!p.next_cursor || p.next_cursor === cursor)) throw new Error('Incomplete pagination');
    cursor = p.has_more ? p.next_cursor : null;
  } while (cursor);
}
export async function collect(entity, query) {
  const rows = [];
  for await (const page of pages(entity, query)) rows.push(...page);
  return rows;
}
export async function setAll(entity, query, values) {
  let result;
  do { result = await entity.updateMany(query, { $set: values }); } while (result.has_more);
}
export const getRecord = (entity, id) => entity.get(id).catch(e => e.status === 404 ? null : Promise.reject(e));
export function galleryMatches(images, backup, slots) {
  return Array.isArray(images) && images.length === backup.original_images.length && images.every((url, i) => {
    if (url === backup.original_images[i]) return true;
    return slots.some(s => s.slot_index === i && s.output_url === url && ['done', 'applied', 'rolled_back'].includes(s.status));
  });
}
// Database-side compare-and-set, not a read followed by an unconditional update.
// Rechecking the result also makes a crash after the gallery write resumable.
export async function compareGallery(entities, listing, next) {
  if (same(listing.images, next)) return true;
  await entities.Listing.updateMany({ id: listing.id, status: 'active', updated_date: listing.updated_date, images: listing.images }, { $set: { images: next } });
  const after = await getRecord(entities.Listing, listing.id);
  return after?.status === 'active' && same(after.images, next);
}
export async function applyPhoto(entities, prepId) {
  const prep = await getRecord(entities.PhotoPrep, prepId);
  if (!prep || prep.status !== 'done' || !prep.verified || prep.pipeline_version !== VERSION || !prep.output_url) {
    return { error: 'A verified current-version result is required', httpStatus: 400 };
  }
  const pending = await entities.PhotoSlot.filter({ prep_id: prepId, current: true, status: 'done' }, { limit: 25, sort: 'id' });
  const ids = [...new Set(pending.items.map(s => s.listing_id))];
  let applied = 0, conflicted = 0;
  for (const id of ids) {
    const group = pending.items.filter(s => s.listing_id === id);
    const backup = await getRecord(entities.PhotoGalleryBackup, group[0].backup_id);
    const listing = await getRecord(entities.Listing, id);
    const slots = await collect(entities.PhotoSlot, { backup_id: group[0].backup_id });
    let ok = listing?.status === 'active' && backup?.current && galleryMatches(listing.images, backup, slots);
    if (ok) {
      const next = [...listing.images];
      for (const s of group) {
        if (next[s.slot_index] !== backup.original_images[s.slot_index] && next[s.slot_index] !== prep.output_url) { ok = false; break; }
        next[s.slot_index] = prep.output_url;
      }
      if (ok) ok = await compareGallery(entities, listing, next);
    }
    await entities.PhotoSlot.bulkUpdate(group.map(s => ({ id: s.id, status: ok ? 'applied' : 'conflicted', output_url: prep.output_url, applied_at: ok ? new Date().toISOString() : '', error: ok ? '' : 'Gallery changed, listing is inactive, or compare-before-write failed. No concurrent edit was overwritten.' })));
    if (ok) applied += group.length; else conflicted += group.length;
  }
  return { applied, conflicted, has_more: pending.has_more };
}
export async function rollbackGallery(entities, backupId) {
  const backup = await getRecord(entities.PhotoGalleryBackup, backupId);
  if (!backup) return { error: 'Backup not found', httpStatus: 404 };
  const listing = await getRecord(entities.Listing, backup.listing_id);
  const slots = await collect(entities.PhotoSlot, { backup_id: backup.id });
  if (!backup.current || listing?.status !== 'active' || !galleryMatches(listing.images, backup, slots)) {
    return { error: 'Rollback conflict. The gallery was edited or listing is inactive; nothing was replaced.', httpStatus: 409 };
  }
  if (!await compareGallery(entities, listing, backup.original_images)) return { error: 'Rollback compare-before-write conflict', httpStatus: 409 };
  await setAll(entities.PhotoSlot, { backup_id: backup.id, status: { $in: ['applied', 'done', 'conflicted'] } }, { status: 'rolled_back', error: 'Restored original gallery. Cached outputs and original files retained.' });
  await entities.PhotoGalleryBackup.update(backup.id, { rolled_back_at: new Date().toISOString() });
  return { restored: backup.original_images.length, listing_id: listing.id };
}