import { APPROVED_URL, VERSION, collect, pages, galleryMatches, setAll, sourceKey } from './photoBatchStore.ts';
export async function auditGallery(entities) {
  let listings = 0, gallerySlots = 0, skipped = 0;
  const originals = new Set(), sources = new Map();
  for await (const rows of pages(entities.PhotoPrep, { status: { $in: ['done', 'review'] } })) {
    for (const p of rows) if (p.output_url) sources.set(p.output_url, p.source_url);
  }
  for await (const rows of pages(entities.Listing, { status: 'active' })) {
    listings += rows.length;

    for (const l of rows) for (const url of l.images || []) {
      gallerySlots++;
      if (url === APPROVED_URL) skipped++; else originals.add(sources.get(url) || url);
    }
  }
  return { listings, gallerySlots, skipped, eligibleSlots: gallerySlots - skipped, uniqueOriginals: originals.size, audited_at: new Date().toISOString() };
}
export async function buildPage(entities, cursor) {
  const page = await entities.Listing.filter({ status: 'active' }, { sort: 'id', limit: 50, ...(cursor ? { cursor } : {}) });
  if (page.has_more && (!page.next_cursor || page.next_cursor === cursor)) throw new Error('Incomplete listing pagination');
  const listingIds = page.items.map(l => l.id);
  if (!listingIds.length) return { has_more: false, listings: 0, slots: 0 };
  const galleries = await collect(entities.PhotoGalleryBackup, { listing_id: { $in: listingIds }, current: true });
  const existingSlots = await collect(entities.PhotoSlot, { listing_id: { $in: listingIds }, current: true });
  const urls = [...new Set(page.items.flatMap(l => l.images || []))];
  const hashes = await Promise.all(urls.map(sourceKey));
  const known = [];
  // URL-sized GET filters overflow header limits. Fixed-size hashes keep queries bounded.
  for (let i = 0; i < hashes.length; i += 25) known.push(...await collect(entities.PhotoPrep, { lookup_keys: { $in: hashes.slice(i, i + 25) } }));
  const bySource = new Map(), byOutput = new Map();
  for (const p of known) { if (!bySource.has(p.source_url)) bySource.set(p.source_url, p); if (p.output_url) byOutput.set(p.output_url, p); }
  const pendingPreps = new Map();
  for (const l of page.items) for (const url of l.images || []) {
    if (url === APPROVED_URL || bySource.has(url) || byOutput.has(url)) continue;
    pendingPreps.set(url, { source_url: url, lookup_keys: [await sourceKey(url)], listing_id: l.id, listing_title: l.title, source_kind: (url.match(/\.(\w+)(?:$|\?)/)?.[1] || 'IMAGE').toUpperCase(), status: url ? 'queued' : 'failed', error: url ? '' : 'Empty gallery URL' });
  }
  const pending = [...pendingPreps.values()];
  for (let i = 0; i < pending.length; i += 500) {
    const created = await entities.PhotoPrep.bulkCreate(pending.slice(i, i + 500));
    for (const p of created) bySource.set(p.source_url, p);
  }
  const needsBackup = [], selected = new Map();
  for (const l of page.items) {
    const candidates = galleries.filter(b => b.listing_id === l.id);
    const backup = candidates.find(b => galleryMatches(l.images || [], b, existingSlots.filter(s => s.backup_id === b.id)));
    if (backup) selected.set(l.id, backup);
    else {
      if (candidates.length) {
        await setAll(entities.PhotoGalleryBackup, { listing_id: l.id, current: true }, { current: false });
        await setAll(entities.PhotoSlot, { listing_id: l.id, current: true }, { current: false });
      }
      needsBackup.push({ listing_id: l.id, listing_title: l.title, original_images: [...(l.images || [])], current: true });
    }
  }
  if (needsBackup.length) for (const b of await entities.PhotoGalleryBackup.bulkCreate(needsBackup)) selected.set(b.listing_id, b);
  const keys = new Set(existingSlots.map(s => s.slot_key));
  const newSlots = [];
  for (const l of page.items) {
    const backup = selected.get(l.id);
    for (let i = 0; i < backup.original_images.length; i++) {
      const url = backup.original_images[i], key = `${backup.id}:${i}`;
      if (keys.has(key)) continue;
      const prep = byOutput.get(url) || bySource.get(url);
      const cached = prep?.pipeline_version === VERSION && prep.verified && prep.status === 'done';
      const status = url === APPROVED_URL ? 'skipped' : !prep ? 'failed' : byOutput.has(url) && cached ? 'applied' : cached ? 'done' : prep.status === 'review' ? 'review' : prep.status === 'failed' ? 'failed' : 'queued';
      newSlots.push({ slot_key: key, listing_id: l.id, listing_title: l.title, backup_id: backup.id, slot_index: i, source_url: prep?.source_url || url, prep_id: prep?.id || '', output_url: prep?.output_url || '', current: true, status, error: url === APPROVED_URL ? 'Exact approved cover retained' : prep?.error || '' });
    }
  }
  for (let i = 0; i < newSlots.length; i += 500) await entities.PhotoSlot.bulkCreate(newSlots.slice(i, i + 500));
  return { has_more: page.has_more, next_cursor: page.next_cursor, listings: page.items.length, slots: page.items.reduce((n, l) => n + (l.images?.length || 0), 0) };
}
export async function finalizeQueue(entities) {
  const ids = [];
  for await (const rows of pages(entities.Listing, { status: 'active' })) ids.push(...rows.map(l => l.id));
  await setAll(entities.PhotoSlot, { current: true, listing_id: { $nin: ids } }, { current: false });
  await setAll(entities.PhotoGalleryBackup, { current: true, listing_id: { $nin: ids } }, { current: false });
  return auditGallery(entities);
}
export async function queueCounts(entities) {
  const { rows } = await entities.PhotoSlot.aggregate({ query: { current: true }, groupBy: 'status' });
  const counts = Object.fromEntries(rows.map(r => [r.status, r.count]));
  const total = rows.reduce((n, r) => n + r.count, 0);
  return { total, queued: counts.queued || 0, processing: counts.processing || 0, done: (counts.done || 0) + (counts.applied || 0), ready: counts.done || 0, applied: counts.applied || 0, review: counts.review || 0, failed: counts.failed || 0, conflicted: counts.conflicted || 0, skipped: counts.skipped || 0, rolled_back: counts.rolled_back || 0, remaining: total - (counts.skipped || 0) - (counts.applied || 0) };
}